#!/usr/bin/env python3
"""Join the round-3 audit's actual records; never execute PHP or mutate the repo.

The summary is derived from records, not reviewers' summary counters. Missing
records, changed input snapshots and mismatched hashes remain explicit errors.
Review attestations are human evidence: this join verifies their presence and
identity, not whether a human really read a file or whether an oracle is sound.
"""
from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import xml.etree.ElementTree as ET


DEFAULT_BASE = pathlib.Path(__file__).resolve().parent
DEFAULT_REPO = pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di')
BASELINE = '2eb36241787a971e1a8185149aaa08b90304d426'
INITIAL_JOIN_HEAD = '141feff3d4747a70a2d4ac4c3841de53eb55fa73'
MANIFESTS = ['root-review.json', 'core/review.json', 'attributes/review.json', 'parameters/review.json']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def populated(value):
    return value is not None and value != '' and value != [] and value != {}


class Join:
    def __init__(self, base, repo):
        self.base, self.repo = base, repo
        self.inputs, self.cache = {}, {}
        self.errors, self.warnings = [], []

    def issue(self, kind, **detail):
        self.errors.append({'kind': kind, **detail})

    def read(self, path, as_json=True):
        p = pathlib.Path(path)
        if not p.is_absolute():
            p = self.base / p
        key = str(p.resolve())
        if key not in self.cache:
            try:
                data = p.read_bytes()
            except OSError as exc:
                self.issue('missing_artifact', path=key, error=str(exc))
                return {} if as_json else b''
            self.cache[key] = data
            self.inputs[key] = {'path': key, 'sha256': digest(data), 'bytes': len(data)}
        data = self.cache[key]
        if not as_json:
            return data
        try:
            return json.loads(data)
        except ValueError as exc:
            self.issue('invalid_json', path=key, error=str(exc))
            return {}

    def path(self, path):
        p = pathlib.Path(path)
        return str((p if p.is_absolute() else self.base / p).resolve())

    def git(self, *args):
        r = subprocess.run(['git', '-C', str(self.repo), *args], capture_output=True, text=True)
        if r.returncode:
            self.issue('git_read_failed', args=list(args), stderr=r.stderr)
        return r.stdout.strip()

    def check_file(self, path, expected, context):
        try:
            actual = digest(pathlib.Path(path).read_bytes())
        except OSError as exc:
            self.issue('missing_file', path=str(path), context=context, error=str(exc))
            return None
        if expected and actual != expected:
            self.issue('hash_mismatch', path=str(path), context=context, expected=expected, actual=actual)
        return actual


def test_notes(test):
    names = ['contract', 'actual_oracle', 'oracle', 'meaningful_fault',
             'meaningful_fault_counterexample', 'meaningful_production_fault',
             'plausible_fault', 'quality_finding', 'quality_finding_or_limitation',
             'variants_and_quality', 'dataset_edges', 'limits']
    return {k: test[k] for k in names if populated(test.get(k))}


def evidence_status(test):
    if test.get('executed_red_in_round3'):
        return 'executed_red_in_round3'
    return test.get('evidence_status', test.get('fault_evidence', 'review_only'))


def verdict(value):
    return {
        'meaningful_gap': 'meaningful gap',
        'equivalent_under_contract': 'equivalent-under-contract',
        'redundant_path': 'redundant path',
        'defensive_outside_supported_input': 'defensive-outside-supported-input',
        'architecture_decision': 'needs architecture decision',
        'needs decision': 'needs architecture decision',
    }.get(value, value)


def phase_name(label):
    s = str(label)
    if re.search(r'(?:improved|new)(?:-test)?-mutant', s):
        return 'improved_mutant_RED'
    if re.search(r'old(?:-test)?-mutant', s):
        return 'old_mutant_GREEN'
    if re.search(r'old-(?:production|test-original)', s):
        return 'old_production_GREEN'
    if re.search(r'(?:improved|new)-(?:production|test-original|test-restored)', s):
        return 'restored_production_GREEN'
    if 'new-test-control' in s:
        return 'improved_production_control_GREEN'
    if re.search(r'-red(?:84|85)?$', s):
        return 'original_production_RED'
    if re.search(r'-green(?:84|85)?$', s):
        return 'fixed_production_GREEN'
    return None


def runtime_name(row):
    value = str(row.get('runtime', row.get('php', ''))).replace('php', '').replace('PHP', '')
    if value in ('84', '8.4'):
        return 'PHP84'
    if value in ('85', '8.5'):
        return 'PHP85'
    command = row.get('command', [])
    text = ' '.join(command) if isinstance(command, list) else command
    for version in ('84', '85'):
        if 'php' + version + '/php' in text:
            return 'PHP' + version
    return value or 'unspecified'


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base', type=pathlib.Path, default=DEFAULT_BASE)
    ap.add_argument('--repository', type=pathlib.Path, default=DEFAULT_REPO)
    ap.add_argument('--output', type=pathlib.Path)
    ap.add_argument('--inventory', default='final-repository-inventory.json')
    ap.add_argument('--ast', default='final-test-declarations.json')
    ap.add_argument('--junit84', default='final84.xml')
    ap.add_argument('--junit85', default='final85.xml')
    args = ap.parse_args()
    j = Join(args.base.resolve(), args.repository.resolve())
    start_head = j.git('rev-parse', 'HEAD')
    inventory = j.read(args.inventory)
    ast = j.read(args.ast)
    catalog = j.read('survivors-detail.json')
    manifests = {name: j.read(name) for name in MANIFESTS}
    baseline_ast = j.read('current-test-declarations.json')
    baseline_paths = set(j.git('ls-tree', '-r', '--name-only', BASELINE).splitlines())
    initial_paths = set(j.git('ls-tree', '-r', '--name-only', INITIAL_JOIN_HEAD).splitlines())

    inventory_rows = inventory.get('files', [])
    inventory_by_path = {}
    for row in inventory_rows:
        if row['path'] in inventory_by_path:
            j.issue('duplicate_inventory_file', path=row['path'])
        inventory_by_path[row['path']] = row
    actual_scope_counts = dict(collections.Counter(r['scope'] for r in inventory_rows))
    if inventory.get('counts') != actual_scope_counts:
        j.issue('inventory_summary_count_mismatch', summary=inventory.get('counts'), actual=actual_scope_counts)

    files, file_owners, raw_tests, tests = [], collections.defaultdict(list), {}, {}
    for manifest_name, manifest in manifests.items():
        for index, f in enumerate(manifest.get('files', [])):
            path = f['path']
            owner = manifest.get('reviewer')
            file_owners[path].append({'manifest': manifest_name, 'index': index, 'reviewer': owner})
            sha = f.get('current_sha256', f.get('sha256'))
            fresh = f.get('fresh_full_read') is True or f.get('review_status') == 'read_in_full_afresh'
            notes = {k: f[k] for k in ['assessment', 'review_notes', 'analysis', 'current_followup_review', 'delta_review'] if populated(f.get(k))}
            declarations = f.get('current_tests', f.get('tests', []))
            if not fresh:
                j.issue('no_fresh_read_attestation', manifest=manifest_name, path=path)
            if not notes and not declarations:
                j.issue('no_file_notes', manifest=manifest_name, path=path)
            actual_sha = j.check_file(j.repo / path, sha, 'primary review file')
            inv = inventory_by_path.get(path)
            if not inv:
                j.issue('review_file_outside_inventory', manifest=manifest_name, path=path)
            elif sha != inv['sha256']:
                j.issue('inventory_review_hash_mismatch', path=path, inventory_sha256=inv['sha256'], review_sha256=sha)
            files.append({'path': path, 'scope': inv.get('scope') if inv else f.get('scope'),
                          'reviewer': owner, 'manifest': manifest_name, 'manifest_file_index': index,
                          'fresh_read_attestation': fresh, 'reviewed_sha256': sha, 'disk_sha256': actual_sha,
                          'inventory_sha256': inv.get('sha256') if inv else None, 'notes': notes,
                          'individual_test_notes': len(declarations),
                          'added_since_audit_baseline': path not in baseline_paths,
                          'added_since_initial_join_head': path not in initial_paths})
            ast_file = ast.get(path)
            if ast_file and ast_file['sha256'] != sha:
                j.issue('ast_review_file_hash_mismatch', path=path, ast_sha256=ast_file['sha256'], review_sha256=sha)
            for ti, t in enumerate(declarations):
                key = (path, t['name'])
                if key in raw_tests:
                    j.issue('duplicate_primary_test_review', path=path, name=t['name'], manifests=[raw_tests[key][0], manifest_name])
                    continue
                raw_tests[key] = (manifest_name, t)
                matching = [a for a in (ast_file or {}).get('tests', []) if a['name'] == t['name']]
                if len(matching) != 1:
                    j.issue('literal_test_name_not_unique_in_ast', path=path, name=t['name'], matches=len(matching))
                    continue
                a = matching[0]
                for field, reviewed in [('line', t.get('current_line', t.get('line'))),
                                        ('end_line', t.get('current_end_line', t.get('end_line'))),
                                        ('kind', t.get('kind')),
                                        ('body_sha256', t.get('current_body_sha256', t.get('body_sha256')))]:
                    if reviewed is not None and reviewed != a[field]:
                        j.issue('declaration_ast_field_mismatch', path=path, name=t['name'], field=field, review=reviewed, ast=a[field])
                if a.get('literal_name') is not True:
                    j.issue('nonliteral_ast_name', path=path, name=t['name'])
                notes_for_test = test_notes(t)
                has_oracle = any(populated(t.get(k)) for k in ['actual_oracle', 'oracle'])
                has_fault = any(populated(t.get(k)) for k in ['meaningful_fault', 'meaningful_fault_counterexample', 'meaningful_production_fault', 'plausible_fault'])
                if not has_oracle or not has_fault:
                    j.issue('incomplete_individual_test_notes', path=path, name=t['name'], has_oracle=has_oracle, has_specific_fault=has_fault)
                tests[key] = {'id': path + '::' + t['name'], 'path': path, 'name': t['name'],
                              'kind': a['kind'], 'line': a['line'], 'end_line': a['end_line'],
                              'literal_ast_match': True, 'body_sha256': a['body_sha256'],
                              'reviewer': owner, 'manifest': manifest_name, 'manifest_test_index': ti,
                              'notes': notes_for_test, 'review_evidence_status': evidence_status(t),
                              'junit': {}, 'executed_fault_ids': []}
    for path in inventory_by_path:
        if len(file_owners[path]) != 1:
            j.issue('file_primary_coverage', path=path, primary_reviews=file_owners[path])
    ast_declarations = []
    for path, f in ast.items():
        if path not in inventory_by_path:
            j.issue('ast_file_outside_inventory', path=path)
        for a in f['tests']:
            ast_declarations.append((path, a['name']))
            if (path, a['name']) not in tests:
                j.issue('unreviewed_current_declaration', path=path, name=a['name'], line=a['line'])
    if len(ast_declarations) != len(set(ast_declarations)):
        j.issue('duplicate_literal_names_in_ast')

    # JUnit case names are literal declaration names, optionally prefixed by Pest
    # "it " and followed by a dataset suffix. No fuzzy name matching is allowed.
    junit_summaries = {}
    for runtime, xml_path in [('PHP84', args.junit84), ('PHP85', args.junit85)]:
        data = j.read(xml_path, as_json=False)
        cases = ET.fromstring(data).iter('testcase') if data else []
        status_counts, case_count, seen_ids = collections.Counter(), 0, set()
        for case in cases:
            case_count += 1
            attrs = case.attrib
            path = attrs.get('file', '').split('::', 1)[0]
            name = attrs['name']
            case_id = path + '::' + name
            if case_id in seen_ids:
                j.issue('duplicate_junit_case', runtime=runtime, case_id=case_id)
            seen_ids.add(case_id)
            matches = []
            for a in ast.get(path, {}).get('tests', []):
                base_name = ('it ' if a['kind'] == 'it' else '') + a['name']
                if name == base_name or name.startswith(base_name + ' with data set '):
                    matches.append((path, a['name']))
            status = next((tag for tag in ['error', 'failure', 'skipped'] if case.find(tag) is not None), 'passed')
            status_counts[status] += 1
            if len(matches) != 1:
                j.issue('junit_ast_join_not_unique', runtime=runtime, case_id=case_id, matches=matches)
                continue
            key = matches[0]
            if key not in tests:
                j.issue('junit_case_without_primary_review', runtime=runtime, case_id=case_id)
                continue
            tests[key]['junit'].setdefault(runtime, []).append({'id': case_id, 'name': name, 'status': status, 'assertions': int(attrs.get('assertions', 0))})
        for key, t in tests.items():
            if not t['junit'].get(runtime):
                j.issue('declaration_without_junit_case', runtime=runtime, path=key[0], name=key[1])
        junit_summaries[runtime] = {'cases': case_count, 'statuses': dict(status_counts),
                                    'joined_cases': sum(len(t['junit'].get(runtime, [])) for t in tests.values()),
                                    'assertions': sum(c['assertions'] for t in tests.values() for c in t['junit'].get(runtime, []))}

    catalog_rows = catalog.get('entries', [])
    catalog_by_id = {s['id']: s for s in catalog_rows}
    if len(catalog_by_id) != len(catalog_rows):
        j.issue('duplicate_catalogue_ids')
    survivor_owners, survivors = collections.defaultdict(list), []
    for name, manifest in manifests.items():
        owned_paths = {f['path'] for f in manifest['files']}
        for s in manifest.get('survivors', []):
            sid = s['id']
            survivor_owners[sid].append(name)
            c = catalog_by_id.get(sid)
            v = s.get('verdict', s.get('classification'))
            reason = s.get('reason', s.get('explanation', s.get('contract_reachability')))
            if not populated(v) or not populated(reason):
                j.issue('survivor_without_verdict_or_reason', id=sid, manifest=name)
            if not c:
                j.issue('survivor_not_in_original_catalogue', id=sid, manifest=name)
            else:
                for field in ['path', 'line', 'mutator', 'source_sha256']:
                    actual = s.get('catalogue_line') if field == 'line' and 'catalogue_line' in s else s.get(field)
                    if actual != c[field]:
                        j.issue('survivor_catalogue_identity_mismatch', id=sid, field=field, reviewed=actual, catalogued=c[field])
            if s['path'] not in owned_paths:
                j.issue('survivor_classification_outside_primary_source_scope', id=sid, manifest=name, path=s['path'])
            survivors.append({'id': sid, 'path': s['path'], 'catalogue_line': c.get('line') if c else s.get('line'),
                              'mutator': s.get('mutator'), 'catalogue_source_sha256': c.get('source_sha256') if c else None,
                              'reviewer': manifest.get('reviewer'), 'manifest': name,
                              'original_verdict': v, 'verdict': verdict(v), 'reason': reason,
                              'reachability': s.get('reachability', s.get('contract_reachability')),
                              'anchors': {k: s[k] for k in ['anchors', 'code_anchor', 'test_anchors'] if k in s},
                              'review_evidence_status': s.get('evidence_status'),
                              'executed_pest_witnesses': []})
    for sid in catalog_by_id:
        if len(survivor_owners[sid]) != 1:
            j.issue('survivor_not_assigned_exactly_once', id=sid, manifests=survivor_owners[sid])

    # Explicit proof mappings alone confer executed status. Merely mentioning RED
    # in a reasoned counterexample, source note, or static-analysis proof does not.
    claims = {}

    def claim(path, name, fault_id, refs, owner, kind=None):
        key = (path, name)
        if key not in tests:
            j.issue('executed_claim_without_exact_current_declaration', path=path, name=name, fault_id=fault_id)
            return
        ck = (key, fault_id)
        row = claims.setdefault(ck, {'declaration_id': tests[key]['id'], 'test_path': path, 'name': name,
                                     'fault_id': fault_id, 'kind': kind or ('catalogued_production_mutant' if fault_id in catalog_by_id else 'bespoke_production_mutant'),
                                     'mapped_by': [], 'proofs': []})
        if owner not in row['mapped_by']:
            row['mapped_by'].append(owner)
        for ref in refs:
            ref = {'path': ref} if isinstance(ref, str) else dict(ref)
            ref['path'] = j.path(ref['path'])
            ref.setdefault('role', 'canonical')
            same = next((old for old in row['proofs'] if old['path'] == ref['path']
                         and old['role'] == ref['role'] and old.get('case') == ref.get('case')), None)
            if same is None:
                row['proofs'].append(ref)
            else:
                for rk, rv in ref.items():
                    if populated(rv):
                        if populated(same.get(rk)) and same[rk] != rv:
                            j.issue('conflicting_proof_reference_metadata', fault_id=fault_id, path=ref['path'], field=rk)
                        same[rk] = rv

    for f in manifests['core/review.json']['files']:
        for t in f.get('current_tests', f.get('tests', [])):
            for e in t.get('executed_evidence', []):
                claim(f['path'], t['name'], e['id'], [{'path': e['path'], 'case': e.get('case')}], 'core/review.json')

    attributes = manifests['attributes/review.json']
    label_map = {e['label']: e for e in attributes.get('executed_evidence', [])}
    attribute_decls = [(f['path'], t) for f in attributes['files'] for t in f.get('tests', [])]
    attribute_decls += [(d['path'], d['declaration']) for d in attributes.get('delegated_declarations', [])]
    for path, t in attribute_decls:
        for label in t.get('proof_labels', []):
            if label not in label_map:
                j.issue('missing_attribute_proof_label', path=path, name=t['name'], label=label)
                continue
            e = label_map[label]
            claim(path, t['name'], e['mutant_id'], [e['canonical_proof']], 'attributes/review.json')

    parameters = manifests['parameters/review.json']
    for e in parameters.get('executed_evidence', []):
        refs = [{'path': e['canonical_proof_path'], 'sha256': e.get('proof_sha256')}]
        if 'final_preserved_variant_proof' in e:
            refs[0]['role'] = 'predecessor_not_counted'
            refs.append({'path': e['final_preserved_variant_proof']})
        if 'final_fixture_proof' in e:
            refs[0]['role'] = 'old_controls_only'
            refs.append({'path': e['final_fixture_proof'], 'role': 'new_controls_only'})
        if 'old_test_GREEN_proof' in e:
            refs[0]['role'] = 'new_controls_only'
            refs.append({'path': e['old_test_GREEN_proof'], 'role': 'old_controls_only'})
        for fid in e['fault_ids']:
            claim(e['test_path'], e['declaration_name'], fid, refs, 'parameters/review.json')

    root = manifests['root-review.json']
    root_executed = [(f['path'], t) for f in root['files'] for t in f['tests'] if t.get('executed_red_in_round3')]
    for finding in root.get('findings', []):
        refs = finding.get('evidence', [])
        target = finding.get('test', finding.get('test_path'))
        matches = [(p, t) for p, t in root_executed if p == target or set(t.get('evidence', [])) & set(refs)]
        # The actual Windows CI proof names the unchanged test file among before/
        # after hashes. It is a second source fault caught by the existing test.
        if not matches and 'Windows CI' in str(finding.get('red_kind', '')):
            for ref in refs:
                proof = j.read(ref)
                if not isinstance(proof, dict):
                    continue
                candidates = set(proof.get('before_files', {})) | set(proof.get('after_files', {}))
                matches += [(p, t) for p, t in root_executed if p in candidates]
        for p, t in matches:
            for fid in finding.get('mutants', finding.get('fault_ids', [finding['id']])):
                kind = 'catalogued_production_mutant' if fid in catalog_by_id else 'confirmed_source_bug'
                claim(p, t['name'], fid, refs, 'root-review.json', kind)
    for p, t in root_executed:
        if not any(c['test_path'] == p and c['name'] == t['name'] for c in claims.values()):
            j.issue('root_executed_declaration_without_fault_mapping', path=p, name=t['name'])

    def verify_claim(c):
        accepted, ci_controls = [], []
        for ref in c['proofs']:
            data = j.read(ref['path'])
            actual_hash = j.inputs.get(ref['path'], {}).get('sha256')
            ref['actual_sha256'] = actual_hash
            if ref.get('sha256') and ref['sha256'] != actual_hash:
                j.issue('proof_hash_mismatch', path=ref['path'], expected=ref['sha256'], actual=actual_hash)
            if ref['role'] == 'predecessor_not_counted':
                continue
            if not isinstance(data, dict):
                continue
            if data.get('red_job') and data.get('green', {}).get('conclusion') == 'success' and data.get('meaningful_failure'):
                green = data['green']
                red_log = pathlib.Path(data.get('red_log_file', j.base / 'ci-intermediate-failures' / (str(data['red_job']) + '.log')))
                green_log = pathlib.Path(green.get('log_file', pathlib.Path(ref['path']).parent / ('windows-green-' + str(green['job_id']) + '.log')))
                red_log_hash = j.check_file(red_log, data.get('red_log_sha256'), 'actual Windows RED log')
                green_log_hash = j.check_file(green_log, green.get('raw_log_sha256'), 'actual Windows GREEN log')
                if data.get('before_files', {}).get(c['test_path']) != data.get('after_files', {}).get(c['test_path']):
                    j.issue('platform_tdd_test_bytes_changed', proof=ref['path'], test=c['test_path'])
                ci_controls.append({'proof': ref['path'], 'red_job': data['red_job'], 'green': data['green'],
                                    'meaningful_failure': data['meaningful_failure'],
                                    'red_log': str(red_log), 'red_log_verified_sha256': red_log_hash,
                                    'green_log': str(green_log), 'green_log_verified_sha256': green_log_hash,
                                    'test_unchanged': data.get('test_unchanged'),
                                    'qualification': 'Actual platform CI RED/GREEN attested in canonical proof, not a local mutant run.'})
            rows = data.get('runs', data.get('records', []))
            if 'cases' in data:
                cases = [x for x in data['cases'] if x.get('id') == c['fault_id'] or (ref.get('case') and x.get('label') == ref['case'])]
                if len(cases) != 1:
                    j.issue('proof_case_selector_not_unique', path=ref['path'], fault_id=c['fault_id'], matches=len(cases))
                    continue
                rows = cases[0].get('runs', [])
            elif 'command' in data:
                rows = [data]
            for index, r in enumerate(rows):
                if r.get('excluded_from_semantic_evidence'):
                    continue
                label = r.get('phase', r.get('label', ''))
                phase = phase_name(label)
                if not phase:
                    continue
                explicit_id = r.get('mutant', r.get('mutant_id'))
                label_ids = re.findall(r'(?<![0-9a-f])[0-9a-f]{16}(?![0-9a-f])', str(label))
                if explicit_id and explicit_id != c['fault_id']:
                    continue
                if label_ids and c['fault_id'] not in label_ids:
                    continue
                rp = r.get('test', r.get('test_path'))
                prior_scope_control = phase.startswith('old_') and data.get('new_test') == c['test_path'] and populated(data.get('old_scope'))
                if rp and rp != c['test_path'] and not prior_scope_control:
                    continue
                command = r.get('command', [])
                cmd = ' '.join(command) if isinstance(command, list) else command
                command_tests = re.findall(r'tests/[^\s]+\.php', cmd)
                if command_tests and c['test_path'] not in command_tests and not prior_scope_control:
                    continue
                if 'pest' not in cmd:
                    continue
                if ref['role'] == 'old_controls_only' and not phase.startswith('old_'):
                    continue
                if ref['role'] == 'new_controls_only' and phase.startswith('old_'):
                    continue
                code = r.get('exit', r.get('exit_code'))
                red = phase.endswith('_RED')
                if (red and code not in (1, 2)) or (not red and code != 0):
                    j.issue('invalid_canonical_pest_phase_exit', proof=ref['path'], fault_id=c['fault_id'], phase=label, exit=code)
                    continue
                if r.get('expected_exit') is not None and code != r['expected_exit']:
                    j.issue('unexpected_canonical_pest_exit', proof=ref['path'], phase=label)
                log = r.get('log_path', r.get('log', r.get('output_file', r.get('stdout'))))
                log_hash = None
                if log:
                    log_hash = j.check_file(log, r.get('log_sha256', r.get('sha256') if 'output_file' in r else None), 'Pest proof output')
                else:
                    j.issue('pest_phase_without_output_artifact', proof=ref['path'], phase=label)
                origins = r.get('origins_path', r.get('origins'))
                origin_hash = None
                if isinstance(origins, str):
                    origin_hash = j.check_file(origins, r.get('origins_sha256'), 'historical source origins')
                provenance = bool(r.get('provenance') or origin_hash or r.get('source_test_fingerprint'))
                if not provenance:
                    j.issue('pest_phase_without_provenance_record', proof=ref['path'], phase=label)
                accepted.append({'proof': ref['path'], 'record_index': index, 'label': label, 'phase': phase,
                                 'runtime': runtime_name(r), 'exit': code, 'log': log, 'log_sha256': log_hash,
                                 'origins': origins if isinstance(origins, str) else None,
                                 'origins_sha256': origin_hash, 'historical_provenance_record_present': provenance})
        phase_sets = collections.defaultdict(set)
        for r in accepted:
            phase_sets[r['runtime']].add(r['phase'])
        needed = {'old_production_GREEN', 'old_mutant_GREEN', 'improved_mutant_RED', 'restored_production_GREEN'}
        if c['kind'] == 'confirmed_source_bug':
            needed = {'original_production_RED', 'fixed_production_GREEN'}
        completed = [runtime for runtime, phases in phase_sets.items() if needed <= phases]
        if not completed and not ci_controls:
            j.issue('incomplete_executed_tdd_controls', fault_id=c['fault_id'], declaration=c['declaration_id'], phases={k: sorted(v) for k, v in phase_sets.items()})
        c['accepted_pest_phases'] = accepted
        c['platform_ci_controls'] = ci_controls
        c['complete_runtime_controls'] = completed
        c['accepted_executed_tdd'] = bool(completed or ci_controls)

    for c in claims.values():
        verify_claim(c)
    faults = {}
    for c in claims.values():
        if not c['accepted_executed_tdd']:
            continue
        fid = c['fault_id']
        f = faults.setdefault(fid, {'id': fid, 'kind': c['kind'], 'declarations': [], 'runtimes': set(), 'platform_ci': False})
        if c['declaration_id'] not in f['declarations']:
            f['declarations'].append(c['declaration_id'])
        f['runtimes'].update(c['complete_runtime_controls'])
        f['platform_ci'] |= bool(c['platform_ci_controls'])
        key = (c['test_path'], c['name'])
        if fid not in tests[key]['executed_fault_ids']:
            tests[key]['executed_fault_ids'].append(fid)
    for f in faults.values():
        f['runtimes'] = sorted(f['runtimes'])
    for s in survivors:
        s['executed_pest_witnesses'] = faults.get(s['id'], {}).get('declarations', [])
    executed = [t for t in tests.values() if t['executed_fault_ids']]
    # If a manifest marks a declaration executed but supplies no accepted mapping,
    # it is a gap, never silently promoted by a status string alone.
    for key, (_, t) in raw_tests.items():
        status = evidence_status(t)
        if isinstance(status, str) and status.startswith('executed') and key in tests and not tests[key]['executed_fault_ids']:
            j.issue('executed_status_without_verified_proof_join', declaration=tests[key]['id'], status=status)

    static = []
    for e in parameters.get('static_analysis_evidence', []):
        static.append({'manifest': 'parameters/review.json', **e})
    for e in manifests['core/review.json'].get('executed_checks', []):
        if 'static RED/GREEN' in e.get('kind', ''):
            if not any(x.get('proof') == e.get('evidence') for x in static):
                static.append({'manifest': 'core/review.json', **e})
    excluded = []
    for e in attributes.get('excluded_or_superseded_attempts', []):
        excluded.append({'manifest': 'attributes/review.json', **e})
    for e in parameters.get('exclusions_and_limits', []):
        excluded.append({'manifest': 'parameters/review.json', **e})
    for e in manifests['core/review.json'].get('executed_checks', []):
        for k in ['excluded_bootstrap_attempt', 'incomplete_runner_attempt']:
            if k in e:
                excluded.append({'manifest': 'core/review.json', 'path': e[k], 'reason': k, 'note': e.get('note')})
    for proof_name in ['core/semantic-proofs.json', 'inherited-property-identity-v2/proof.json', 'windows-path-proof/proof.json']:
        d = j.read(proof_name)
        for k in ['superseded_invocation_test_version', 'excluded_setup_attempts']:
            if k in d:
                excluded.append({'proof': j.path(proof_name), 'category': k, 'record': d[k]})
    excluded.append({'path': j.path('inherited-property-identity/proof.json'), 'reason': 'Initial property fixtures are superseded; only inherited-property-identity-v2/proof.json is canonical.'})

    final_head = j.git('rev-parse', 'HEAD')
    if final_head != start_head:
        j.issue('repository_head_changed_during_join', start=start_head, end=final_head)
    for path, record in list(j.inputs.items()):
        try:
            current_hash = digest(pathlib.Path(path).read_bytes())
        except OSError:
            current_hash = None
        if current_hash != record['sha256']:
            j.issue('input_changed_during_join', path=path, start_sha256=record['sha256'], end_sha256=current_hash)

    test_rows = sorted(tests.values(), key=lambda x: (x['path'], x['line']))
    prior_keys = {(p, t['name']) for p, f in baseline_ast.items() for t in f['tests']}
    result = {
        'schema_version': 1,
        'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'repository': str(j.repo), 'repository_head_observed': final_head,
        'audit_baseline': BASELINE, 'initial_aggregation_reference_head': INITIAL_JOIN_HEAD,
        'inventory_snapshot': inventory.get('final_code_head'),
        'status': 'complete_mechanical_join' if not j.errors else 'gaps_detected',
        'method': [
            'Read actual primary records from four manifests; do not use reviewer summary counters.',
            'Verify one file owner, fresh-read attestation, review notes, disk/inventory/AST SHA256, literal declaration identity and individual oracle/fault notes.',
            'Join every JUnit runtime case by exact file/literal Pest name plus dataset suffix; skips remain skips.',
            'Join each original survivor by exact ID/path/line/mutator/source hash; preserve individual verdict and reason.',
            'Count executed Pest TDD only through explicit declaration/fault/proof mappings with successful control sequences or explicit actual-platform CI RED/GREEN.',
            'Proof metadata and output/origin artifact existence are checked, and historical hashes compared where provided; no PHP/tests/mutants/benchmarks are executed by this script.',
            'Historical accepted proof preimages remain historical; current file equality does not relabel old runs as current runs.',
        ],
        'summary': {
            'inventory_files': len(inventory_rows), 'inventory_scope_counts': actual_scope_counts,
            'unique_primary_review_files': len(file_owners), 'primary_file_records': len(files),
            'initial_aggregation_scope_files_still_present': sum(p in initial_paths for p in inventory_by_path),
            'initial_aggregation_scope_counts': dict(collections.Counter(r['scope'] for r in inventory_rows if r['path'] in initial_paths)),
            'current_ast_files': len(ast), 'current_ast_declarations': len(ast_declarations),
            'unique_primary_review_declarations': len(tests), 'junit': junit_summaries,
            'catalogue_survivors': len(catalog_rows), 'classified_survivor_records': len(survivors),
            'unique_classified_survivor_ids': len(survivor_owners),
            'survivor_verdict_counts': dict(collections.Counter(s['verdict'] for s in survivors)),
            'executed_pest_tdd_unique_declarations': len(executed),
            'executed_unique_fault_ids': len(faults),
            'executed_fault_kind_counts': dict(collections.Counter(f['kind'] for f in faults.values())),
            'catalogue_ids_with_executed_pest_witness': sum(bool(s['executed_pest_witnesses']) for s in survivors),
            'meaningful_gap_catalogue_ids_without_executed_witness': sum(s['verdict'] == 'meaningful gap' and not s['executed_pest_witnesses'] for s in survivors),
            'reviewed_declarations_without_executed_pest_tdd': len(tests) - len(executed),
            'static_analysis_evidence_groups_separate_from_pest': len(static),
            'error_count': len(j.errors), 'warning_count': len(j.warnings),
        },
        'root_supplemental_scope': {
            'files_added_since_audit_baseline': [f for f in files if f['reviewer'] == '/root' and f['added_since_audit_baseline']],
            'files_added_since_initial_aggregation_head': [f for f in files if f['reviewer'] == '/root' and f['added_since_initial_join_head']],
            'current_root_declarations_absent_by_literal_identity_from_baseline_ast': [t['id'] for t in test_rows if t['reviewer'] == '/root' and (t['path'], t['name']) not in prior_keys],
            'qualification': 'Supplemental root file/declaration records are explicit additions, not silently added to earlier reviewer scope counts.',
        },
        'files': sorted(files, key=lambda x: x['path']), 'declarations': test_rows,
        'survivors': sorted(survivors, key=lambda x: x['id']),
        'executed_pest_tdd': {'declarations': [{'id': t['id'], 'path': t['path'], 'name': t['name'], 'line': t['line'], 'fault_ids': t['executed_fault_ids']} for t in executed],
                              'faults': sorted(faults.values(), key=lambda x: x['id']),
                              'declaration_fault_proofs': sorted(claims.values(), key=lambda x: (x['test_path'], x['name'], x['fault_id']))},
        'static_analysis_evidence_not_pest_tdd': static,
        'prose_and_unexecuted_evidence': {
            'declaration_ids_without_executed_pest_tdd': [t['id'] for t in test_rows if not t['executed_fault_ids']],
            'meaningful_gap_survivor_ids_without_executed_pest_witness': [s['id'] for s in survivors if s['verdict'] == 'meaningful gap' and not s['executed_pest_witnesses']],
            'qualification': 'A reviewed plausible fault or a surviving mutant is not a confirmed defect in unchanged production and is not an executed RED.',
        },
        'excluded_or_superseded': excluded,
        'supporting_reviews_not_primary_owners': attributes.get('delegated_declarations', []),
        'input_artifacts': sorted(j.inputs.values(), key=lambda x: x['path']),
        'errors': j.errors, 'warnings': j.warnings,
        'limits': [
            'This mechanical join checks completeness/identity of the audit evidence, not the truth of each human review judgment or absence of vulnerabilities.',
            'Individual review of all declarations is separate from an independently executed TDD cycle for each declaration.',
            'Dataset runtime cases, Pest declarations, unique faulty production variants and executions are different units.',
            'Static PHPStan RED/GREEN, native-only probes, setup failures and superseded diagnostic-only kills are not added to the executed Pest totals.',
            'Actual Windows CI controls are platform-specific and are reported separately from local PHP84/PHP85 mutation cycles.',
            'Control-sequence validation checks stored command/result metadata and artifacts. Semantic attribution of a failing test to its intended fault remains the explicitly cited reviewer judgment.',
        ],
    }
    out = args.output or j.base / 'aggregate-review.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(out), 'sha256': digest(out.read_bytes()), 'status': result['status'], 'summary': result['summary'], 'errors': j.errors}, ensure_ascii=False, indent=2))
    return 0 if not j.errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
