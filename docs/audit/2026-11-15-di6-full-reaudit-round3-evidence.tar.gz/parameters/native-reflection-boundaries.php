<?php
final class NativeReflectionScopeProbe
{
    public static function scoped(): Closure { return static function (self $value): void {}; }
    private function hidden(string $value): void {}
    public function __call(string $name, array $arguments): array { return [$name, $arguments]; }
}
$result = [];
$magic = Closure::fromCallable([new NativeReflectionScopeProbe(), 'hidden']);
$r = new ReflectionFunction($magic);
$result['private_magic'] = ['internal'=>$r->isInternal(),'name'=>$r->name,'scope'=>$r->getClosureScopeClass()?->name,'called'=>$r->getClosureCalledClass()?->name,'required'=>$r->getNumberOfRequiredParameters(),'parameter_names'=>array_map(fn(ReflectionParameter $p)=>$p->name,$r->getParameters()),'result'=>$magic('kept','visible')];
$r = new ReflectionMethod(WeakMap::class, 'offsetSet');
$result['native_reflection_method'] = ['scope'=>$r->getClosureScopeClass()?->name,'called'=>$r->getClosureCalledClass()?->name,'bound'=>$r->getClosureThis()];
echo json_encode($result, JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR),"\n";
