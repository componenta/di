import pathlib, subprocess, json, hashlib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');out=base/'numeric-proof'
paths=['tests/Contract/EntryCacheIsolationContractTest.php','tests/Contract/AliasPipelineInvalidationContractTest.php']
for p in paths:(root/p).write_text((base/'isolated'/p).read_text())
rows=[]
commands=[(f'green-php{v}',[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',*paths,'--compact','--colors=never','--do-not-cache-result']) for v in ['84','85']]
commands += [('cs', ['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n','vendor/bin/php-cs-fixer','fix','--config=.php-cs-fixer.dist.php','--dry-run','--diff','--using-cache=no',*paths]),('phpstan',['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n','vendor/bin/phpstan','analyse',*paths,'--level=max','--no-progress','--memory-limit=512M'])]
try:
 for label,cmd in commands:
  r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  path=out/('main-'+label+'.log');path.write_text(r.stdout)
  rows.append({'label':label,'command':cmd,'cwd':str(root),'exit_code':r.returncode,'output':r.stdout,'output_file':str(path),'test_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}})
  print(label,r.returncode,r.stdout[-800:],flush=True)
  assert r.returncode==0
finally:
 (out/'main-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
