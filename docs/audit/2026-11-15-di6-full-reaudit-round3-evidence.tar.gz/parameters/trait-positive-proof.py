import pathlib,subprocess,json,hashlib,difflib,os
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');r=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');iso=b/'isolated';o=b/'eligibility-proof'/'trait-positive-oracle';o.mkdir(exist_ok=True)
source_baseline='2eb36241787a971e1a8185149aaa08b90304d426';test_baseline='7d771478d170ac594a8c9872c119f00bb7f32059';sp='src/Object/ObjectPipeline.php';tp='tests/Contract/FactoryClassAvailabilityContractTest.php'
s=subprocess.check_output(['git','show',source_baseline+':'+sp],cwd=r,text=True);old=subprocess.check_output(['git','show',test_baseline+':'+tp],cwd=r,text=True);new=(r/tp).read_text();needle='''        $metadata = $this->metadata($class);
        if (!is_entry_class_eligible($metadata->class)) {''';assert s.count(needle)==1
m=s.replace(needle,'''        $metadata = $this->metadata($class);
        if ($metadata->class->getTraits() !== []) {
            return false;
        }
        if (!is_entry_class_eligible($metadata->class)) {''');rows=[]
try:
 for phase,prod,tests,expected in [('old-test-original',s,old,0),('old-test-mutant',m,old,0),('new-test-mutant',m,new,1),('new-test-restored',s,new,0)]:
  (iso/sp).write_text(prod);(iso/tp).write_text(tests)
  for version in ['84','85']:
   label=phase+'-php'+version;prov=o/(label+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-n','vendor/bin/pest',tp,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov);q=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=o/(label+'.log');log.write_text(q.stdout);rows.append({'phase':phase,'php':version,'command':cmd,'cwd':str(iso),'exit_code':q.returncode,'output_file':str(log),'output':q.stdout,'source_path':sp,'source_sha256':hashlib.sha256(prod.encode()).hexdigest(),'test_path':tp,'test_sha256':hashlib.sha256(tests.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(label,q.returncode,q.stdout[-220:],flush=True);assert q.returncode==expected and prov.exists()
finally:
 (iso/sp).write_text(s);(iso/tp).write_text(new)
 (o/'results.json').write_text(json.dumps({'production_baseline':source_baseline,'old_test_snapshot':test_baseline,'description':'Meaningful new positive-contract mutant: public canCreate rejects all concrete classes using a trait; no artificial test failure injected. Earlier negative eligibility declarations remain green. This is a bespoke mutant, not one of the 552 CI survivors.','records':rows},indent=2)+'\n')
 (o/'mutant.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),m.splitlines(True),fromfile='a/'+sp,tofile='b/'+sp)))
 (o/'test.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+tp,tofile='b/'+tp)))
