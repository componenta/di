import pathlib,json,subprocess,hashlib
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');r=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');p=b/'review.json';d=json.loads(p.read_text())
subprocess.run(['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n',str(b/'inventory-current-tests.php'),str(b/'test-declarations-current.json')],check=True)
a=json.loads((b/'test-declarations-current.json').read_text())
new={
'shape validation canonicalizes the caller dependency array by reference': {
 'contract':'Public assertShape canonicalizes the supplied array in place: invokable descriptors become class lists and aliases; a scalar delegator becomes a list.',
 'actual_oracle':'Strict complete array equality with an independent expected shape, including exact supplied delegator identity.',
 'meaningful_production_fault':'Skip the delegator output assignment or leave an InvokableDefinition in the caller-owned input.',
 'quality_finding':'Executed exact delegator-normalization mutants 029be1b769417bfb and f4368db14107b8c1: old selected tests GREEN, this oracle RED, restored production GREEN on PHP84/85. Also exposed the original inaccurate public PHPDoc in PHPStan; static and runtime evidence are separate.',
 'dataset_edges':'One fixture deliberately combines invokable alias canonicalization and a scalar delegator; full expected shape verifies preservation and addition of keys.',
 'fault_evidence':'executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85',
 'executed_evidence':str(b/'public-seams-proof/results.json')},
'direct shape validation rejects malformed alias graphs and empty delegator specifications': {
 'contract':'Direct public shape validation rejects malformed alias mappings, cyclic alias graphs and an empty delegator string.',
 'actual_oracle':'Pest toThrow constrains exception class compatibility and diagnostic substring; cyclic graph explicitly expects CircularDependencyException rather than assuming InvalidConfigurationException inheritance.',
 'meaningful_production_fault':'Weaken alias type/empty checks, omit alias cycle validation, or admit the empty delegator at this public boundary.',
 'quality_finding':'Executed five exact mutants d20c9fa5da4157f0,5d2a0001799a65c6,30a1f8a8517cda48,79f85603282597fb,fd7122208c0e83b4. The direct API is exercised so later ContainerFactory normalization cannot mask the skipped validation.',
 'dataset_edges':'Five variants: integer alias key, empty alias key, integer target, two-node cycle, empty delegator string. Each checks its specific diagnostic and the cycle uses its distinct exception class.',
 'fault_evidence':'executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85',
 'executed_evidence':str(b/'public-seams-proof/results.json')},
'implicit entries reject ineligible class kinds even when constructor policy would permit allocation': {
 'contract':'Implicit entry discovery and creation reject anonymous classes, interfaces, traits, abstract classes and enums regardless of NoConstructor policy.',
 'actual_oracle':'Independent false expectations for public ObjectPipeline.canCreate and Container.has, then NotFoundException expectations for get and make.',
 'meaningful_production_fault':'Weaken class-kind eligibility or remove the ObjectPipeline eligibility gate; NoConstructor keeps the otherwise-unreachable non-instantiable path observable.',
 'quality_finding':'All five helper survivor mutants and delegated ObjectPipeline165273e were executed old GREEN/new RED/restored GREEN on PHP84/85. Final trait-consumer fixture reran every mutant; no bootstrap failure counted as semantic RED.',
 'dataset_edges':'Five class kinds are individually tested. Every named non-instantiable fixture carries NoConstructor so isInstantiable alone cannot mask a faulty kind guard. The anonymous class case covers an instantiable but forbidden class.',
 'fault_evidence':'executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85',
 'executed_evidence':str(b/'eligibility-proof/results.json'),
 'final_fixture_evidence':str(b/'eligibility-proof/trait-consumer-final/results.json')},
'implicit entries can create concrete consumers of traits': {
 'contract':'A regular concrete class remains implicitly creatable when it uses a trait whose declaration itself is not an entry.',
 'actual_oracle':'True canCreate for a concrete ReflectionClass, true has, both shared/fresh results of the concrete class, and different shared/fresh identities.',
 'meaningful_production_fault':'Incorrectly reject all classes whose reflected getTraits list is nonempty.',
 'quality_finding':'A bespoke production mutant is executed independently of the 552-survivor catalogue. It preserves the prior negative eligibility tests and fails this positive contract. The concrete ReflectionClass overload also exposes a PHPDoc invariance issue handled by the ObjectPipeline owner.',
 'dataset_edges':'No dataset: one named concrete trait consumer is the contrast to the separate trait declaration negative case.',
 'fault_evidence':'executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85',
 'executed_evidence':str(b/'eligibility-proof/trait-positive-oracle/results.json')},
'standalone lazy and proxy creation uses the supplied proxy factory': {
 'contract':'The optional public ProxyFactoryInterface constructor argument is honored for both lazy and virtual proxy construction.',
 'actual_oracle':'Exact factory call sequence lazy/proxy plus independently expected initialized field values on both products.',
 'meaningful_production_fault':'Discard the supplied factory and instantiate the default factory internally.',
 'quality_finding':'Exact62799d36f56971f5 mutant: old5/16 GREEN, strengthened test RED, restored6/19 GREEN on both PHP versions. Named fixture keeps source-origin validation strict; the earlier anonymous-fixture control exit255 is explicitly excluded.',
 'dataset_edges':'Both factory interface methods are used in one ordered witness; reading resulting fields verifies the initializer/factory callbacks are actually effective.',
 'fault_evidence':'executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85',
 'executed_evidence':str(b/'public-seams-proof/results.json')},
}
for f in d['files']:
 f.setdefault('baseline_sha256',f['sha256']);raw=(r/f['path']).read_bytes();f['sha256']=hashlib.sha256(raw).hexdigest();f['lines']=len(raw.splitlines())
 if f['path'] not in a:continue
 old={t['name']:t for t in f['tests']};fresh=[]
 for t in a[f['path']]['tests']:
  if t['name'] in old:
   x=old[t['name']];x.setdefault('baseline_line',x['line']);x.setdefault('baseline_body_sha256',x['body_sha256'])
  else:
   assert t['name'] in new,t['name'];x={'name':t['name'],**new[t['name']],'new_in_round3':True}
  for k in ['line','end_line','body_sha256']:x[k]=t[k]
  fresh.append(x)
 f['tests']=fresh
for i,j,evidence,extra in [
 (60,1,'configuration-proof/results.json','Three added variants place a valid ParameterResolver or AttributeDefinition before a later invalid specification/priority. They require the correct section-specific diagnostic instead of accidental downstream rejection.'),
 (83,3,'state-proof/results.json','Four variants: shared/fresh resolution each with direct cyclic entry or an already-completed leaf call in the same Fiber. Exact chain and subsequent recovery are observed.'),
 (62,1,'state-proof/results.json','Two variants: replace the definition while suspended; or replace the definition and then install a raw shared override. Shared get must preserve the newer source and make must still use the current definition.'),
 (61,2,'numeric-proof/results.json','Cross-product of null/false source values and ordinary/numeric-string alias IDs, including warmed cache invalidation.')]:
  t=d['files'][i-1]['tests'][j-1];t['round3_additional_dataset_edges']=extra;t['fault_evidence']='executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85';t['executed_evidence']=str(b/evidence)
d['current_snapshot_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();d['current_worktree_note']='Hashes describe the current inspected files, including review patches not yet committed at this update. Baseline read hashes are retained separately.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('review declarations',sum(len(f['tests']) for f in d['files']))
