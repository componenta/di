# DI6 round 3 — container/definition domain conclusions

**Reviewed snapshot:** baseline `2eb36241787a971e1a8185149aaa08b90304d426`; assigned source/test contents reviewed at `141feff3d4747a70a2d4ac4c3841de53eb55fa73` and hash-verified unchanged at final code head `19584c03f77036045184d5eef4b992a9e86aaad6`. The later harness documentation and additional CLI regression do not change this domain. Paths below are relative to `/workspace/scratch/8f6c1df8ef3b/di`.

The review covers **96 newly read files: 31 production files and 65 test/support files**. There are **210 current executable test declarations**, each with an individual contract, actual oracle, specific counterexample and dataset discussion in `review.json`. All **223 assigned catalogue survivors** have a fresh reachability verdict. These are mutation IDs, not counts of independent bugs.

## 1. Canonicalization has an output contract, not an input type assertion

`src/Configuration/DependencyConfiguration.php:101–156` accepts raw dependency shapes and changes the array by reference. A valid literal input may contain an `InvokableDefinition` under an alias and a single delegator Closure; after validation the array contains class lists, aliases and delegator lists. Its former `@phpstan-assert DependencyShape` incorrectly described narrowing of an unchanged input. The new direct public-call test exposed a real `staticMethod.impossibleType` error for that supported input.

The narrow correction removes that assertion and documents `normalize()` as the typed-result API. Runtime statements remain unchanged. A precise `@param-out DependencyShape` attempt was **not** accepted: PHPStan reported the partially transformed values passed through the two private by-reference helpers. Those failed intermediate gates are retained, not relabeled as GREEN. The separate typing plan explains the alternatives and the effect of changing partial mutation on failure.

Evidence: `shape-contract-static-proof/red.json`, `green-gates.json`; `tests/Contract/DependencyConfigurationContractTest.php:152–180`. The four accepted shape mutants are `029be1b769417bfb`, `f4368db14107b8c1`, `79f85603282597fb`, `fd7122208c0e83b4`. Three alias-validation mutants only changed rejection wording; their former REDs are explicitly superseded and excluded from semantic counts.

## 2. Cache publication requires independent, stable revision tokens

`src/Container.php:146–171` only publishes an in-flight result if both the requested pipeline revision and source revision remain current. `src/Internal/EntryCache.php` maintains these tokens independently of the actual cached values, including `null` and `false`.

The strengthened `EntryCachePublicationContractTest` replaces a definition and then installs a raw shared override while an older factory is suspended. This catches ABA caused by changing the sign of only one of the base-revision operations: the old token can otherwise appear current again. The test separately checks that `make()` still follows the current definition. Revision seed values and uniform token steps are not public counters, so several surviving mutations are equivalent under that contract; they should not be killed by asserting private integers.

Evidence: `state-proof/results.json`, exact IDs `3b72a5fed56f647f` and `036d2689b2bbe2ab`; `tests/Contract/EntryCachePublicationContractTest.php:19`. These are test-oracle improvements; the existing runtime implementation was already correct.

## 3. Class eligibility and Fiber cleanup need contrasting successful paths

`src/Internal/functions.php:85–97` rejects anonymous classes, interfaces, traits, abstract classes and enums before constructor policy can affect allocation. The new negative matrix adds `#[NoConstructor]` to the named non-instantiable declarations, preventing a later instantiability check from masking a weakened eligibility guard. A separate positive test verifies that a regular concrete class using a trait remains creatable.

The first unused trait fixture exposed a whole-project PHPStan gate failure that targeted analysis missed. A concrete consumer fixed the fixture without suppression. Its positive oracle has its own meaningful production mutant: incorrectly rejecting all classes with `getTraits() !== []` leaves the earlier negative tests GREEN and fails the new public `canCreate()` assertion. The concrete `ReflectionClass<T>` call also exposed an independent public PHPDoc invariance problem in `ObjectPipeline`; the core reviewer fixed the generic annotations and supplied a separate static RED/GREEN proof. Static failures are not counted as runtime mutation kills.

The Fiber test now completes a leaf resolution before entering a service cycle. This makes `CycleGuard::leaveContext` stack corruption observable through the complete cycle chain and recovery, instead of relying only on a direct cycle.

Evidence: `eligibility-proof/results.json`, `trait-consumer-final/results.json`, `trait-positive-oracle/results.json`, `state-proof/results.json`; static proof at `../core/object-pipeline-generic-proof/proof.json`. Tests: `FactoryClassAvailabilityContractTest.php:101–132`, `RuntimeMutationRecoveryContractTest.php:68`.

## 4. Numeric string IDs remain string API identifiers after PHP key coercion

`src/Container.php:365` converts deferred dependency keys back to strings before alias resolution; `src/Internal/EntryCache.php` does the same during invalidation traversal. PHP array-key coercion means a valid ID such as `'7'` can otherwise become an integer internally. Removing the cast can cause a strict-parameter error, or be caught as an unavailable alias target and unnecessarily invalidate an independent pipeline.

The new variants exercise numeric IDs through both cache invalidation and alias/deferred dependency mutation. The final alias test also preserves its original inline-decorator variant, plus ordinary and numeric deferred IDs. This avoids silently exchanging old coverage for the new witness.

Evidence: `numeric-proof/results.json`; root's final preserved-variant proof at `../preserved-variants-proof/proof.json`. Tests: `EntryCacheIsolationContractTest.php:117`, `AliasPipelineInvalidationContractTest.php:22`. Declarative integer map keys and runtime nonempty string IDs have different admission rules; the review does not merge those boundaries.

## 5. Public extension seams differ from private state injection

The supplied `ProxyFactoryInterface` in `Container::__construct` is a clear public seam. `StandaloneContainerContractTest.php:127` now proves that both `makeLazy` and `makeProxy` use it, observing the two factory calls and initialized product values. Ignoring the supplied object passes the old standalone tests and fails this new contract on PHP84/85.

The constructor also accepts concrete internal `DelegatorRegistry` and `CycleGuard` instances. Whether callers may inject prepopulated or shared internal state is less clear. Those two survivor IDs are recorded as contract decisions, not silently declared equivalent and not turned into implementation-coupled tests. Similar limits apply to prepared external callable ownership across a failed delegator retry and unusual multi-separator opaque IDs. The review preserves current behavior pending a documented lifetime/grammar decision.

Evidence: `public-seams-proof/results.json`, ID `62799d36f56971f5`; `src/Container.php:44–96`. The failed anonymous-fixture source-origin control is excluded; the accepted proof uses a named test fixture.

## 6. The security boundary is configured PHP versus request values

Configuration objects, definitions, factories, strategies, resolvers, autoloaders and external providers are trusted application PHP. Their callbacks can execute arbitrary application code; this DI component is not a sandbox for hostile callbacks. Request data remains data until an explicitly configured mapping/resolver/handler processes it.

Within this domain, `src/Internal/functions.php:150–255` rejects conflicting mapping destinations, invalid sort types and invalid resolver results. These guards protect data shape and dispatch consistency; they are not authorization checks. `Container::set`, `alias`, `delegator`, `get` and `has` protect core IDs and canonical alias targets, including rechecking targets after external ownership or autoload callbacks. `CompositeResolver` attaches a private authority to the container root, so public definition mutation cannot bypass container cache invalidation through that root.

Tests anchoring these boundaries include `ProtectedExternalContainerTest.php:17`, `DelegatorReentrantRegistrationContractTest.php`, `StandaloneContainerContractTest.php:59`, `CentralDefinitionStrategyContractTest.php` and the request-map contract. Arbitrary opaque IDs can contain control bytes; the existing namespace separation prevents collisions between lookup and service guards. Additional cross `get`/`has` callback collision cases are reasoned survivor counterexamples, not confirmed vulnerabilities in the current source.

This is a manual source/test security review. No completed Codex Security plugin scan, attack campaign, or proof of absence of all vulnerabilities is claimed.

## 7. Exceptions and retirement preserve state, but carry application context

`Container` collects obsolete roots in `MutationRetirement`, completes publication/invalidation, then releases them. Its retirement tests observe committed `get`/`make` behavior even when a destructor throws or reenters mutation. Releasing a prepared external callable owner too early would be a distinct lifetime hazard; the corresponding survivor has a concrete reasoned scenario, but no executed RED in this round.

Resolution and configuration exceptions intentionally retain diagnostic context and previous exceptions. Their messages or payloads can therefore include application-supplied values and callback messages. The container does not itself transmit or log them. Applications must choose what error information crosses their HTTP/logging boundary; removing diagnostic payloads here would be an API decision, not an evidence-backed security fix established by this audit.

Anchors: `src/Internal/MutationRetirement.php`; `tests/Contract/MutationRetirementContractTest.php:89–306`, `MutationRetirementBoundaryContractTest.php:24–99`. The mutation harness checks bootstrap and native-output controls separately; a failed harness bootstrap is not counted as a meaningful application mutant RED.

## 8. Performance conclusions are bounded by the actual source path

The default external registry is `null`; normal local lookup does not call `ExternalContainerRegistry::findOwning`. The append-aware suffix traversal therefore does not add `count`/loop work to the zero-external local path. This is source evidence from `src/Container.php:35,108–129,183–195`, not a speedup claim. No new benchmark was run in this round.

Several survivors only change metadata memoization, duplicated invalidation or opaque revision seeds. Their functional equivalence does not establish equal CPU cost. Conversely, the bootstrap active-guard mutation can retain an ever-growing post-bootstrap history of attributed object phases; it is recorded as a reasoned lifetime/performance counterexample without a fragile private-array-size test or unmeasured throughput claim.

## Evidence limits and counts

The accepted runtime proofs cover **19 catalogue IDs owned by this domain**, **one delegated core ID** and **one bespoke trait-consumer mutant**. They map to **10 executable test declarations**; they do not mean that every one of the 210 declarations was artificially mutated. The remaining verdicts are source/test reasoning, with uncertainty and public-contract assumptions stated individually.

Verdicts across 223 catalogue IDs: 87 equivalent under contract, 42 redundant paths, 17 defensive cases outside supported production inputs, 67 potentially meaningful differences, and 10 contract decisions. Of the 67 potentially meaningful IDs, 19 have accepted executed evidence in this domain. The other 48 are reasoned counterexamples, including literal/diagnostic artifacts, not 48 confirmed production bugs.

`immutable-test-snapshots/manifest.json` preserves 21 exact selected test-file preimages and checks hashes against 160 accepted isolated proof rows. Those rows include repeated controls and final-fixture rechecks; assertion counts across runs are deliberately not summed. Final local targeted verification was 49 tests / 123 assertions on each PHP version, CS clean and full-project PHPStan clean on PHP84/85. Root owns the final full-suite and CI results.
