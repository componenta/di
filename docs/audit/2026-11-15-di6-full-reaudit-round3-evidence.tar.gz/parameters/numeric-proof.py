import pathlib,subprocess,os,json,hashlib,difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');iso=base/'isolated';root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');out=base/'numeric-proof';out.mkdir(exist_ok=True);baseline='2eb36241787a971e1a8185149aaa08b90304d426'
def original(p):return subprocess.check_output(['git','show',baseline+':'+p],cwd=root,text=True)
groups=[]
src='src/Internal/EntryCache.php';test='tests/Contract/EntryCacheIsolationContractTest.php';s=original(src);t=original(test)
start=t.index("test('null and false factory results"); end=t.index("test('external ownership",start);part=t[start:end]
new=part.replace('function (mixed $value): void {','function (mixed $value, string $alias): void {').replace("$container->alias('alias', 'source');","$container->alias($alias, 'source');").replace("$container->get('alias')","$container->get($alias)").replace("$container->has('alias')","$container->has($alias)").replace("})->with(['null' => [null], 'false' => [false]]);","})->with(['null' => [null], 'false' => [false]])\n    ->with(['ordinary alias' => 'alias', 'numeric string alias' => '7']);")
strong=t[:start]+new+t[end:];needle='$this->invalidateResolved((string) $sibling, $retirement);';assert s.count(needle)==1;mutant=s.replace(needle,'$this->invalidateResolved($sibling, $retirement);');groups.append(('ec3a27adcd137792',src,test,s,t,strong,mutant,2))
src='src/Container.php';test='tests/Contract/AliasPipelineInvalidationContractTest.php';s=original(src);t=original(test)
strong=t.replace('function (string $mutation): void {','function (string $mutation, string $siblingDecorator): void {',1)
needle="    $container->delegator('sibling', static fn(Entry $entry): Entry => new Entry($entry->path . ':sibling'));"
replacement="    $container->set($siblingDecorator, static fn(Entry $entry): Entry => new Entry($entry->path . ':sibling'));\n    $container->delegator('sibling', $siblingDecorator);"
assert t.count(needle)==1;strong=strong.replace(needle,replacement,1)
strong=strong.replace("})->with(['append delegator', 'replace deferred decorator', 'retarget alias']);","})->with(['append delegator', 'replace deferred decorator', 'retarget alias'])\n    ->with(['ordinary decorator id' => 'sibling.decorator', 'numeric string decorator id' => '7']);",1)
needle='$dependencyId = (string) $dependencyId;';assert s.count(needle)==1;mutant=s.replace(needle,'$dependencyId = $dependencyId;');groups.append(('645741cb54a634ec',src,test,s,t,strong,mutant,1))
rows=[]
try:
 for mid,src,test,s,t,strong,mutant,red in groups:
  for phase,prod,testtext,expected in [('old-test-original',s,t,0),('old-test-mutant',mutant,t,0),('new-test-mutant',mutant,strong,red),('new-test-original',s,strong,0)]:
   (iso/src).write_text(prod);(iso/test).write_text(testtext)
   for v in ['84','85']:
    ident=mid+'-'+phase+'-php'+v;prov=out/(ident+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov)
    r=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/(ident+'.log');log.write_text(r.stdout)
    rows.append({'mutant':mid,'phase':phase,'php':v,'command':cmd,'cwd':str(iso),'exit_code':r.returncode,'output':r.stdout,'output_file':str(log),'source':src,'test':test,'source_sha256':hashlib.sha256(prod.encode()).hexdigest(),'test_sha256':hashlib.sha256(testtext.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(ident,r.returncode,r.stdout[-180:],flush=True);assert r.returncode==expected
  (out/(mid+'-test.patch')).write_text(''.join(difflib.unified_diff(t.splitlines(True),strong.splitlines(True),fromfile='a/'+test,tofile='b/'+test)))
  (out/(mid+'-mutant.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),mutant.splitlines(True),fromfile='a/'+src,tofile='b/'+src)))
finally:
 for mid,src,test,s,t,strong,mutant,red in groups:(iso/src).write_text(s);(iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':baseline,'records':rows},indent=2)+'\n')
