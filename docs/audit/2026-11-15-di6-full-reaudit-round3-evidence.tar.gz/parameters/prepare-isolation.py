import pathlib, subprocess, tarfile, io, shutil, json, hashlib
root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di')
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters')
iso=base/'isolated'
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
assert not iso.exists()
iso.mkdir()
blob=subprocess.check_output(['git','archive',baseline],cwd=root)
with tarfile.open(fileobj=io.BytesIO(blob)) as archive: archive.extractall(iso,filter='data')
(iso/'vendor').mkdir()
for path in (root/'vendor').iterdir():
 dest=iso/'vendor'/path.name
 if path.name in ['composer','bin','pestphp']:
  shutil.copytree(path,dest)
 elif path.is_file(): shutil.copy2(path,dest)
 else: dest.symlink_to(path,target_is_directory=True)
removed=[]
for name in ['autoload_classmap.php','autoload_static.php']:
 path=iso/'vendor/composer'/name
 lines=path.read_text().splitlines(True)
 updated=[line for line in lines if 'DefinitionAwareResolverInterface' not in line]
 removed += [dict(file=name,line=line.strip()) for line in lines if 'DefinitionAwareResolverInterface' in line]
 path.write_text(''.join(updated))
provenance=(pathlib.Path('/workspace/scratch/fa8384e69042/reaudit/parameters-isolated/tests/bootstrap.php').read_text().split('$selectedSource = realpath')[1])
provenance='$selectedSource = realpath'+provenance
provenance=provenance.replace("!isset($classes['Componenta\\\\DI\\\\Attribute\\\\Composition\\\\AttributePlanBuilder'])", "!isset($classes['Componenta\\\\DI\\\\Configuration\\\\DependencyConfiguration'])")
path=iso/'tests/bootstrap.php'; path.write_text(path.read_text()+'\n'+provenance)
source={str(p.relative_to(iso)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (iso/'src').rglob('*.php')}
(base/'isolation.json').write_text(json.dumps({'baseline':baseline,'git_archive_sha256':hashlib.sha256(blob).hexdigest(),'removed_stale_classmap_entries':removed,'source_sha256':source,'isolation':str(iso),'bootstrap_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},indent=2)+'\n')
print('isolated',len(source),'source files; removed',len(removed),'stale metadata lines')
