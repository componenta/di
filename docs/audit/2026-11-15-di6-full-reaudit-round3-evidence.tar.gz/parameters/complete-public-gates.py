import pathlib,subprocess,json,hashlib,difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');out=base/'public-seams-proof'
for name in []:
 p=out/name
 if p.exists():(out/('first-gate-'+name)).write_bytes(p.read_bytes())
paths=['src/Configuration/DependencyConfiguration.php','tests/Contract/FactoryClassAvailabilityContractTest.php','tests/Contract/DependencyConfigurationContractTest.php','tests/Contract/StandaloneContainerContractTest.php'];testpaths=paths[1:];rows=[]
commands=[(f'green-php{v}',[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',*testpaths,'--compact','--colors=never','--do-not-cache-result']) for v in ['84','85']]
commands += [('cs',['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n','vendor/bin/php-cs-fixer','fix','--config=.php-cs-fixer.dist.php','--dry-run','--diff','--using-cache=no',*paths])]
commands += [(f'phpstan-full-php{v}',[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/phpstan','analyse','src','tests','--level=max','--no-progress','--memory-limit=1G']) for v in ['84','85']]
try:
 for label,cmd in commands:
  r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/('final-main-'+label+'.log');log.write_text(r.stdout)
  rows.append({'label':label,'command':cmd,'cwd':str(root),'exit_code':r.returncode,'output_file':str(log),'output':r.stdout,'sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'main_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()});print(label,r.returncode,r.stdout[-1600:],flush=True)
  assert r.returncode==0,label
finally:
 (out/'final-main-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 for p in paths:
  before=subprocess.check_output(['git','show','HEAD:'+p],cwd=root,text=True)
  (out/(pathlib.Path(p).stem+'-main.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),(root/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
 (base/'shape-contract-static-proof'/'green-gates.json').write_text(json.dumps({'description':'Final production correction removes inaccurate phpstan-assert: assertShape mutates its input, so it cannot promise that the original literal input already belongs to DependencyShape. Precise param-out rejected for partially transformed intermediate states; normalize() retains typed return. Final trait positive control exercises the ReflectionClass overload with the separate ObjectPipeline generic PHPDoc correction.','records':rows},indent=2)+'\n')
