import pathlib,subprocess,json,hashlib,difflib,os
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');r=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');iso=b/'isolated';o=b/'public-seams-proof'/'final-semantic-shape';o.mkdir(exist_ok=True)
baseline='2eb36241787a971e1a8185149aaa08b90304d426';sp='src/Configuration/DependencyConfiguration.php';tp='tests/Contract/DependencyConfigurationContractTest.php';s=subprocess.check_output(['git','show',baseline+':'+sp],cwd=r,text=True);t=(r/tp).read_text();mutants=[('79f85603282597fb',s.replace('            self::assertAliasesAcyclic($aliases);','')),('029be1b769417bfb',s.replace('if ($delegators !== []) {','if (!($delegators !== [])) {')),('f4368db14107b8c1',s.replace('if ($delegators !== []) {','if ($delegators === []) {')),('fd7122208c0e83b4',s.replace("if (is_string($delegator) && $delegator !== '') {","if (is_string($delegator) && $delegator !== 'PEST Mutator was here!') {"))];rows=[]
try:
 for phase,prod,expected in [('new-test-control',s,0),*[(mid+'-new-test-mutant',m,1) for mid,m in mutants],('new-test-restored',s,0)]:
  (iso/sp).write_text(prod);(iso/tp).write_text(t)
  for v in ['84','85']:
   label=phase+'-php'+v;prov=o/(label+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',tp,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov);p=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=o/(label+'.log');log.write_text(p.stdout);rows.append({'phase':phase,'php':v,'command':cmd,'cwd':str(iso),'exit_code':p.returncode,'output':p.stdout,'output_file':str(log),'source':sp,'source_sha256':hashlib.sha256(prod.encode()).hexdigest(),'test':tp,'test_sha256':hashlib.sha256(t.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(label,p.returncode,p.stdout[-230:],flush=True);assert p.returncode==expected and prov.exists()
finally:
 (iso/sp).write_text(s);(iso/tp).write_text(t)
 (o/'results.json').write_text(json.dumps({'production_baseline':baseline,'old_test_GREEN_evidence':'../results.json','contract_decision':'Malformed aliases are rejected by compatible exception type; wording differences between equivalent validation layers are not an intended semantic oracle. Three prior alias-message-only kills are superseded, not counted as semantic defects.','records':rows},indent=2)+'\n')
for mid,m in mutants:(o/(mid+'-mutant.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),m.splitlines(True),fromfile='a/'+sp,tofile='b/'+sp)))
orig=b/'public-seams-proof'/'results.json';j=json.loads(orig.read_text());excluded=[]
for row in j['records']:
 if any(mid in row['phase'] for mid in ['d20c9fa5da4157f0','5d2a0001799a65c6','30a1f8a8517cda48']) and 'new-test-mutant' in row['phase']:
  row['excluded_from_semantic_evidence']='Superseded message-only oracle: actual type-compatible rejection remains. Parent review intentionally accepts alternative validation wording.';excluded.append({'phase':row['phase'],'php':row['php'],'output_file':row['output_file']})
orig.write_text(json.dumps(j,indent=2)+'\n');(o/'superseded-alias-message-only.json').write_text(json.dumps(excluded,indent=2)+'\n')
