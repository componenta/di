import pathlib,subprocess,os,json,hashlib,difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters'); iso=base/'isolated'; root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di'); out=base/'state-proof'; out.mkdir(exist_ok=True)
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
def original(path):return subprocess.check_output(['git','show',baseline+':'+path],cwd=root,text=True)
groups=[]
src='src/Internal/CycleGuard.php'; test='tests/Contract/RuntimeMutationRecoveryContractTest.php'; s=original(src); t=original(test)
strong=t.replace("function (bool $fresh): void {", "function (bool $fresh, bool $completedLeaf): void {")
strong=strong.replace("    $attempts = 0;\n", "    $attempts = 0;\n    $container->set('leaf', Definition::factory(static fn(): object => new \\stdClass()));\n",1)
strong=strong.replace('use ($container, $fresh, &$attempts)', 'use ($container, $fresh, $completedLeaf, &$attempts)',1)
strong=strong.replace("        return $fresh ? $container->make('second') : $container->get('second');", "        if ($completedLeaf) {\n            $fresh ? $container->make('leaf') : $container->get('leaf');\n        }\n        return $fresh ? $container->make('second') : $container->get('second');",1)
strong=strong.replace("})->with(['shared' => false, 'fresh' => true]);", "})->with(['shared' => false, 'fresh' => true])\n    ->with(['direct cycle' => false, 'after a completed nested resolution' => true]);",1)
needle='        $stack = $this->fiberStacks[$execution] ?? [];'
assert s.count(needle)==3
idx=s.rindex(needle)
mutants=[('87fa7a782e3b546c',s[:idx]+s[idx:].replace(needle,'        $stack = [];',1)),('91ce753c5495667b',s.replace('        if ($stack === []) {','        if (!($stack === [])) {')),('c984b4652b0940d5',s.replace('        if ($stack === []) {','        if ($stack !== []) {'))]
groups.append(('fiber-stack',src,test,s,t,strong,mutants))
src='src/Internal/EntryCache.php'; test='tests/Contract/EntryCachePublicationContractTest.php';s=original(src);t=original(test)
strong=t.replace("function (): void {", "function (bool $replaceRaw): void {",1)
needle="    $di->set('source', Definition::factory(static fn(): Value => new Value('new')));"
strong=strong.replace(needle,needle+"\n    if ($replaceRaw) {\n        $di->set('source', new Value('raw'));\n    }",1)
strong=strong.replace("->and($current)->toEqual(new Value('new'))", "->and($current)->toEqual(new Value($replaceRaw ? 'raw' : 'new'))",1)
needle="        ->and($di->get('source'))->toBe($current);\n});"
strong=strong.replace(needle,"        ->and($di->get('source'))->toBe($current)\n        ->and($di->make('source'))->toEqual(new Value('new'));\n})->with(['definition only' => false, 'definition then shared override' => true]);",1)
needle='$this->baseRevisions[$id] = $this->baseRevision($id) + 1;'
assert s.count(needle)==2
idx=s.rindex(needle)
mutants=[('3b72a5fed56f647f',s.replace(needle,needle.replace('+ 1','- 1'),1)),('036d2689b2bbe2ab',s[:idx]+s[idx:].replace(needle,needle.replace('+ 1','- 1'),1))]
groups.append(('base-revision',src,test,s,t,strong,mutants))
rows=[]
def run(g,phase,prod,testtext,expected):
 name,src,test,s,t,strong,mutants=g
 (iso/src).write_text(prod); (iso/test).write_text(testtext)
 for version in ['84','85']:
  ident=name+'-'+phase+'-php'+version; prov=out/(ident+'-provenance.json')
  cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result']
  env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov)
  res=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/(ident+'.log')).write_text(res.stdout)
  p=json.loads(prov.read_text()) if prov.exists() else None
  rows.append({'group':name,'phase':phase,'php':version,'command':cmd,'cwd':str(iso),'exit_code':res.returncode,'source':src,'test':test,'source_sha256':hashlib.sha256(prod.encode()).hexdigest(),'test_sha256':hashlib.sha256(testtext.encode()).hexdigest(),'output_file':str(out/(ident+'.log')),'output':res.stdout,'provenance':p})
  print(ident,res.returncode,res.stdout[-180:],flush=True)
  assert res.returncode==expected,ident
  assert p and len(p['eager_functions'])==6,ident
try:
 for g in groups:
  name,src,test,s,t,strong,mutants=g
  assert strong!=t
  (out/(name+'-test.patch')).write_text(''.join(difflib.unified_diff(t.splitlines(True),strong.splitlines(True),fromfile='a/'+test,tofile='b/'+test)))
  run(g,'old-test-original',s,t,0)
  for mid,mutant in mutants:
   (out/(mid+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),mutant.splitlines(True),fromfile='a/'+src,tofile='b/'+src)))
   run(g,mid+'-old-test-mutant',mutant,t,0)
   run(g,mid+'-new-test-mutant',mutant,strong,1 if name=='base-revision' else 2)
  run(g,'new-test-original',s,strong,0)
finally:
 for g in groups:
  name,src,test,s,t,strong,mutants=g
  (iso/src).write_text(s);(iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':baseline,'records':rows},indent=2)+'\n')
