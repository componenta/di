# Precise typing for DependencyConfiguration::assertShape

## Decision implemented in this audit

Remove the inaccurate `@phpstan-assert DependencyShape` from `assertShape`, retain its documented `array<array-key,mixed>` input and in-place canonicalization, and direct callers needing a statically typed result to `normalize()`. This decision was authorized by the root reviewer. **No runtime statements were reorganized.**

`normalize()` already returns `DependencyShape`; the direct `assertShape()` method accepts a broader input containing invokable descriptors and scalar delegators. The previous assertion could make PHPStan reject a valid literal input as `staticMethod.impossibleType`. The direct regression test supplies that input and independently checks the actual normalized array.

Evidence: `shape-contract-static-proof/red.json` and `red-phpstan.log`; final full-project PHP84/PHP85 GREEN in `green-gates.json`. The precise `@param-out` experiment failed with `paramOut.type` at the private by-reference transformations and is preserved in `public-seams-proof/param-out-attempt-checks.json`. Those failures are analysis evidence, not runtime regressions.

## Why a broader redesign might be useful

A caller using `assertShape($dependencies)` does not currently gain a precise post-call type. A truthful `@param-out DependencyShape` could give callers typed invokable lists, alias maps and delegator lists after successful validation, and make invalid output changes easier for static analysis to detect.

The existing method transforms the array in stages: invokables and aliases first, then delegators, while other sections are still broad raw values. The installed PHPStan checks assignments to by-reference output parameters, including helper calls, against their promised output type. Claiming a complete `DependencyShape` on the partially transformed private helpers would be false. Adding suppressions or a cast that simply assumes the final shape would hide the issue.

## Options

| Option | Benefit | Cost and compatibility concern |
| --- | --- | --- |
| Keep the implemented narrow correction | Removes false-positive consumer errors; no runtime change; typed `normalize()` remains available | Direct `assertShape()` callers retain a broad static array type |
| Describe typed intermediate stages and precise section-returning helpers | Can preserve the current transformation order while proving each stage | More type aliases/generics; needs careful analysis of dynamic keys, references and all section validators |
| Build a complete typed result separately and assign the input once | Clear output contract and a single publication point | May make failure atomic instead of leaving partial normalization visible; copying can change alias/reference behavior and must not be assumed free |
| Consolidate on a typed return API and deprecate the by-reference entry point | Simpler long-term contract and consumer guidance | Public API migration and deprecation policy; disproportionate to the narrow issue fixed now |

The first option is the current recommendation. The other options need an explicit compatibility decision, not an implementation undertaken to increase a mutation score.

## Required decisions before implementation

1. State whether callers may observe partial canonicalization after an exception. The present method mutates earlier sections before later validation fails. A copy-return design changes this behavior unless deliberately preserved.
2. State how references in the supplied array should behave. PHP copy-on-write does not automatically sever nested reference slots; copying the outer array alone is not a sufficient semantic design.
3. Choose whether direct by-reference post-call narrowing is part of the supported public static API, or whether callers should consistently use the existing typed `normalize()` result.

## Implementation and validation plan if precise output is approved

Start with a static consumer fixture using literal supported input and passing the post-call sections to functions requiring the advertised list/map types. Preserve that static RED before changing annotations. Add runtime public-contract cases for the chosen failure-state behavior, reference slots, invokable aliases and scalar/list delegators; preserve existing exception families without locking incidental wording.

Introduce typed intermediate results or typed section-returning helpers only as needed to express the selected contract. Keep validation order, callable ownership, alias-cycle rejection and resolver priority keys explicit. Do not add repeated reflection/autoload or factory materialization to shape validation.

Finish with PHP84/PHP85 targeted runtime tests, full-project PHPStan, configured style checks and the existing full suite. If the chosen design introduces extra copying, measure only the affected configuration-build path with representative large definitions before making performance claims. It does not justify changing warm container lookup.

## Reference

The annotation distinction is documented in [PHPStan PHPDocs Basics](https://phpstan.org/writing-php-code/phpdocs-basics): assertions narrow types, while `@param-out` describes a value written through a reference. The actual accepted fix and limits here are established by the installed analyzer logs, not by assuming that a documentation example proves the complete DI shape.
