import json,sys
x=json.load(open('/workspace/scratch/fa8384e69042/reaudit-round3/parameters/review.json'))
for e in x['survivors']:
 if not sys.argv[1:] or any(q in e['path'] for q in sys.argv[1:]):
  print(e['id'],e['path'],e['line'],e['mutator'])
  print('\n'.join(line for line in e['diff_context'].splitlines() if line.lstrip().startswith(('- ','+ '))))
