import datetime, hashlib, json, pathlib, sys

BASE = pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters')
ROOT = pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di')

def record(entries):
    path = BASE / 'review.json'
    doc = json.loads(path.read_text())
    ast = json.loads((BASE / 'test-declarations.json').read_text())
    for index, notes in entries.items():
        item = doc['files'][int(index) - 1]
        raw = (ROOT / item['path']).read_bytes()
        item['sha256'] = hashlib.sha256(raw).hexdigest()
        item['lines'] = len(raw.splitlines())
        item['review_status'] = 'read_in_full_afresh'
        item['reviewed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if isinstance(notes, str):
            item['analysis'] = notes
            continue
        declarations = ast[item['path']]['tests']
        assert len(notes) == len(declarations), (item['path'], len(notes), len(declarations))
        item['tests'] = []
        for decl, note in zip(declarations, notes):
            if isinstance(note, str):
                note = note.split(' | ')
            assert len(note) >= 3
            item['tests'].append({
                'line': decl['line'], 'end_line': decl['end_line'], 'name': decl['name'],
                'body_sha256': decl['body_sha256'], 'contract': note[0], 'actual_oracle': note[1],
                'meaningful_production_fault': note[2],
                'quality_finding': note[3] if len(note) > 3 else 'No material oracle defect established in this fresh review.',
                'dataset_edges': note[4] if len(note) > 4 else 'No dataset; fixture edges are described in the contract and oracle.',
                'fault_evidence': 'reasoned_counterexample_not_executed_RED',
            })
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n')

if __name__ == '__main__':
    record(json.load(sys.stdin))
