import pathlib,subprocess,os,json,hashlib,difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');iso=base/'isolated';root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');out=base/'eligibility-proof';out.mkdir(exist_ok=True);baseline='2eb36241787a971e1a8185149aaa08b90304d426';test='tests/Contract/FactoryClassAvailabilityContractTest.php'
def original(p):return subprocess.check_output(['git','show',baseline+':'+p],cwd=root,text=True)
t=original(test);strong=t+'''
#[\\Componenta\\DI\\Attribute\\NoConstructor]
interface IneligibleInterface {}

#[\\Componenta\\DI\\Attribute\\NoConstructor]
trait IneligibleTrait {}

#[\\Componenta\\DI\\Attribute\\NoConstructor]
abstract class IneligibleAbstract {}

#[\\Componenta\\DI\\Attribute\\NoConstructor]
enum IneligibleEnum
{
    case Value;
}

/** @param class-string $class */
test('implicit entries reject ineligible class kinds even when constructor policy would permit allocation', function (string $class): void {
    $container = (new ContainerBuilder())->build();
    $pipeline = $container->get(\\Componenta\\DI\\Object\\ObjectPipeline::class);

    expect($pipeline->canCreate(new \\ReflectionClass($class)))->toBeFalse()
        ->and($container->has($class))->toBeFalse()
        ->and(fn() => $container->get($class))->toThrow(\\Componenta\\DI\\Exception\\NotFoundException::class)
        ->and(fn() => $container->make($class))->toThrow(\\Componenta\\DI\\Exception\\NotFoundException::class);
})->with([
    'anonymous class' => [(new class () {})::class],
    'interface with constructor policy' => [IneligibleInterface::class],
    'trait with constructor policy' => [IneligibleTrait::class],
    'abstract class with constructor policy' => [IneligibleAbstract::class],
    'enum with constructor policy' => [IneligibleEnum::class],
]);
'''
paths=['src/Internal/functions.php','src/Object/ObjectPipeline.php']; originals={p:original(p) for p in paths}
f=originals[paths[0]];old='''if ($class->isAnonymous()
        || $class->isInterface()
        || $class->isTrait()
        || $class->isAbstract()
        || $class->isEnum()
    )''';assert f.count(old)==1
conds=[('16e3675d1baadf49','($class->isAnonymous() && $class->isInterface()) || $class->isTrait() || $class->isAbstract() || $class->isEnum()'),('bf8ecc7eb3275097','(($class->isAnonymous() || $class->isInterface()) && $class->isTrait()) || $class->isAbstract() || $class->isEnum()'),('4673ece5edb23559','(($class->isAnonymous() || $class->isInterface() || $class->isTrait()) && $class->isAbstract()) || $class->isEnum()'),('f596254bf44df6a4','($class->isAnonymous() || $class->isInterface() || $class->isTrait() || $class->isAbstract()) && $class->isEnum()')]
mutants=[(mid,paths[0],f.replace(old,'if ('+condition+')')) for mid,condition in conds]
needle='''    ) {
        return false;
    }

    return $class->isInstantiable()''';assert f.count(needle)==1
mutants.append(('9e7ce1a2b28df62a',paths[0],f.replace(needle,needle.replace('return false;','return true;'))))
p=originals[paths[1]];needle='''        if (!is_entry_class_eligible($metadata->class)) {
            return false;
        }''';assert p.count(needle)==1
mutants.append(('165273e57fdff011',paths[1],p.replace(needle,needle.replace('return false;',''))))
rows=[]
def run(label,src,prod,testtext,expected):
 for path,source in originals.items():(iso/path).write_text(source)
 if src:(iso/src).write_text(prod)
 (iso/test).write_text(testtext)
 for v in ['84','85']:
  ident=label+'-php'+v;prov=out/(ident+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov)
  r=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/(ident+'.log');log.write_text(r.stdout)
  rows.append({'phase':label,'php':v,'command':cmd,'cwd':str(iso),'exit_code':r.returncode,'output':r.stdout,'output_file':str(log),'source':src,'source_sha256':hashlib.sha256(prod.encode()).hexdigest() if src else None,'all_source_sha256':{path:hashlib.sha256((iso/path).read_bytes()).hexdigest() for path in paths},'test_sha256':hashlib.sha256(testtext.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(ident,r.returncode,r.stdout[-200:],flush=True);assert r.returncode==expected,ident
try:
 run('old-test-original',None,None,t,0)
 for mid,src,mutant in mutants:
  (out/(mid+'-mutant.patch')).write_text(''.join(difflib.unified_diff(originals[src].splitlines(True),mutant.splitlines(True),fromfile='a/'+src,tofile='b/'+src)))
  run(mid+'-old-test-mutant',src,mutant,t,0)
  run(mid+'-new-test-mutant',src,mutant,strong,1)
 run('new-test-original',None,None,strong,0)
finally:
 for path,source in originals.items():(iso/path).write_text(source)
 (iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':baseline,'records':rows},indent=2)+'\n')
 (out/'test.patch').write_text(''.join(difflib.unified_diff(t.splitlines(True),strong.splitlines(True),fromfile='a/'+test,tofile='b/'+test)))
