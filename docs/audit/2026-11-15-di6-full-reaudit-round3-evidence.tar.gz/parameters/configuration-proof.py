import pathlib, subprocess, os, json, hashlib, difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters')
iso=base/'isolated'; out=base/'configuration-proof'; out.mkdir(exist_ok=True)
src='src/Configuration/DependencyConfiguration.php'; test='tests/Contract/DependencyConfigurationContractTest.php'
s=(iso/src).read_text(); t=(iso/test).read_text()
fixture='''#[\\Attribute(\\Attribute::TARGET_CLASS)]
final class DependencyConfigurationMarker {}

final class DependencyConfigurationResolver implements \\Componenta\\DI\\Resolver\\Parameter\\ParameterResolverInterface
{
    public function supports(\\Componenta\\DI\\Resolver\\Target\\ParameterTarget $target): bool
    {
        return false;
    }

    public function resolveParameter(
        \\Componenta\\DI\\Resolver\\Target\\ParameterTarget $target,
        \\Componenta\\DI\\Resolver\\Parameter\\ParameterResolutionContext $context,
    ): ?array {
        return null;
    }
}

'''
strong=t.replace('test(\n',fixture+'test(\n',1)
needle="    'associative attribute definitions' => ["
extra="""    'invalid resolver after valid instance' => [
        [ConfigKey::PARAMETER_RESOLVERS => [100 => new DependencyConfigurationResolver(), 90 => new \\stdClass()]],
        'Parameter resolver specification must be an instance, callable, non-empty service id or [service-id, method]',
    ],
    'invalid resolver priority after valid instance' => [
        [ConfigKey::PARAMETER_RESOLVERS => [100 => new DependencyConfigurationResolver(), 'later' => new DependencyConfigurationResolver()]],
        'Parameter resolver priority must be int; got string',
    ],
"""
strong=strong.replace(needle,extra+needle)
needle="    'associative capability policies' => ["
extra="""    'invalid attribute definition after valid instance' => [
        [ConfigKey::ATTRIBUTE_DEFINITIONS => [
            new \\Componenta\\DI\\Attribute\\Composition\\AttributeDefinition(DependencyConfigurationMarker::class),
            new \\stdClass(),
        ]],
        'Attribute definition specification must be an instance, callable, non-empty service id or [service-id, method]',
    ],
"""
strong=strong.replace(needle,extra+needle)
mutations=[('acff8d220fe83337','ParameterResolverInterface'),('ede184da61b1fb43','AttributeDefinition')]
rows=[]
def run(label,source,testtext,expected):
 (iso/src).write_text(source); (iso/test).write_text(testtext)
 for version in ['84','85']:
  ident=label+'-php'+version; prov=out/(ident+'-provenance.json')
  cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result']
  env=os.environ.copy(); env['PARAMETERS_PROVENANCE_FILE']=str(prov)
  res=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/(ident+'.log')).write_text(res.stdout)
  p=json.loads(prov.read_text()) if prov.exists() else None
  row={'label':label,'php':version,'command':cmd,'cwd':str(iso),'exit_code':res.returncode,'output_file':str(out/(ident+'.log')),'output':res.stdout,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'test_sha256':hashlib.sha256(testtext.encode()).hexdigest(),'provenance':p}
  rows.append(row)
  print(ident,res.returncode,res.stdout[-650:])
  assert res.returncode==expected, ident
  assert p and p['eager_functions'] and 'Componenta\\DI\\Configuration\\DependencyConfiguration' in p['loaded_classes'],ident
try:
 run('old-test-original',s,t,0)
 for mid,kind in mutations:
  variable='$resolver' if kind=='ParameterResolverInterface' else '$definition'
  needle=f'if ({variable} instanceof {kind}) {{\n                continue;\n            }}'
  assert s.count(needle)==1
  mutant=s.replace(needle,needle.replace('continue;','break;'))
  (out/(mid+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),mutant.splitlines(True),fromfile='a/'+src,tofile='b/'+src)))
  run(mid+'-old-test-mutant',mutant,t,0)
  run(mid+'-new-test-mutant',mutant,strong,1)
 run('new-test-original',s,strong,0)
finally:
 (iso/src).write_text(s); (iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':'2eb36241787a971e1a8185149aaa08b90304d426','mutant_ids':[x[0] for x in mutations],'records':rows},indent=2)+'\n')
 (out/'test.patch').write_text(''.join(difflib.unified_diff(t.splitlines(True),strong.splitlines(True),fromfile='a/'+test,tofile='b/'+test)))
