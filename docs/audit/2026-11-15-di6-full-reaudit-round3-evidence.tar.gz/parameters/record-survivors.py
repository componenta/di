import json,pathlib,sys,datetime
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');p=b/'review.json';d=json.loads(p.read_text());byid={x['id']:x for x in d['survivors']}
for ids,verdict,reason,anchors,*evidence in json.load(sys.stdin):
 for mid in ids.split():
  row=byid[mid]; row.update(review_status='classified_afresh',verdict=verdict,contract_reachability=reason,code_anchor={'path':row['path'],'line':row['line']},test_anchors=[],evidence_status='source_and_test_reasoning_not_executed_mutant')
  for anchor in anchors:
   if isinstance(anchor,dict):
    row['test_anchors'].append(anchor);continue
   fileindex,testindex=anchor
   f=d['files'][fileindex-1];test=f.get('tests',[])[testindex-1];row['test_anchors'].append({'path':f['path'],'line':test['line'],'name':test['name']})
  if evidence:
   row['executed_evidence']=evidence[0];row['evidence_status']='executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('classified',sum(x.get('review_status')=='classified_afresh' for x in d['survivors']),'of',len(d['survivors']))
