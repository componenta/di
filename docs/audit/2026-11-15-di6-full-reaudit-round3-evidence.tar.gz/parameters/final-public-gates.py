import pathlib,subprocess,json,hashlib,difflib,os
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');iso=base/'isolated'
# Reuse only the literal baseline source/mutant definitions, not their prior results.
namespace={};exec((base/'eligibility-proof.py').read_text().split('rows=[]')[0],namespace)
originals=namespace['originals'];mutants=namespace['mutants'];test=namespace['test'];strong=(root/test).read_text();out=base/'eligibility-proof'/'trait-consumer-final';out.mkdir(exist_ok=True)
rows=[]
def proof(label,src=None,prod=None,expected=0):
 for path,text in originals.items():(iso/path).write_text(text)
 if src:(iso/src).write_text(prod)
 (iso/test).write_text(strong)
 for version in ['84','85']:
  ident=label+'-php'+version;prov=out/(ident+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov)
  r=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/(ident+'.log');log.write_text(r.stdout)
  rows.append({'phase':label,'php':version,'command':cmd,'cwd':str(iso),'exit_code':r.returncode,'output_file':str(log),'output':r.stdout,'mutated_source':src,'source_sha256':{p:hashlib.sha256((iso/p).read_bytes()).hexdigest() for p in originals},'test':test,'test_sha256':hashlib.sha256(strong.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(ident,r.returncode,r.stdout[-180:],flush=True)
  assert r.returncode==expected,ident
  assert prov.exists(),ident+' missing origin evidence'
try:
 proof('new-test-control')
 for mid,src,prod in mutants:proof(mid+'-new-test-mutant',src,prod,1)
 proof('new-test-restored')
finally:
 for path,text in originals.items():(iso/path).write_text(text)
 (iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':namespace['baseline'],'reason':'Whole-project PHPStan trait.unused in newly introduced test fixture. Named concrete trait consumer plus supported-class positive control; production unchanged. Prior old-test GREEN records remain in ../results.json; all final new-test mutants rerun here.','records':rows},indent=2)+'\n')
paths=['tests/Contract/FactoryClassAvailabilityContractTest.php','tests/Contract/DependencyConfigurationContractTest.php','tests/Contract/StandaloneContainerContractTest.php'];out=base/'public-seams-proof';rows=[]
commands=[(f'green-php{v}',[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',*paths,'--compact','--colors=never','--do-not-cache-result']) for v in ['84','85']]
commands += [('cs',['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n','vendor/bin/php-cs-fixer','fix','--config=.php-cs-fixer.dist.php','--dry-run','--diff','--using-cache=no',*paths]),('phpstan-full',['/workspace/scratch/8f6c1df8ef3b/runtime/php84/php','-n','vendor/bin/phpstan','analyse','src','tests','--level=max','--no-progress','--memory-limit=1G'])]
try:
 for label,cmd in commands:
  r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/('final-main-'+label+'.log');log.write_text(r.stdout)
  rows.append({'label':label,'command':cmd,'cwd':str(root),'exit_code':r.returncode,'output_file':str(log),'output':r.stdout,'test_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'main_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()});print(label,r.returncode,r.stdout[-1500:],flush=True)
  assert r.returncode==0,label
finally:
 (out/'final-main-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 for p in paths:
  before=subprocess.check_output(['git','show','HEAD:'+p],cwd=root,text=True)
  (out/(pathlib.Path(p).stem+'-main.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),(root/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
