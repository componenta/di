import pathlib,json,hashlib,subprocess,collections,datetime
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');r=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');p=b/'review.json';d=json.loads(p.read_text());ast=json.loads((b.parent/'final-test-declarations.json').read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest();baseline='2eb36241787a971e1a8185149aaa08b90304d426';frozen='141feff3d4747a70a2d4ac4c3841de53eb55fa73'
for f in d['files']:
 raw=(r/f['path']).read_bytes();f.setdefault('baseline_sha256',f['sha256']);f['sha256']=sha(raw);f['lines']=len(raw.splitlines());f['initial_full_read_snapshot']=baseline;f['current_source_test_snapshot']=frozen
 if f['path'] in ast:
  a=ast[f['path']];assert f['sha256']==a['sha256'],f['path'];decl={t['name']:t for t in a['tests']};assert len(decl)==len(f['tests']),f['path']
  for t in f['tests']:
   assert t['name'] in decl;t.update({k:decl[t['name']][k] for k in ['line','end_line','body_sha256']})
  assert all(all(t.get(k) for k in ['contract','actual_oracle','meaningful_production_fault','quality_finding','dataset_edges']) for t in f['tests']),f['path']
 f['delta_review']='Baseline file was read in full afresh; current source/test edits were inspected separately.' if f['sha256']!=f['baseline_sha256'] else 'Unchanged from freshly read baseline.'
def testcase(path,name):return next(t for f in d['files'] if f['path']==path for t in f['tests'] if t['name']==name)
def ap(path):return str(b/path)
links=[
('tests/Contract/DependencyConfigurationContractTest.php','container factory rejects invalid dependency definitions at its public boundary',['acff8d220fe83337','ede184da61b1fb43'],'configuration-proof/results.json'),
('tests/Contract/RuntimeMutationRecoveryContractTest.php','a service cycle inside a Fiber reports the complete chain and permits recovery',['87fa7a782e3b546c','91ce753c5495667b','c984b4652b0940d5'],'state-proof/results.json'),
('tests/Contract/EntryCachePublicationContractTest.php','a suspended source cannot republish its base after a new definition is installed',['3b72a5fed56f647f','036d2689b2bbe2ab'],'state-proof/results.json'),
('tests/Contract/EntryCacheIsolationContractTest.php','null and false factory results remain shared through warmed aliases',['ec3a27adcd137792'],'numeric-proof/results.json'),
('tests/Contract/AliasPipelineInvalidationContractTest.php','changing one alias pipeline preserves independent shared decorations',['645741cb54a634ec'],'numeric-proof/results.json'),
('tests/Contract/FactoryClassAvailabilityContractTest.php','implicit entries reject ineligible class kinds even when constructor policy would permit allocation',['16e3675d1baadf49','bf8ecc7eb3275097','4673ece5edb23559','f596254bf44df6a4','9e7ce1a2b28df62a','165273e57fdff011'],'eligibility-proof/results.json'),
('tests/Contract/FactoryClassAvailabilityContractTest.php','implicit entries can create concrete consumers of traits',['bespoke:reject-concrete-trait-consumers'],'eligibility-proof/trait-positive-oracle/results.json'),
('tests/Contract/DependencyConfigurationContractTest.php','shape validation canonicalizes the caller dependency array by reference',['029be1b769417bfb','f4368db14107b8c1'],'public-seams-proof/final-semantic-shape/results.json'),
('tests/Contract/DependencyConfigurationContractTest.php','direct shape validation rejects malformed alias graphs and empty delegator specifications',['79f85603282597fb','fd7122208c0e83b4'],'public-seams-proof/final-semantic-shape/results.json'),
('tests/Contract/StandaloneContainerContractTest.php','standalone lazy and proxy creation uses the supplied proxy factory',['62799d36f56971f5'],'public-seams-proof/results.json'),
]
proof_links=[]
for path,name,ids,proof in links:
 t=testcase(path,name);t['fault_evidence']='executed_old_GREEN_new_RED_restored_GREEN_PHP84_PHP85';t['fault_ids']=ids;t['executed_evidence']=ap(proof)
 link={'test_path':path,'declaration_name':name,'current_line':t['line'],'current_body_sha256':t['body_sha256'],'fault_ids':ids,'canonical_proof_path':ap(proof),'proof_sha256':sha((b/proof).read_bytes()),'execution_kind':'Pest_runtime_mutant_oracle'}
 if path.endswith('AliasPipelineInvalidationContractTest.php'):
  link['final_preserved_variant_proof']=str(b.parent/'preserved-variants-proof/proof.json');t['final_variant_evidence']=link['final_preserved_variant_proof'];t['dataset_edges']='Three mutations (append delegator, replace deferred decorator, retarget alias) crossed with original inline sibling decorator, ordinary deferred ID and numeric-string deferred ID: nine cases. Root restored the original inline variant while retaining both new deferred-ID witnesses.'
 if name.startswith('implicit entries reject'):
  link['final_fixture_proof']=ap('eligibility-proof/trait-consumer-final/results.json');link['delegated_catalogue_fault_ids']=['165273e57fdff011'];t['final_fixture_evidence']=link['final_fixture_proof']
 if proof.startswith('public-seams-proof/final'):
  link['old_test_GREEN_proof']=ap('public-seams-proof/results.json')
 if name.startswith('shape validation canonicalizes'):
  t['static_analysis_evidence']=[ap('shape-contract-static-proof/red.json'),ap('shape-contract-static-proof/green-gates.json')]
 if name.startswith('implicit entries can create'):
  t['static_analysis_evidence']=[str(b.parent/'core/object-pipeline-generic-proof/proof.json')]
 proof_links.append(link)
neg=testcase('tests/Contract/DependencyConfigurationContractTest.php','direct shape validation rejects malformed alias graphs and empty delegator specifications')
neg['actual_oracle']='Pest toThrow checks compatible exception class only: CircularDependencyException for a cycle; InvalidConfigurationException for malformed alias mappings and empty delegator string. Equivalent validation wording is intentionally accepted.'
neg['meaningful_production_fault']='Omit direct alias-cycle validation or admit an empty delegator specification so no required exception is thrown.'
neg['quality_finding']='Final exact79f85603282597fb and fd7122208c0e83b4 mutants are RED on PHP84/85, then restored GREEN. Three earlier alias-message-only REDs were rejected during root review and superseded; no semantic defect is attributed to alternative wording.'
neg['dataset_edges']='Five variants separately cover numeric alias key, empty alias key, non-string alias target, two-node cycle and empty delegator. The cycle uses a distinct exception family; no diagnostic text is fixed by this test.'
out=testcase('tests/Contract/DependencyConfigurationContractTest.php','shape validation canonicalizes the caller dependency array by reference')
out['quality_finding']='Exact029be1b769417bfb and f4368db14107b8c1 mutants fail independent normalized array equality; old selected tests pass and restored production passes on PHP84/85. Separately, the same valid literal input exposed an inaccurate PHPStan assertion; static RED/GREEN is not a runtime RED.'
# Resolve all current anchors to the frozen AST; retain the catalogue location separately.
line_one={
 'tests/V5/ProxyCompositionRegressionTest.php':'Proxy cannot compete with another value source on one injection point',
 'tests/V5/DeferredExtensionSpecificationTest.php':'container factory materializes deferred attribute and parameter resolver service methods',
 'tests/Contract/MagicCallableSyntaxContractTest.php':'string and array callable syntax preserve magic arguments',
 'tests/Contract/CallableCacheParityContractTest.php':'warm callable cache preserves binding and complete native signatures across all callable forms',
}
def anchor(path,name):
 t=next(t for t in ast[path]['tests'] if t['name']==name);return {'path':path,'line':t['line'],'name':name,'coverage_relation':'Related existing contract; reachability verdict does not claim this test kills the mutant unless execution evidence is linked.'}
def own(i,j):
 f=d['files'][i-1];t=f['tests'][j-1];return {'path':f['path'],'line':t['line'],'name':t['name'],'coverage_relation':'Related contract anchor; executed status is stated separately.'}
for s in d['survivors']:
 s['catalogue_line']=s['line'];s['catalogue_source_sha256']=s['source_sha256'];s['current_source_sha256']=sha((r/s['path']).read_bytes());s['code_anchor']['line']=s['line']+(2 if s['path']=='src/Configuration/DependencyConfiguration.php' and s['line']>=108 else 0);s['code_anchor']['snapshot']=frozen
 fresh=[]
 for a in s['test_anchors']:
  path=a['path'];name=a['name']
  if path=='tests/Contract/CompositionConfigurationContractTest.php' and a['line']==53:
   path='tests/Contract/DependencyNormalizationContractTest.php';name='normalization rejects cycles formed by combining default and configured aliases'
  if a['line']==1 and path in line_one:name=line_one[path]
  if path.startswith('src/'):
   a['line']=70 if path=='src/Attribute/Composition/AttributeUsage.php' else a['line'];s.setdefault('additional_code_anchors',[]).append(a);continue
  if path in ast:
   match=next((t for t in ast[path]['tests'] if t['name']==name),None)
   if match:a={'path':path,'line':match['line'],'name':name}
   else:
    match=next((t for t in ast[path]['tests'] if t['line']==a['line']),None)
    assert match,(s['id'],a);a={'path':path,'line':match['line'],'name':match['name']}
  a['coverage_relation']='Executed exact mutant proof is linked separately; otherwise this is a related contract anchor, not proof that the existing test detects the mutant.';fresh.append(a)
 s['test_anchors']=fresh
 if s.get('executed_evidence') and not pathlib.Path(s['executed_evidence']).is_absolute():s['executed_evidence']=ap(s['executed_evidence'])
 if s['id'] in ['79f85603282597fb','029be1b769417bfb','f4368db14107b8c1','fd7122208c0e83b4']:
  s['executed_evidence']=ap('public-seams-proof/final-semantic-shape/results.json');s['old_test_GREEN_evidence']=ap('public-seams-proof/results.json')
 if s['id'] in ['d20c9fa5da4157f0','5d2a0001799a65c6','30a1f8a8517cda48']:
  s.pop('executed_evidence',None);s['evidence_status']='alternative_validation_reasoning_prior_message_only_RED_superseded';s['superseded_evidence']={'path':ap('public-seams-proof/results.json'),'exclusion_record':ap('public-seams-proof/final-semantic-shape/superseded-alias-message-only.json'),'reason':'Compatible exception rejection remains; wording-only oracle rejected by root review.'}
 if s['id']=='a96826a52bb8b773':s['test_anchors']=[own(67,5),own(67,6),own(66,1)]
 if s['id'] in ['1c99094190e8fbe0','71fb2f3fb66a7bb4','fd99d4f9a8bb7ae4']:s['test_anchors']=[own(67,4),own(67,7)]
 if s['id'] in ['287d4e947536bc02','c07540ab1a704f12']:s['test_anchors']=[own(70,2),own(72,4)]
 if s['id']=='963ffa19a7476473':s['test_anchors']=[own(72,4),anchor('tests/Contract/CallableCacheParityContractTest.php',line_one['tests/Contract/CallableCacheParityContractTest.php'])]
 if s['id']=='2038b1d37cee3ee1':s['test_anchors']=[own(92,1),own(92,2),own(72,3)]
 if s['id'] in ['b89cc12eb2a91793','963c5d2af0c1d976','b9147261359e2416']:s['test_anchors']=[own(72,3),own(95,1)]
 if s['id']=='b5c27cd6818cdd68':s['test_anchors']=[own(71,1),own(70,1),own(92,1)]
 assert s['review_status']=='classified_afresh' and s['test_anchors'],s['id']
 assert all(a['line']>1 for a in s['test_anchors']),s['id']
d['executed_evidence']=proof_links
d['static_analysis_evidence']=[{'finding':'assertShape inaccurate type assertion','red':ap('shape-contract-static-proof/red.json'),'green':ap('shape-contract-static-proof/green-gates.json'),'kind':'PHPStan consumer/type-contract RED and full-project GREEN, not a runtime mutation kill'},{'finding':'ObjectPipeline concrete ReflectionClass generic input','proof':str(b.parent/'core/object-pipeline-generic-proof/proof.json'),'owner':'core_audit','kind':'PHPStan static RED/GREEN, separate from the trait positive runtime mutant'}]
d['findings']=[
 {'id':'R3-PARAM-MIXED-LIST','kind':'test_oracle_gap_fixed','declarations':[proof_links[0]],'result':'Mixed valid/invalid extension lists now preserve section/priority diagnostic specificity; not a claim that old production accepted an exploit.'},
 {'id':'R3-PARAM-FIBER-STACK','kind':'test_oracle_gap_fixed','declarations':[proof_links[1]],'result':'Completed leaf resolution before a cycle now witnesses exact Fiber stack unwinding and recovery.'},
 {'id':'R3-PARAM-BASE-ABA','kind':'test_oracle_gap_fixed','declarations':[proof_links[2]],'result':'Definition replacement followed by raw override now exposes ABA in mixed base-revision operations.'},
 {'id':'R3-PARAM-NUMERIC-IDS','kind':'test_oracle_gap_fixed','declarations':[proof_links[3],proof_links[4]],'result':'Numeric-string array-key coercion now participates in cache and alias/deferred invalidation tests; original inline variant retained by root.'},
 {'id':'R3-PARAM-ELIGIBILITY','kind':'test_oracle_gap_fixed','declarations':[proof_links[5],proof_links[6]],'result':'Negative kind matrix and positive concrete trait consumer distinguish class eligibility from constructor policy.'},
 {'id':'R3-PARAM-PROXY-SEAM','kind':'test_oracle_gap_fixed','declarations':[proof_links[9]],'result':'Standalone Container must use its supplied ProxyFactoryInterface for both public factory methods.'},
 {'id':'R3-PARAM-SHAPE','kind':'test_oracle_gap_fixed','declarations':[proof_links[7],proof_links[8]],'result':'Direct by-reference canonicalization, cycle rejection and empty delegator rejection now have independent semantic witnesses. Alias wording-only differences are excluded.'},
 {'id':'R3-PARAM-SHAPE-PHPDOC','kind':'static_public_contract_bug_fixed','source':'src/Configuration/DependencyConfiguration.php','result':'Removed false phpstan-assert from a mutating canonicalizer. Valid literal input now passes static analysis. normalize() remains the typed-result API; runtime behavior is unchanged.','proof':d['static_analysis_evidence'][0],'plan':ap('precise-byref-typing-plan.md')},
 {'id':'R3-PARAM-INTRODUCED-TRAIT-GATE','kind':'introduced_test_gate_failure_fixed','result':'New trait fixture was unused under whole-project PHPStan although targeted analysis passed. Named concrete consumer and independently proven positive contract fixed it without suppression. CI failure is not a production runtime bug.','failure_jobs':['132802853302','132802853019','132802853369'],'final_gate':ap('public-seams-proof/final-main-checks.json')}
]
d['exclusions_and_limits']=[
 {'path':ap('public-seams-failed-control'),'reason':'Initial negative cycle control incorrectly expected InvalidConfigurationException inheritance; corrected before accepting mutation evidence.'},
 {'path':ap('public-seams-proof/results.json'),'reason':'Anonymous ProxyFactory fixture produced control exit255 in strict DI source-origin guard after assertions; named test fixture restored valid control. Failed control explicitly excluded.'},
 {'path':ap('public-seams-proof/final-semantic-shape/superseded-alias-message-only.json'),'reason':'Six PHP84/85 rows for three alias mutants observed only diagnostic wording. Superseded, not counted as semantic kills.'},
 {'path':ap('state-proof/main-checks.json'),'reason':'First CS multiple-path invocation lacked explicit config and returned tool-usage exit16; corrected CS passed. Not a semantic RED.'},
 {'path':ap('native-reflection-boundaries-notes.json'),'reason':'Native-only reflection experiments are supporting metadata evidence, not DI mutant tests; failed exploratory invocations are not semantic RED.'},
 {'reason':'Reasoned counterexamples and architecture decisions are not confirmed current-production bugs, executed REDs, timing measurements or a proof that all vulnerabilities are absent.'},
 {'reason':'Manual scoped security review only; no completed Codex Security plugin scan is claimed.'}
]
d['current_snapshot_head']=frozen;d['repository_observed_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();d['current_worktree_note']='Assigned src/tests hashes match final AST at141feff. Subsequent documentation/harness commits are outside this assigned manifest; no source/test reruns are invented.'
d['final_ast_reference']={'path':str(b.parent/'final-test-declarations.json'),'sha256':sha((b.parent/'final-test-declarations.json').read_bytes())}
d['scope_summary']={'assigned_files':96,'production_files':31,'test_and_support_files':65,'fresh_full_file_reads':96,'baseline_declarations':205,'current_declarations':210,'reviewed_current_declarations':210,'catalogued_survivor_ids':223,'classified_survivor_ids':223,'verdict_counts':dict(collections.Counter(s['verdict'] for s in d['survivors'])),'accepted_exact_catalogue_mutants_owned':19,'accepted_exact_catalogue_mutants_delegated':1,'accepted_bespoke_runtime_mutants':1,'superseded_message_only_mutant_ids':3,'executed_runtime_declarations':len(proof_links),'counts_are_ids_not_distinct_bugs':True,'assertions_across_runs_are_not_summed':True}
d['finalized_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['supporting_reports']=[ap('domain-conclusions.md'),ap('precise-byref-typing-plan.md')]
assert sum(len(f['tests']) for f in d['files'])==210 and len(d['survivors'])==223
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(b/'scope-summary.json').write_text(json.dumps({'manifest':str(p),'manifest_sha256':sha(p.read_bytes()),**d['scope_summary'],'snapshot':frozen,'final_ast_reference':d['final_ast_reference']},indent=2)+'\n')
print(json.dumps(d['scope_summary'],indent=2))
