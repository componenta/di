import pathlib,subprocess,json,hashlib,re
b=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');r=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');o=b/'immutable-test-snapshots';o.mkdir(exist_ok=True);base='2eb36241787a971e1a8185149aaa08b90304d426';items={}
def capture(text,origin):
 h=hashlib.sha256(text.encode()).hexdigest();p=o/(h+'.php');p.write_text(text);items.setdefault(h,{'path':str(p),'origins':[]})['origins'].append(origin);return text
def original(path,commit=base):return subprocess.check_output(['git','show',commit+':'+path],cwd=r,text=True)
def apply(text,patch):
 src=text.splitlines(True);out=[];pos=0;ls=patch.splitlines(True);i=0
 while i<len(ls):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+\d+(?:,\d+)? @@',ls[i])
  if not m:i+=1;continue
  start=int(m[1])-1;out+=src[pos:start];pos=start;i+=1
  while i<len(ls) and not ls[i].startswith('@@ '):
   line=ls[i]
   if line.startswith('--- ') or line.startswith('+++ '):break
   if line.startswith(' '):assert src[pos]==line[1:];out.append(src[pos]);pos+=1
   elif line.startswith('-'):assert src[pos]==line[1:];pos+=1
   elif line.startswith('+'):out.append(line[1:])
   i+=1
 out+=src[pos:];return ''.join(out)
paths=['tests/Contract/DependencyConfigurationContractTest.php','tests/Contract/RuntimeMutationRecoveryContractTest.php','tests/Contract/EntryCachePublicationContractTest.php','tests/Contract/EntryCacheIsolationContractTest.php','tests/Contract/AliasPipelineInvalidationContractTest.php','tests/Contract/FactoryClassAvailabilityContractTest.php','tests/Contract/StandaloneContainerContractTest.php']
for path in paths:
 capture(original(path),{'git_commit':base,'test_path':path});capture((r/path).read_text(),{'git_commit':'141feff3d4747a70a2d4ac4c3841de53eb55fa73','test_path':path})
patches=[('configuration-proof/test.patch',paths[0]),('state-proof/fiber-stack-test.patch',paths[1]),('state-proof/base-revision-test.patch',paths[2]),('numeric-proof/ec3a27adcd137792-test.patch',paths[3]),('numeric-proof/645741cb54a634ec-test.patch',paths[4]),('eligibility-proof/test.patch',paths[5]),('public-seams-proof/shape-test.patch',paths[0]),('public-seams-proof/proxy-test.patch',paths[6])]
for patch,path in patches:
 t=capture(apply(original(path),(b/patch).read_text()),{'baseline':base,'test_path':path,'patch':str(b/patch)})
 if patch=='eligibility-proof/test.patch':capture(apply(t,(b/'eligibility-proof/final-annotation-only.patch').read_text()),{'baseline_patch':patch,'followup_patch':'eligibility-proof/final-annotation-only.patch'})
 if patch=='public-seams-proof/shape-test.patch':capture(t.replace("function (array $dependencies, string $message, string $exception = InvalidConfigurationException::class): void {\n", "function (array $dependencies, string $message, string $exception = InvalidConfigurationException::class): void {\n    /** @var class-string<\\Throwable> $exception */\n"),{'source':'Initial shape runtime proof plus static-analysis-only class-string annotation, before root semantic-oracle review'})
# Restore the exact initial positive-control ordering used by trait-consumer-final;
# the final independently proven positive declaration evaluates canCreate before get.
t=(r/paths[5]).read_text();needle='''    expect($pipeline->canCreate(new \\ReflectionClass(EligibleTraitConsumer::class)))->toBeTrue()
        ->and($container->has(EligibleTraitConsumer::class))->toBeTrue();

    $shared = $container->get(EligibleTraitConsumer::class);
    $fresh = $container->make(EligibleTraitConsumer::class);

    expect($shared)->toBeInstanceOf(EligibleTraitConsumer::class)''';replacement='''    $shared = $container->get(EligibleTraitConsumer::class);
    $fresh = $container->make(EligibleTraitConsumer::class);

    expect($pipeline->canCreate(new \\ReflectionClass(EligibleTraitConsumer::class)))->toBeTrue()
        ->and($container->has(EligibleTraitConsumer::class))->toBeTrue()
        ->and($shared)->toBeInstanceOf(EligibleTraitConsumer::class)''';assert t.count(needle)==1;capture(t.replace(needle,replacement).replace('$pipeline = $container->get(\\Componenta\\DI\\Object\\ObjectPipeline::class);\n\n    $shared','$pipeline = $container->get(\\Componenta\\DI\\Object\\ObjectPipeline::class);\n    $shared'),{'source':'Reconstructed initial trait-consumer control from final bytes; hash must match recorded executed proof'})
records=[];missing=[]
for name in ['configuration-proof/results.json','state-proof/results.json','numeric-proof/results.json','eligibility-proof/results.json','eligibility-proof/trait-consumer-final/results.json','eligibility-proof/trait-positive-oracle/results.json','public-seams-proof/results.json','public-seams-proof/final-semantic-shape/results.json']:
 j=json.loads((b/name).read_text())
 for row in j['records']:
  if row.get('excluded_from_semantic_evidence'):continue
  h=row['test_sha256'];log=pathlib.Path(row['output_file']);assert log.exists(),str(log);assert log.read_text()==row['output'],str(log);assert row['provenance'] is not None,name
  if h not in items:missing.append({'proof':name,'phase':row.get('phase',row.get('label')),'sha256':h})
  records.append({'proof':name,'phase':row.get('phase',row.get('label')),'php':row['php'],'test_sha256':h,'snapshot':items.get(h,{}).get('path'),'output_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'output_file':str(log)})
result={'purpose':'Immutable exact test-file preimages for accepted isolated runtime proof rows; hash-verified reconstruction from recorded patches or git snapshots. This does not rerun any tests or mutate production.','snapshots':items,'accepted_proof_rows':records,'missing_test_preimages':missing};(o/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'snapshots':len(items),'accepted_rows':len(records),'missing':missing},indent=2));assert not missing
