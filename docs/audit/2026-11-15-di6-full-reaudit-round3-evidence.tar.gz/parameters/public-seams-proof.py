import pathlib,subprocess,os,json,hashlib,difflib
base=pathlib.Path('/workspace/scratch/fa8384e69042/reaudit-round3/parameters');iso=base/'isolated';root=pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di');out=base/'public-seams-proof';out.mkdir(exist_ok=True);baseline='2eb36241787a971e1a8185149aaa08b90304d426'
def original(p):return subprocess.check_output(['git','show',baseline+':'+p],cwd=root,text=True)
groups=[]
src='src/Configuration/DependencyConfiguration.php';test='tests/Contract/DependencyConfigurationContractTest.php';s=original(src);t=original(test);strong=(root/test).read_text()+'''
test('shape validation canonicalizes the caller dependency array by reference', function (): void {
    $delegator = static fn(object $entry): object => $entry;
    $dependencies = [
        ConfigKey::INVOKABLES => ['alias' => new \\Componenta\\DI\\Definition\\InvokableDefinition(\\stdClass::class)],
        ConfigKey::DELEGATORS => ['product' => $delegator],
    ];

    \\Componenta\\DI\\Configuration\\DependencyConfiguration::assertShape($dependencies);

    expect($dependencies)->toBe([
        ConfigKey::INVOKABLES => [\\stdClass::class],
        ConfigKey::DELEGATORS => ['product' => [$delegator]],
        ConfigKey::ALIASES => ['alias' => \\stdClass::class],
    ]);
});

/** @param array<array-key,mixed> $dependencies */
test('direct shape validation rejects malformed alias graphs and empty delegator specifications', function (array $dependencies, string $message, string $exception = InvalidConfigurationException::class): void {
    expect(static function () use (&$dependencies): void {
        \\Componenta\\DI\\Configuration\\DependencyConfiguration::assertShape($dependencies);
    })->toThrow($exception, $message);
})->with([
    'numeric alias key' => [[ConfigKey::ALIASES => [7 => 'entry']], 'Aliases must map non-empty string ids'],
    'empty alias key' => [[ConfigKey::ALIASES => ['' => 'entry']], 'Aliases must map non-empty string ids'],
    'non-string alias target' => [[ConfigKey::ALIASES => ['alias' => 7]], 'Aliases must map non-empty string ids'],
    'cyclic aliases' => [[ConfigKey::ALIASES => ['first' => 'second', 'second' => 'first']], 'Circular alias reference', \\Componenta\\DI\\Exception\\CircularDependencyException::class],
    'empty delegator specification' => [[ConfigKey::DELEGATORS => ['entry' => '']], 'Invalid delegator for "entry": string.'],
]);
'''
old="if (!is_string($alias) || $alias === '' || !is_string($target) || $target === '') {"
mutants=[('d20c9fa5da4157f0',s.replace(old,"if ((!is_string($alias) && $alias === '') || !is_string($target) || $target === '') {")),('5d2a0001799a65c6',s.replace(old,"if ((!is_string($alias) || $alias === '') && !is_string($target) || $target === '') {")),('30a1f8a8517cda48',s.replace(old,old.replace("$alias === ''","$alias === 'PEST Mutator was here!'"))),('79f85603282597fb',s.replace('            self::assertAliasesAcyclic($aliases);','')),('029be1b769417bfb',s.replace('if ($delegators !== []) {','if (!($delegators !== [])) {')),('f4368db14107b8c1',s.replace('if ($delegators !== []) {','if ($delegators === []) {')),('fd7122208c0e83b4',s.replace("if (is_string($delegator) && $delegator !== '') {","if (is_string($delegator) && $delegator !== 'PEST Mutator was here!') {"))]
groups.append(('shape',src,test,s,t,strong,mutants))
src='src/Container.php';test='tests/Contract/StandaloneContainerContractTest.php';s=original(src);t=original(test);strong=t+'''
final class StandaloneProxyProduct
{
    public string $value = 'default';
}

final class StandaloneProxyFactory implements \\Componenta\\DI\\ProxyFactoryInterface
{
    /** @var list<string> */
    public array $calls = [];

    /**
     * @template T of object
     * @param class-string<T> $class
     * @param callable(T):void $initializer
     * @return T
     */
    public function makeLazy(string $class, callable $initializer): object
    {
        $this->calls[] = 'lazy';
        return (new \\Componenta\\DI\\ProxyFactory())->makeLazy($class, $initializer);
    }

    /**
     * @template T of object
     * @param class-string<T> $class
     * @param callable(T):T $factory
     * @return T
     */
    public function makeProxy(string $class, callable $factory): object
    {
        $this->calls[] = 'proxy';
        return (new \\Componenta\\DI\\ProxyFactory())->makeProxy($class, $factory);
    }
}

test('standalone lazy and proxy creation uses the supplied proxy factory', function (): void {
    $factory = new StandaloneProxyFactory();
    $container = new Container(
        new StandaloneEntryResolver(),
        new AliasResolver(),
        (new ContainerBuilder())->build(),
        proxyFactory: $factory,
    );
    $lazy = $container->makeLazy(StandaloneProxyProduct::class, static function (StandaloneProxyProduct $entry): void {
        $entry->value = 'initialized';
    });
    $proxy = $container->makeProxy(StandaloneProxyProduct::class, static function (): StandaloneProxyProduct {
        $entry = new StandaloneProxyProduct();
        $entry->value = 'factory';
        return $entry;
    });

    expect($factory->calls)->toBe(['lazy', 'proxy'])
        ->and($lazy->value)->toBe('initialized')
        ->and($proxy->value)->toBe('factory');
});
'''
old='$this->proxyFactory = $proxyFactory ?? new ProxyFactory();';assert s.count(old)==1;mutants=[('62799d36f56971f5',s.replace(old,'$this->proxyFactory = new ProxyFactory();'))];groups.append(('proxy',src,test,s,t,strong,mutants))
rows=json.loads((out/'results.json').read_text())['records']
rows[-1]['excluded_from_semantic_evidence']='Control exit255 after assertions: anonymous DI-interface fixture was classified as DI production by origin guard. Replaced by explicitly namespaced fixture; no mutant result accepted.'
def run(g,label,prod,testtext,expected):
 name,src,test,s,t,strong,mutants=g;(iso/src).write_text(prod);(iso/test).write_text(testtext)
 for v in ['84','85']:
  ident=name+'-named-fixture-'+label+'-php'+v;prov=out/(ident+'-provenance.json');cmd=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{v}/php','-n','vendor/bin/pest',test,'--compact','--colors=never','--do-not-cache-result'];env=os.environ.copy();env['PARAMETERS_PROVENANCE_FILE']=str(prov)
  r=subprocess.run(cmd,cwd=iso,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=out/(ident+'.log');log.write_text(r.stdout);rows.append({'group':name,'phase':label,'php':v,'command':cmd,'cwd':str(iso),'exit_code':r.returncode,'output':r.stdout,'output_file':str(log),'source':src,'test':test,'source_sha256':hashlib.sha256(prod.encode()).hexdigest(),'test_sha256':hashlib.sha256(testtext.encode()).hexdigest(),'provenance':json.loads(prov.read_text()) if prov.exists() else None});print(ident,r.returncode,r.stdout[-250:],flush=True);assert r.returncode==expected,ident
try:
 for g in groups[1:]:
  name,src,test,s,t,strong,mutants=g
  (out/(name+'-test.patch')).write_text(''.join(difflib.unified_diff(t.splitlines(True),strong.splitlines(True),fromfile='a/'+test,tofile='b/'+test)))
  run(g,'old-test-original',s,t,0)
  run(g,'new-test-control',s,strong,0)
  for mid,mutant in mutants:
   assert mutant!=s
   (out/(mid+'-mutant.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),mutant.splitlines(True),fromfile='a/'+src,tofile='b/'+src)))
   run(g,mid+'-old-test-mutant',mutant,t,0)
   run(g,mid+'-new-test-mutant',mutant,strong,1)
  run(g,'new-test-original',s,strong,0)
finally:
 for name,src,test,s,t,strong,mutants in groups:(iso/src).write_text(s);(iso/test).write_text(strong)
 (out/'results.json').write_text(json.dumps({'baseline':baseline,'records':rows},indent=2)+'\n')
