import hashlib
import json
from pathlib import Path
import re

base = Path(__file__).resolve().parent
repo = Path('/workspace/scratch/8f6c1df8ef3b/di')
target = repo / 'docs/audit'
prefix = '2026-11-15-di6-full-reaudit-round3'
scope = json.loads((base / 'aggregate-review.json').read_text())
ci = json.loads((base / 'final-ci/coverage-mutation-summary.json').read_text())
bundle = json.loads((base / 'bundle-build.json').read_text())
summary = scope['summary']
assert ci['head'] == '19584c03f77036045184d5eef4b992a9e86aaad6'
assert ci['conclusion'] == 'success'
assert summary['error_count'] == summary['warning_count'] == 0
assert summary['executed_pest_tdd_unique_declarations'] == 37

def metric(item):
    return f"{item['passed']} passed, {item['skipped']} skipped, {item['assertions']} assertions"

common = {
    'HEAD': ci['head'],
    'CI_RUN': str(ci['run_id']),
    'TDD_DECLARATIONS': str(summary['executed_pest_tdd_unique_declarations']),
    'LOCAL84': metric({'passed': summary['junit']['PHP84']['statuses']['passed'], 'skipped': summary['junit']['PHP84']['statuses']['skipped'], 'assertions': summary['junit']['PHP84']['assertions']}),
    'LOCAL85': metric({'passed': summary['junit']['PHP85']['statuses']['passed'], 'skipped': summary['junit']['PHP85']['statuses']['skipped'], 'assertions': summary['junit']['PHP85']['assertions']}),
    'CI84': 'PHP ' + ci['platforms']['linux84']['version'] + ': ' + metric(ci['platforms']['linux84']),
    'CI85': 'PHP ' + ci['platforms']['linux85']['version'] + ': ' + metric(ci['platforms']['linux85']),
    'CIWIN': 'PHP ' + ci['platforms']['windows84']['version'] + ': ' + metric(ci['platforms']['windows84']),
    'COVERAGE': f"Pest Total: {ci['coverage']['percent']}% (minimum {ci['coverage']['minimum']}%); Clover: 4441/4823 statements",
    'MUTATION': f"{ci['mutation']['score_percent']}% MSI (minimum {ci['mutation']['minimum']}%); {ci['mutation']['total']} total, {ci['mutation']['tested']} tested, {ci['mutation']['timeouts']} timeouts, {ci['mutation']['untested']} untested",
}
verdict = summary['survivor_verdict_counts']
values = {
    'ru': common | {
        'SURVIVOR_SUMMARY': f"Итог классификации исходных 552: {verdict['meaningful gap']} meaningful candidates, {verdict['equivalent-under-contract']} equivalent-under-contract, {verdict['redundant path']} redundant paths, {verdict['defensive-outside-supported-input']} defensive/outside-supported-input, {verdict['needs architecture decision']} needs-decision и {verdict['diagnostic-specificity-only']} diagnostic-specificity-only. Из 172 meaningful candidates 57 имеют новый исполненный witness; 115 остаются reasoned/unexecuted. Это классификация исходного каталога, не подмена числа survivors финального CI.",
        'MUTATION_CAVEAT': f"Движок включает {ci['mutation']['timeouts']} timeouts в MSI. Доля именно завершённых kills составляет {ci['mutation']['completed_kill_percent']:.2f}% от всех мутаций ({ci['mutation']['tested']}/{ci['mutation']['total']}); timeout не засчитан как смысловой RED. Для сравнения, предыдущий опубликованный прогон имел 87.01% MSI, 4248 мутаций, 3640 tested, 56 timeouts и 552 untested. Старые цифры не выдаются за текущий результат.",
    },
    'en': common | {
        'SURVIVOR_SUMMARY': f"The baseline classification is {verdict['meaningful gap']} meaningful candidates, {verdict['equivalent-under-contract']} equivalent-under-contract, {verdict['redundant path']} redundant paths, {verdict['defensive-outside-supported-input']} defensive/outside-supported-input, {verdict['needs architecture decision']} needs-decision and {verdict['diagnostic-specificity-only']} diagnostic-specificity-only. Of the 172 meaningful candidates, 57 have a newly executed witness and 115 remain reasoned/unexecuted. These are baseline classifications, not substituted counts for the final CI survivors.",
        'MUTATION_CAVEAT': f"The engine includes {ci['mutation']['timeouts']} timeouts in MSI. Completed kills alone represent {ci['mutation']['completed_kill_percent']:.2f}% of all mutations ({ci['mutation']['tested']}/{ci['mutation']['total']}); a timeout is not a semantic RED proof. The previous published run had 87.01% MSI, 4248 mutations, 3640 tested, 56 timeouts and 552 untested. Those historical numbers are not presented as the current result.",
    },
}

outputs = []
for language, name in [('ru', prefix + '.ru.md'), ('en', prefix + '.md')]:
    text = (base / f'report-round3.{language}.template.md').read_text()
    for key, value in values[language].items():
        text = text.replace('@@' + key + '@@', str(value))
    assert not re.search(r'@@[A-Z0-9_]+@@', text), name
    archive_link = f'[{prefix}-evidence.tar.gz]({prefix}-evidence.tar.gz)'
    if language == 'ru':
        text += f"\nПолный архив исходных доказательств: {archive_link}. SHA-256: `{bundle['sha256']}`. Архив содержит {bundle['entries']} файлов; распаковка и побайтовое соответствие manifest проверены.\n"
    else:
        text += f"\nFull raw evidence archive: {archive_link}. SHA-256: `{bundle['sha256']}`. It contains {bundle['entries']} files; round-trip extraction and every manifest hash were verified.\n"
    (target / name).write_text(text)
    outputs.append(target / name)

gates = []
for label in ['final84', 'final85', 'final-phpstan', 'final-style', 'final-composer-validate', 'composer-audit', 'mutation-parity84', 'mutation-parity85', 'native-platform85', 'windows-path-style-final']:
    p = base / 'checks' / (label + '.json')
    if not p.exists():
        raise RuntimeError('Missing claimed gate: ' + label)
    data = json.loads(p.read_text())
    gates.append({k: v for k, v in data.items() if k != 'source_test_files'} | {'archive_member': str(p.relative_to(base)), 'metadata_sha256': hashlib.sha256(p.read_bytes()).hexdigest()})

proofs = json.loads((base / 'aggregate-evidence-files.json').read_text())
index = {
    'schema_version': 1,
    'repository': 'componenta/di',
    'branch': 'refactor/di6-definitions-callbacks',
    'baseline': '2eb36241787a971e1a8185149aaa08b90304d426',
    'validated_code_head': ci['head'],
    'scope': {'path': prefix + '-scope.json', 'sha256': hashlib.sha256((target / (prefix + '-scope.json')).read_bytes()).hexdigest(), 'summary': summary},
    'archive': {'path': prefix + '-evidence.tar.gz', **{k: v for k, v in bundle.items() if k != 'archive'}},
    'canonical_evidence_index': {'archive_member': 'aggregate-evidence-files.json', 'sha256': hashlib.sha256((base / 'aggregate-evidence-files.json').read_bytes()).hexdigest(), 'summary': proofs['summary']},
    'ci': ci,
    'local_gates': gates,
    'production_runtime_token_proof': json.loads((base / 'final-code-snapshot.json').read_text()),
    'static_analysis_separate_from_pest': scope['static_analysis_evidence_not_pest_tdd'],
    'executed_pest_declarations': scope['executed_pest_tdd']['declarations'],
    'canonical_platform_pairs': proofs['canonical_platform_ci_pairs'],
    'code_commits': json.loads((base / 'final-repository-inventory.json').read_text())['commits'],
    'report_peer_review': json.loads((base / 'parameters/report-peer-review.json').read_text()),
    'limitations': [
        'Only 37 declarations have newly executed individual meaningful RED/GREEN; 725 have individual manual review and whole-suite validation.',
        'The 552 baseline survivor decisions are distinct from the final engine outcome; 115 meaningful candidates remain reasoned/unexecuted.',
        'Timeouts count in engine MSI but do not establish a semantic oracle.',
        'Native E1 on available PHP 8.5.8 is 2/10 with unverified release/source provenance; feature-local only.',
        'The required Codex Security server tool was unavailable; no automated Codex Security scan is claimed.',
        'Absolute workspace paths are historical provenance, not portable commands without root substitution.',
        'Archive preserves excluded attempts. Inclusion alone does not make a result canonical.',
    ],
}
index_path = target / (prefix + '-evidence.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
outputs.extend([index_path, target / (prefix + '-scope.json'), target / (prefix + '-evidence.tar.gz')])
manifest = []
for p in outputs:
    content = p.read_bytes()
    manifest.append({'path': str(p.relative_to(repo)), 'absolute_path': str(p), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(), 'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()})
(base / 'delivery-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest))
