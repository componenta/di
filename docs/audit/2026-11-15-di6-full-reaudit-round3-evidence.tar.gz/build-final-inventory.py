import hashlib,json,subprocess
from collections import Counter
from pathlib import Path

repo=Path('/workspace/scratch/8f6c1df8ef3b/di')
out=Path(__file__).resolve().parent/'final-repository-inventory.json'
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
configs={'composer.json','phpunit.xml','phpstan.neon.dist','.php-cs-fixer.dist.php','.github/workflows/ci.yml','.github/workflows/release.yml','.gitattributes','.gitignore'}
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
files=[]
for name in git('ls-files').splitlines():
    p=Path(name)
    if name in configs:scope='configuration'
    elif name.startswith('src/') and p.suffix=='.php':scope='production'
    elif name.startswith('tests/') and p.suffix=='.php':scope='tests/support'
    elif name.startswith('tests/Fixtures/') and name.endswith('.php.fixture'):scope='native fixtures'
    elif name.startswith('benchmarks/') and p.suffix=='.php':scope='benchmarks'
    elif name.startswith('docs/audit/reproductions/') and p.suffix in ('.php','.py'):scope='reproductions'
    else:continue
    b=(repo/p).read_bytes()
    files.append({'path':name,'scope':scope,'sha256':hashlib.sha256(b).hexdigest(),'lines':len(b.splitlines())})
commits=[]
for line in git('log','--reverse','--format=%H %s',baseline+'..HEAD').splitlines():
    sha,subject=line.split(' ',1)
    commits.append({'sha':sha,'subject':subject,'paths':git('diff-tree','--no-commit-id','--name-only','-r',sha).splitlines()})
result={'baseline':baseline,'final_code_head':git('rev-parse','HEAD'),'files':files,'counts':dict(Counter(f['scope'] for f in files)),'commits':commits,'diff_stat':git('diff','--stat',baseline+'..HEAD'),'changed_paths':git('diff','--name-only',baseline+'..HEAD').splitlines()}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'head':result['final_code_head'],'files':len(files),'counts':result['counts'],'commits':len(commits),'changed_paths':len(result['changed_paths'])}))
