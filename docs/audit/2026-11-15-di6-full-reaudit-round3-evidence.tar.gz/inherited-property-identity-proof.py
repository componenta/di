from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, tarfile, datetime

base=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/8f6c1df8ef3b/di')
out=base/'inherited-property-identity'
isolated=out/'isolated'
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
out.mkdir(exist_ok=False)
isolated.mkdir()
data=subprocess.check_output(['git','archive',baseline,'--','src','tests','composer.json','phpunit.xml','.php-cs-fixer.dist.php','phpstan.neon.dist'],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    archive.extractall(isolated,filter='data')
vendor=isolated/'vendor';vendor.mkdir()
for entry in (repo/'vendor').iterdir():
    target=vendor/entry.name
    if entry.name in ['composer','bin','pestphp']:
        shutil.copytree(entry,target,symlinks=False)
    elif entry.is_file():shutil.copy2(entry,target)
    else:target.symlink_to(entry,target_is_directory=True)

source=isolated/'src/Resolver/Entry/ObjectCreationContext.php'
original=source.read_text()
test=isolated/'tests/Contract/InheritedPropertyIdentityContractTest.php'
test_bytes=(base/'inherited-property-identity-improved.php').read_bytes()
bootstrap=base/'core/proof-bootstrap.php'
classes=['Componenta\\DI\\Resolver\\Entry\\ObjectCreationContext','Componenta\\DI\\Object\\ObjectPipeline','Componenta\\DI\\Resolver\\Entry\\InstanceCreator','Componenta\\DI\\Resolver\\Attribute\\AttributeProcessor']
records=[]
evidence={'baseline':baseline,'source':'src/Resolver/Entry/ObjectCreationContext.php','new_test':'tests/Contract/InheritedPropertyIdentityContractTest.php','test_sha256':hashlib.sha256(test_bytes).hexdigest(),'old_scope':'entire ObjectLifecycleTestCoverageContractTest.php; catalog carries prior full-suite survival','new_scope':'new entire test file, both property/class boundary directions','records':records}

def run(label,version,expected,whole=False):
    origins=out/(label+'-php'+version+'-origins.json')
    hashes={cls:hashlib.sha256((isolated/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()).hexdigest() for cls in classes}
    env=os.environ.copy();env.update({'R3_CORE_ROOT':str(isolated),'R3_CORE_PROVENANCE':str(origins),'R3_CORE_HASHES':json.dumps(hashes)})
    command=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-d','opcache.enable_cli=0','vendor/bin/pest']
    command += ['tests/Contract/ObjectLifecycleTestCoverageContractTest.php' if whole else str(test.relative_to(isolated))]
    command += ['--bootstrap='+str(bootstrap),'--compact','--colors=never','--do-not-cache-result','--order-by=random','--random-order-seed=2026111533']
    before={str(p.relative_to(isolated)):hashlib.sha256(p.read_bytes()).hexdigest() for prefix in ['src','tests'] for p in (isolated/prefix).rglob('*') if p.is_file()}
    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    process=subprocess.run(command,cwd=isolated,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    log=out/(label+'-php'+version+'.log');log.write_bytes(process.stdout)
    after={str(p.relative_to(isolated)):hashlib.sha256(p.read_bytes()).hexdigest() for prefix in ['src','tests'] for p in (isolated/prefix).rglob('*') if p.is_file()}
    record={'label':label,'php':version,'started_utc':timestamp,'command':command,'cwd':str(isolated),'exit':process.returncode,'expected_exit':expected,'log':str(log),'log_sha256':hashlib.sha256(process.stdout).hexdigest(),'source_sha256':hashes[classes[0]],'origins':str(origins),'unchanged_during_run':before==after,'source_test_fingerprint':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
    if origins.exists():
        record['origins_sha256']=hashlib.sha256(origins.read_bytes()).hexdigest()
        origin_data=json.loads(origins.read_text());assert origin_data['pest_root']==str(isolated)
    records.append(record);(out/'proof.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(label,version,process.returncode,process.stdout.decode(errors='replace')[-300:],flush=True)
    assert process.returncode==expected and origins.exists() and before==after,(label,process.returncode)

try:
    for version in ['84','85']:run('old-production',version,0,whole=True)
    needle='$property->getDeclaringClass()->getName() . "\\0" . $property->getName()'
    cases=[
        ('1d6cfa6279fb43b9', '$property->getDeclaringClass()->getName() . $property->getName()'),
        ('6d14b6b0ee74a098', '"\\0" . $property->getDeclaringClass()->getName() . $property->getName()'),
        ('e71f5d6b520c53c2', '$property->getName() . ($property->getDeclaringClass()->getName() . "\\0")'),
    ]
    for id,replacement in cases:
        assert original.count(needle)==1
        source.write_text(original.replace(needle,replacement))
        for version in ['84','85']:run(id+'-old-mutant',version,0,whole=True)
        test.write_bytes(test_bytes)
        for version in ['84','85']:run(id+'-new-mutant',version,1)
        test.unlink()
    source.write_text(original);test.write_bytes(test_bytes)
    for version in ['84','85']:run('new-production',version,0)
finally:
    source.write_text(original)
    (out/'proof.json').write_text(json.dumps(evidence,indent=2)+'\n')
