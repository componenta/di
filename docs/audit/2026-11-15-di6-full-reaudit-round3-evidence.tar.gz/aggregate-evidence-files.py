#!/usr/bin/env python3
"""Materialize an archive input list from the accepted aggregate; run no tests."""
import collections
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess

BASE = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/workspace/scratch/8f6c1df8ef3b/di')
BASELINE = '2eb36241787a971e1a8185149aaa08b90304d426'
OUT = BASE / 'aggregate-evidence-files.json'
PREIMAGES = BASE / 'aggregate-test-preimages'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    aggregate_path = BASE / 'aggregate-review.json'
    aggregate = json.loads(aggregate_path.read_text())
    files, missing, external, queue, parsed = {}, [], [], [], {}
    directories = []

    def add(path, role, origin, recurse=False, required=True):
        p = pathlib.Path(path)
        if not p.is_absolute():
            p = BASE / p
        p = p.resolve()
        if not p.is_relative_to(BASE):
            external.append({'path': str(p), 'role': role, 'origin': origin})
            return
        if p.is_dir():
            directories.append({'path': str(p), 'role': role, 'origin': origin, 'included_as_tree': False})
            return
        if not p.is_file():
            if required:
                missing.append({'path': str(p), 'role': role, 'origin': origin})
            return
        key = str(p)
        if key not in files:
            data = p.read_bytes()
            files[key] = {'path': key, 'archive_path': str(p.relative_to(BASE)), 'sha256': sha(data),
                          'bytes': len(data), 'roles': [], 'referenced_by': []}
        r = files[key]
        if role not in r['roles']:
            r['roles'].append(role)
        if origin not in r['referenced_by']:
            r['referenced_by'].append(origin)
        if recurse and p.suffix == '.json' and key not in parsed:
            try:
                parsed[key] = json.loads(p.read_text())
            except (ValueError, UnicodeError):
                return
            queue.append((p, role, parsed[key]))

    def values(value):
        if isinstance(value, dict):
            for child in value.values():
                yield from values(child)
        elif isinstance(value, list):
            for child in value:
                yield from values(child)
        elif isinstance(value, str):
            yield value

    def is_mutable_tree(p):
        return any(part == 'vendor' or part == '.git' or 'isolated' in part for part in p.parts)

    def follow(value, owner, role):
        for text in values(value):
            if text.startswith('--bootstrap='):
                text = text.split('=', 1)[1]
            if '\n' in text or len(text) > 600 or not re.search(r'\.(?:json|log|xml|py|php|patch|diff|md|neon)$', text):
                continue
            p = pathlib.Path(text)
            candidates = [p] if p.is_absolute() else [owner.parent / p, BASE / p]
            for candidate in candidates:
                if not candidate.is_file():
                    continue
                candidate = candidate.resolve()
                if candidate.is_relative_to(BASE) and not is_mutable_tree(candidate):
                    add(candidate, role + ':referenced', str(owner), True)
                break

    add(aggregate_path, 'aggregate', 'entrypoint')
    add(BASE / 'aggregate-review.py', 'aggregation_script', 'entrypoint')
    add(pathlib.Path(__file__), 'archive_index_script', 'entrypoint')
    for item in aggregate['input_artifacts']:
        add(item['path'], 'aggregate_input', str(aggregate_path))
    runs, ci, proof_claims = {}, {}, collections.defaultdict(list)
    for c in aggregate['executed_pest_tdd']['declaration_fault_proofs']:
        for ref in c['proofs']:
            add(ref['path'], 'proof:' + ref['role'], c['declaration_id'] + ' / ' + c['fault_id'], True)
            proof_claims[ref['path']].append(c)
        for r in c['accepted_pest_phases']:
            entry = runs.setdefault(r['log'], {**r, 'fault_ids': [], 'declaration_ids': []})
            if c['fault_id'] not in entry['fault_ids']:
                entry['fault_ids'].append(c['fault_id'])
            if c['declaration_id'] not in entry['declaration_ids']:
                entry['declaration_ids'].append(c['declaration_id'])
            add(r['log'], 'canonical_pest_output', r['proof'])
            if r.get('origins'):
                add(r['origins'], 'canonical_historical_origins', r['proof'])
        for row in c['platform_ci_controls']:
            ci[row['proof']] = row
            add(row['proof'], 'canonical_platform_ci_proof', c['declaration_id'], True)
            add(row['red_log'], 'canonical_platform_ci_RED_output', row['proof'])
            add(row['green_log'], 'canonical_platform_ci_GREEN_output', row['proof'])
    for e in aggregate['static_analysis_evidence_not_pest_tdd']:
        follow(e, BASE / 'aggregate-review.json', 'static_analysis_not_pest_tdd')
    for e in aggregate['excluded_or_superseded']:
        path = e.get('path')
        if path:
            add(path, 'excluded_or_superseded_not_canonical', 'aggregate exclusion list', True, False)
        follow(e, BASE / 'aggregate-review.json', 'excluded_or_superseded_not_canonical')
    while queue:
        p, role, value = queue.pop()
        follow(value, p, role)

    # Recover exact old/new test bytes from frozen copies or Git only when their
    # SHA256 equals the proof's demanded preimage. Mutable cwd files are never
    # archived under their current name as evidence of an old execution.
    needs = {}
    whole_baseline_controls = []
    candidate_paths = set()
    for current, dirs, names in os.walk(BASE):
        dirs[:] = [d for d in dirs if not is_mutable_tree(pathlib.Path(d)) and d != 'aggregate-test-preimages']
        for name in names:
            if name.endswith(('.php', '.inc')):
                candidate_paths.add(pathlib.Path(current) / name)
    baseline_files = []
    listing = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', '-z', BASELINE, '--', 'tests'])
    for item in listing.split(b'\0'):
        if item:
            meta, path = item.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            if kind == 'blob':
                baseline_files.append((oid, path.decode()))
    data_by_sha = {}
    batch = subprocess.run(['git', '-C', str(REPO), 'cat-file', '--batch'],
                           input=('\n'.join(oid for oid, _ in baseline_files) + '\n').encode(), capture_output=True, check=True).stdout
    pos, baseline_tree = 0, []
    for oid, path in baseline_files:
        end = batch.index(b'\n', pos)
        header = batch[pos:end].decode().split()
        size = int(header[2])
        content = batch[end + 1:end + 1 + size]
        pos = end + 2 + size
        h = sha(content)
        data_by_sha[h] = (content, {'kind': 'git_blob', 'commit': BASELINE, 'path': path, 'blob': oid})
        baseline_tree.append({'path': path, 'sha256': h, 'git_blob': oid})
    for p in candidate_paths:
        content = p.read_bytes()
        data_by_sha.setdefault(sha(content), (content, {'kind': 'existing_copy_matching_expected_sha256', 'path': str(p)}))

    def require_preimage(path, expected, proof, run, direct=True):
        key = (path, expected)
        entry = needs.setdefault(key, {'test_path': path, 'expected_sha256': expected, 'expected_hash_directly_recorded': direct,
                                       'proofs': [], 'phase_outputs': []})
        if proof not in entry['proofs']:
            entry['proofs'].append(proof)
        if run not in entry['phase_outputs']:
            entry['phase_outputs'].append(run)
        candidate = REPO / path
        if candidate.is_file():
            content = candidate.read_bytes()
            data_by_sha.setdefault(sha(content), (content, {'kind': 'current_repository_copy_matching_expected_sha256', 'path': str(candidate)}))

    for c in aggregate['executed_pest_tdd']['declaration_fault_proofs']:
        for run in c['accepted_pest_phases']:
            p = pathlib.Path(run['proof'])
            d = parsed.get(str(p)) or json.loads(p.read_text())
            context = d
            if 'cases' in d:
                context = next(x for x in d['cases'] if x['id'] == c['fault_id'])
            rows = context.get('runs', context.get('records', []))
            raw = rows[run['record_index']] if rows else context
            command = raw.get('command', [])
            tokens = command if isinstance(command, list) else command.split()
            selected = [x for x in tokens if x.startswith('tests/') and x.endswith('.php')]
            old = run['phase'].startswith('old_')
            if old and not selected and d.get('old_scope') == 'entire baseline suite':
                whole_baseline_controls.append({'proof': str(p), 'phase_output': run['log'], 'commit': d.get('baseline'),
                                                'source_test_fingerprint': raw.get('source_test_fingerprint')})
                continue
            path = raw.get('test_path', raw.get('test')) or (selected[0] if selected else c['test_path'])
            expected = raw.get('test_sha256')
            if not expected:
                expected = raw.get('source_test_files', {}).get(path)
            if not expected:
                expected = context.get('old_test_sha256') if old else context.get('new_test_sha256', context.get('improved_test_sha256'))
            if not expected and path in d.get('tests', {}):
                expected = d['tests'][path]['old_sha256' if old else 'new_sha256']
            if not expected and not old:
                expected = d.get('test_sha256')
            direct = bool(expected)
            if not expected and old and d.get('baseline') == BASELINE:
                found = next((x for x in baseline_tree if x['path'] == path), None)
                expected = found['sha256'] if found else None
            if expected:
                require_preimage(path, expected, str(p), run['log'], direct)
            else:
                missing.append({'role': 'test_preimage_identity', 'proof': str(p), 'phase_output': run['log'], 'test_path': path})
        for platform in c['platform_ci_controls']:
            d = json.loads(pathlib.Path(platform['proof']).read_text())
            for field in ['before_files', 'after_files']:
                expected = d[field].get(c['test_path'])
                if expected:
                    require_preimage(c['test_path'], expected, platform['proof'], platform['red_log' if field == 'before_files' else 'green_log'])
    PREIMAGES.mkdir(exist_ok=True)
    for entry in needs.values():
        h = entry['expected_sha256']
        if h not in data_by_sha:
            # Later accepted proof versions may predate the final test file. The
            # repository history is read only; no branch/check-out is created.
            revisions = subprocess.check_output(['git', '-C', str(REPO), 'log', '--all', '--format=%H', '--', entry['test_path']], text=True).splitlines()
            for rev in revisions:
                cp = subprocess.run(['git', '-C', str(REPO), 'show', rev + ':' + entry['test_path']], capture_output=True)
                if cp.returncode == 0 and sha(cp.stdout) == h:
                    data_by_sha[h] = (cp.stdout, {'kind': 'git_blob_from_history_matching_expected_sha256', 'commit': rev, 'path': entry['test_path']})
                    break
        if h not in data_by_sha:
            missing.append({'role': 'test_preimage_bytes', **entry})
            continue
        content, source = data_by_sha[h]
        target = PREIMAGES / (h + pathlib.Path(entry['test_path']).suffix)
        target.write_bytes(content)
        entry['materialized_file'] = str(target)
        entry['bytes_obtained_from'] = source
        add(target, 'canonical_exact_test_preimage', ', '.join(entry['proofs']))
    if whole_baseline_controls:
        for row in baseline_tree:
            content, source = data_by_sha[row['sha256']]
            target = PREIMAGES / 'whole-baseline-suite' / row['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            row['materialized_file'] = str(target)
            add(target, 'whole_baseline_suite_test_preimage', 'old whole-suite controls at ' + BASELINE)
    unique_whole_controls = {x['phase_output']: x for x in whole_baseline_controls}
    by_proof = collections.defaultdict(list)
    for row in runs.values():
        by_proof[row['proof']].append(row)
    result = {
        'schema_version': 1, 'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'aggregate': {'path': str(aggregate_path), 'sha256': sha(aggregate_path.read_bytes()), 'status': aggregate['status']},
        'code_head': aggregate['repository_head_observed'],
        'status': 'complete' if not missing else 'missing_references',
        'summary': {'archive_input_files': len(files), 'archive_input_bytes': sum(x['bytes'] for x in files.values()),
                    'unique_local_canonical_pest_output_files': len(runs),
                    'local_pest_phases': dict(collections.Counter(x['phase'] for x in runs.values())),
                    'local_pest_runtime_counts': dict(collections.Counter(x['runtime'] for x in runs.values())),
                    'platform_ci_red_green_pairs': len(ci),
                    'test_path_sha256_preimages_required': len(needs),
                    'test_path_sha256_preimages_materialized': sum('materialized_file' in x for x in needs.values()),
                    'whole_baseline_suite_controls': len(unique_whole_controls),
                    'whole_baseline_test_files_materialized': len(baseline_tree) if whole_baseline_controls else 0,
                    'missing_references': len(missing)},
        'files': sorted(files.values(), key=lambda x: x['archive_path']),
        'canonical_pest_run_outputs': sorted(runs.values(), key=lambda x: (x['proof'], x['runtime'], x['label'])),
        'canonical_phase_counts_by_proof': {p: {'unique_outputs': len(rows), 'phases': dict(collections.Counter(x['phase'] for x in rows)),
                                             'runtimes': dict(collections.Counter(x['runtime'] for x in rows))} for p, rows in sorted(by_proof.items())},
        'canonical_platform_ci_pairs': list(ci.values()),
        'exact_test_preimages': sorted(needs.values(), key=lambda x: (x['test_path'], x['expected_sha256'])),
        'whole_baseline_suite_controls': list(unique_whole_controls.values()),
        'whole_baseline_suite_preimages': baseline_tree if whole_baseline_controls else [],
        'directories_not_implicitly_archived': directories,
        'external_environment_dependencies_not_archived': external,
        'missing_references': missing,
        'limits': ['Archive roles distinguish canonical phases, static analysis, predecessors, exclusions and supporting artifacts. Inclusion never promotes an excluded phase into a successful TDD proof.',
                   'Phase counts deduplicate by saved output path; shared GREEN controls count once. They are not the total number of processes launched throughout the audit.',
                   'Test preimage bytes are materialized only from an exact expected SHA256 match. Baseline old-scope files without a direct test hash are explicitly marked as derived from the declared baseline Git tree.',
                   'Absolute runtime/vendor paths and mutable isolated checkouts are environment dependencies; they are not archived as immutable historical source evidence.',
                   'This is an explicit archive input list. Directories in exclusion prose are listed without silently adding every file below them.'],
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()), 'status': result['status'], 'summary': result['summary'], 'missing_references': missing}, indent=2))
    return 0 if not missing else 1


if __name__ == '__main__':
    raise SystemExit(main())
