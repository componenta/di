import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile

base = Path(__file__).resolve().parent
repo = Path('/workspace/scratch/8f6c1df8ef3b/di')
output = repo / 'docs/audit/2026-11-15-di6-full-reaudit-round3-evidence.tar.gz'
excluded_dirs = {'isolated', 'selected-source', 'final-token-baseline', '__pycache__', 'vendor', '.git'}
extensions = {'.json', '.log', '.stdout', '.stderr', '.php', '.fixture', '.py', '.xml', '.zip', '.md', '.patch', '.diff', '.txt'}
secret_patterns = [
    re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}'),
    re.compile(rb'github_pat_[A-Za-z0-9_]{30,}'),
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
]

entries = {}
for root, dirs, files in os.walk(base):
    dirs[:] = sorted(d for d in dirs if d not in excluded_dirs and not d.startswith('.'))
    for name in sorted(files):
        path = Path(root) / name
        if name.startswith('.') or path.suffix not in extensions or name.endswith('.template.md'):
            continue
        if name in {'bundle-build.json', 'delivery-manifest.json', 'report-values.json'}:
            continue
        if path.is_symlink():
            raise RuntimeError('Unexpected evidence symlink: ' + str(path))
        entries[str(path.relative_to(base))] = path.read_bytes()

for name, source in {
    'composer.json': repo / 'composer.json',
    'composer.lock': repo / 'composer.lock',
    'installed.json': repo / 'vendor/composer/installed.json',
}.items():
    if source.is_file():
        entries['dependency-snapshot/' + name] = source.read_bytes()

assert 'aggregate-evidence-files.json' in entries, 'Canonical proof selection must be complete first.'
assert 'final-ci/coverage-mutation-summary.json' in entries, 'Final CI coverage/mutation evidence is required.'
canonical = json.loads(entries['aggregate-evidence-files.json'])
assert canonical['status'] == 'complete' and not canonical['missing_references']
for record in canonical['files']:
    name = record['archive_path']
    assert name in entries, 'Missing canonical evidence member: ' + name
    assert hashlib.sha256(entries[name]).hexdigest() == record['sha256'], 'Changed canonical evidence: ' + name
scope = json.loads(entries['aggregate-review.json'])
assert scope['summary']['error_count'] == 0
assert scope['summary']['warning_count'] == 0
assert scope['summary']['executed_pest_tdd_unique_declarations'] == 37
for name, content in entries.items():
    if any(pattern.search(content) for pattern in secret_patterns):
        raise RuntimeError('Review potential secret before publication: ' + name)

rows = [{'path': name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
        for name, content in sorted(entries.items())]
manifest = {
    'schema_version': 1,
    'head': '19584c03f77036045184d5eef4b992a9e86aaad6',
    'baseline': '2eb36241787a971e1a8185149aaa08b90304d426',
    'qualification': 'Byte inventory of preserved evidence. Historical and excluded attempts are retained, not counted as canonical proofs. BUNDLE-MANIFEST.json itself is excluded from its recursive inventory.',
    'entries': rows,
}
entries['BUNDLE-MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with output.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(mode='w', fileobj=compressed, format=tarfile.PAX_FORMAT) as tar:
            for name, content in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mtime = 0
                info.mode = 0o644
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(content))

with tarfile.open(output, 'r:gz') as tar:
    found = {}
    for member in tar.getmembers():
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        stream = tar.extractfile(member)
        assert stream is not None
        content = stream.read()
        found[member.name] = hashlib.sha256(content).hexdigest()
        assert content == entries[member.name], member.name
    assert set(found) == set(entries)

result = {
    'archive': str(output),
    'bytes': output.stat().st_size,
    'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'entries': len(entries),
    'uncompressed_bytes': sum(len(v) for v in entries.values()),
    'round_trip_verified': True,
    'high_confidence_secret_scan_matches': 0,
    'manifest_sha256': hashlib.sha256(entries['BUNDLE-MANIFEST.json']).hexdigest(),
}
(base / 'bundle-build.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
