import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/workspace/scratch/8f6c1df8ef3b/di')
out = Path('/workspace/scratch/fa8384e69042/reaudit-round3/checks')
out.mkdir(exist_ok=True)
label, *command = sys.argv[1:]
snapshot = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for prefix in ('src', 'tests') for p in sorted((root / prefix).rglob('*')) if p.is_file()}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
start = time.monotonic()
timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out / (label + '.log')).open('wb') as log:
    run = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=os.environ.copy())
raw = (out / (label + '.log')).read_bytes()
after = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
         for prefix in ('src', 'tests') for p in sorted((root / prefix).rglob('*')) if p.is_file()}
result = {'label': label, 'head_at_start': head, 'started_utc': timestamp,
          'duration_seconds': time.monotonic() - start, 'command': command,
          'exit_code': run.returncode, 'sha256': hashlib.sha256(raw).hexdigest(),
          'source_test_fingerprint': hashlib.sha256(json.dumps(snapshot, separators=(',', ':'), sort_keys=True).encode()).hexdigest(),
          'source_test_files': snapshot, 'unchanged_during_run': snapshot == after,
          'output_file': str(out / (label + '.log'))}
(out / (label + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'source_test_files'}))
print(raw.decode(errors='replace')[-5000:])
sys.exit(run.returncode)
