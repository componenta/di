<?php
declare(strict_types=1);

$source = $argv[1];
require '/workspace/scratch/8f6c1df8ef3b/di/vendor/psr/container/src/ContainerExceptionInterface.php';
foreach (['ExceptionInterface', 'InvalidConfigurationException', 'InvalidCallableException', 'MutationRetirementException', 'RequestDataConflictException', 'RequestParameterSourceConflictException'] as $name) {
    require $source . '/' . $name . '.php';
}
set_error_handler(static function (int $severity, string $message): never {
    throw new ErrorException($message, 0, $severity);
});

use Componenta\DI\Exception\InvalidCallableException;
use Componenta\DI\Exception\MutationRetirementException;
use Componenta\DI\Exception\RequestDataConflictException;
use Componenta\DI\Exception\RequestParameterSourceConflictException;

final class NamedAuditReceiver {}
$receivers = ['named' => new NamedAuditReceiver(), 'anonymous' => new class {}];
$data = [];
foreach ($receivers as $kind => $receiver) {
    $error = InvalidCallableException::forValue([$receiver, 'missing']);
    $data['callable'][$kind] = [
        'description' => $error->callableDescription,
        'native_owner' => $receiver::class,
        'debug_owner' => get_debug_type($receiver),
        'type' => $error->callableType,
        'message' => $error->getMessage(),
    ];
}
foreach ([null, 'argument'] as $parameter) {
    $error = new RequestParameterSourceConflictException(stdClass::class, 'typed-key', 'Componenta\\DI\\Attribute\\QueryParam', $parameter);
    $data['parameter_source'][$parameter ?? 'null'] = [
        'parameter' => $error->parameter, 'key' => $error->key, 'source' => $error->source,
        'dtoClass' => $error->dtoClass, 'message' => $error->getMessage(),
    ];
}
$cause = new RuntimeException('release failed');
foreach ([null, 'service'] as $id) {
    $error = new MutationRetirementException($id, [$cause]);
    $data['valid_retirement'][$id ?? 'null'] = [
        'id' => $error->id, 'same_causes' => $error->causes === [$cause],
        'same_previous' => $error->getPrevious() === $cause, 'message' => $error->getMessage(),
    ];
}
foreach (['empty' => [], 'non-list' => [2 => $cause], 'non-throwable-second' => [$cause, new stdClass()]] as $label => $causes) {
    try {
        new MutationRetirementException('service', $causes);
        $data['outside_declared_causes_contract'][$label] = ['accepted' => true];
    } catch (Throwable $error) {
        $data['outside_declared_causes_contract'][$label] = ['exception' => $error::class, 'message' => $error->getMessage()];
    }
}
foreach (['', 0, -1, PHP_INT_MAX, PHP_INT_MIN, '0042', 'plain-key'] as $key) {
    $error = new RequestDataConflictException($key, 'query', 'payload');
    $data['request_data'][] = ['key' => $error->key, 'message' => $error->getMessage()];
}
$origins = [];
foreach ([InvalidCallableException::class, MutationRetirementException::class, RequestDataConflictException::class, RequestParameterSourceConflictException::class] as $class) {
    $file = (new ReflectionClass($class))->getFileName();
    if (!is_string($file) || !str_starts_with(realpath($file), $source . '/')) {
        throw new RuntimeException('Wrong diagnostic source: ' . $class);
    }
    $origins[$class] = ['path' => $file, 'sha256' => hash_file('sha256', $file)];
}
echo json_encode(['php' => PHP_VERSION, 'observations' => $data, 'origins' => $origins], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
