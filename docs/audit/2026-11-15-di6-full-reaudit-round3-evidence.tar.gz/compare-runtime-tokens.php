<?php

declare(strict_types=1);

[$script, $original, $current, $destination] = $argv;
$entries = [];
$runtimeChanges = [];
$rawChanges = [];
$ignored = [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT];
$tokens = static function (string $source) use ($ignored): array {
    $result = [];
    foreach (token_get_all($source) as $token) {
        if (is_array($token)) {
            if (!in_array($token[0], $ignored, true)) {
                $result[] = [$token[0], $token[1]];
            }
        } else {
            $result[] = $token;
        }
    }
    return $result;
};
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($original . '/src')) as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }
    $path = substr($file->getPathname(), strlen($original) + 1);
    $before = file_get_contents($file->getPathname());
    $after = file_get_contents($current . '/' . $path);
    $left = $tokens($before);
    $right = $tokens($after);
    $sameTokens = $left === $right;
    if (!$sameTokens) {
        $runtimeChanges[] = $path;
    }
    if ($before !== $after) {
        $rawChanges[] = $path;
    }
    $entries[$path] = [
        'baseline_sha256' => hash('sha256', $before),
        'final_sha256' => hash('sha256', $after),
        'non_comment_tokens' => count($right),
        'non_comment_tokens_unchanged' => $sameTokens,
        'token_sha256' => hash('sha256', json_encode($right, JSON_THROW_ON_ERROR)),
    ];
}
ksort($entries);
$result = [
    'php' => PHP_VERSION,
    'scope' => 'All tracked production PHP sources; whitespace and PHPDoc/comments ignored, all other token types and text compared exactly.',
    'files' => $entries,
    'raw_changed_paths' => $rawChanges,
    'non_comment_token_changed_paths' => $runtimeChanges,
    'limitation' => 'This establishes unchanged executable token sequences, not a proof of all runtime behavior or of PHPDoc-visible reflection metadata equivalence.',
];
file_put_contents($destination, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
echo json_encode(['php' => PHP_VERSION, 'files' => count($entries), 'raw_changed_paths' => $rawChanges, 'non_comment_token_changed_paths' => $runtimeChanges], JSON_THROW_ON_ERROR) . "\n";
exit($runtimeChanges === [] ? 0 : 1);
