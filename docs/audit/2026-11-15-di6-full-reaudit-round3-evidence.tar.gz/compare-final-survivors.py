#!/usr/bin/env python3
"""Read-only mutation-log reconciliation; never runs PHP, tests, or mutations.

Preparation checks the saved baseline log/catalogue, the 57 executed catalogue
witness IDs, and source line alignment across the two immutable git snapshots.
Final comparison is explicit: pass --log only after the completed log exists.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import difflib
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/workspace/scratch/8f6c1df8ef3b/di')
BASELINE_HEAD = '2eb36241787a971e1a8185149aaa08b90304d426'
FINAL_HEAD = '19584c03f77036045184d5eef4b992a9e86aaad6'
ANSI_CSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
ANSI_OSC = re.compile(r'\x1b\].*?(?:\x07|\x1b\\)')
TIMESTAMP = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z ?')
HEADER = re.compile(
    r'^\s*UNTESTED\s+(?P<path>.+?\.php)\s+>\s+Line\s+(?P<line>\d+)\s*:\s*'
    r'(?P<mutator>\S+)\s+-\s+ID:\s*(?P<id>[0-9a-fA-F]+)\s*$', re.IGNORECASE,
)
SEPARATOR = re.compile(r'^\s*-{20,}\s*$')
SUMMARY = re.compile(r'^\s*Mutations:\s*(.+)$', re.IGNORECASE)
CREATED = re.compile(r'^\s*([\d,]+)\s+Mutations\s+for\s+([\d,]+)\s+Files\s+created\s*$', re.IGNORECASE)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def artifact(path: Path) -> dict:
    return {'path': str(path), 'sha256': sha(path.read_bytes())}


def clean_lines(data: bytes) -> list[str]:
    return [TIMESTAMP.sub('', ANSI_CSI.sub('', ANSI_OSC.sub('', line)))
            for line in data.decode('utf-8', errors='strict').splitlines()]


def relative_source_path(path: str) -> str:
    path = path.strip().replace('\\', '/')
    if path.startswith('./'):
        path = path[2:]
    if not path.startswith('src/'):
        marker = path.find('/src/')
        if marker < 0:
            raise ValueError('Mutation header does not identify a src path: ' + path)
        path = path[marker + 1:]
    if '..' in Path(path).parts:
        raise ValueError('Unexpected parent path in mutation header: ' + path)
    return path


def delta_parts(context: str) -> tuple[list[str], list[str], list[str]]:
    """Remove Pest's three-character diff prefix, not PHP whitespace/literals."""
    old, new, unchanged = [], [], []
    for line in context.splitlines():
        if SEPARATOR.fullmatch(line):
            continue
        if line.startswith('  -'):
            old.append(line[3:])
        elif line.startswith('  +'):
            new.append(line[3:])
        elif line.startswith('   '):
            unchanged.append(line[3:])
    return old, new, unchanged


def enrich(entry: dict) -> dict:
    entry = dict(entry)
    entry['path'] = relative_source_path(entry['path'])
    entry['id'] = entry['id'].lower()
    old, new, context = delta_parts(entry['diff_context'])
    if not old and not new:
        raise ValueError('No changed PHP lines parsed for mutation ' + entry['id'])
    # Preserve string literals, indentation and all code bytes in each line.
    entry['removed_lines'] = old
    entry['added_lines'] = new
    entry['delta_sha256'] = sha(json.dumps([old, new], ensure_ascii=False, separators=(',', ':')).encode())
    entry['context_sha256'] = sha(json.dumps(context, ensure_ascii=False, separators=(',', ':')).encode())
    return entry


def parse_log(path: Path, expected_head: str) -> dict:
    data = path.read_bytes()
    lines = clean_lines(data)
    entries, summaries, generated, heads = [], [], [], []
    score = None
    for index, line in enumerate(lines):
        match = HEADER.fullmatch(line)
        if match:
            end = index + 1
            while end < len(lines) and not (HEADER.fullmatch(lines[end]) or SEPARATOR.fullmatch(lines[end]) or SUMMARY.fullmatch(lines[end])):
                end += 1
            body = '\n'.join(lines[index + 1:end])
            entries.append(enrich({
                **match.groupdict(), 'line': int(match['line']), 'diff_context': body,
                'raw_log_header_line': index + 1, 'raw_log_diff_end_line': end,
            }))
        summary = SUMMARY.fullmatch(line)
        if summary:
            counts = {label.lower(): int(number.replace(',', '')) for number, label in re.findall(
                r'([\d,]+)\s+(untested|tested|timeout|uncovered|skipped|errors?)\b', summary[1], re.IGNORECASE,
            )}
            summaries.append({'raw_log_line': index + 1, 'text': line.strip(), 'counts': counts})
        created = CREATED.fullmatch(line)
        if created:
            generated.append({'mutations': int(created[1].replace(',', '')), 'files': int(created[2].replace(',', '')), 'raw_log_line': index + 1})
        if re.search(r'\bgit(?:\.exe)?\s+log\s+-1\s+--format=%H\b', line):
            for following in lines[index + 1:index + 4]:
                if re.fullmatch(r'[a-fA-F0-9]{40}', following.strip()):
                    heads.append(following.strip().lower())
                    break
        if re.match(r'^\s*Score:', line):
            score = line.strip()
    errors = []
    if len(summaries) != 1:
        errors.append('Expected exactly one complete mutation summary, found ' + str(len(summaries)) + '; do not silently merge or select runs.')
    ids = [entry['id'] for entry in entries]
    duplicate_ids = [identifier for identifier, count in collections.Counter(ids).items() if count > 1]
    if duplicate_ids:
        errors.append('Duplicate UNTESTED IDs in raw log: ' + ', '.join(duplicate_ids))
    if len(summaries) == 1 and summaries[0]['counts'].get('untested') != len(entries):
        errors.append('Parsed UNTESTED block count differs from the mutation footer.')
    if len(generated) == 1 and len(summaries) == 1:
        if sum(summaries[0]['counts'].values()) != generated[0]['mutations']:
            errors.append('Footer outcome counts do not sum to the generated mutation count.')
    if expected_head not in heads:
        errors.append('Expected checkout head was not verified from git log -1 --format=%H in this raw log.')
    return {
        'artifact': artifact(path), 'line_count': len(lines), 'checkout_heads': sorted(set(heads)),
        'expected_head': expected_head, 'summaries': summaries, 'generated': generated,
        'score_line': score, 'entries': entries, 'parse_errors': errors,
    }


def git_sources(repo: Path, commit: str) -> dict[str, bytes]:
    data = subprocess.check_output(['git', 'archive', commit, 'src'], cwd=repo)
    result = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:') as archive:
        for member in archive.getmembers():
            if member.isfile() and member.name.startswith('src/') and member.name.endswith('.php'):
                reader = archive.extractfile(member)
                if reader is None:
                    raise ValueError('Unreadable git archive member ' + member.name)
                result[member.name] = reader.read()
    return result


def source_alignment(repo: Path, old_head: str, new_head: str) -> tuple[dict, dict, dict]:
    old = git_sources(repo, old_head)
    new = git_sources(repo, new_head)
    if set(old) != set(new):
        raise ValueError('Source path inventory changed; the comment-only alignment premise needs fresh review.')
    maps, changed = {}, []
    for path in old:
        a, b = old[path].decode().splitlines(), new[path].decode().splitlines()
        if old[path] == new[path]:
            maps[path] = {line: line for line in range(1, len(a) + 1)}
            continue
        matcher = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
        mapping = {}
        hunks = []
        for kind, a0, a1, b0, b1 in matcher.get_opcodes():
            if kind == 'equal':
                mapping.update({i + 1: b0 + (i - a0) + 1 for i in range(a0, a1)})
            else:
                hunks.append({'kind': kind, 'baseline_lines': [a0 + 1, a1], 'final_lines': [b0 + 1, b1], 'removed': a[a0:a1], 'added': b[b0:b1]})
        maps[path] = mapping
        # This claim is deliberately narrower than semantic program equivalence.
        # Both changed files are also described by their exact removed/added lines.
        outside_docs_equal = re.sub(rb'/\*\*.*?\*/', b'', old[path], flags=re.S) == re.sub(rb'/\*\*.*?\*/', b'', new[path], flags=re.S)
        comment_shaped_lines = all(
            line.strip().startswith(('/**', '*'))
            for hunk in hunks for side in ['removed', 'added'] for line in hunk[side]
        )
        changed.append({
            'path': path, 'baseline_sha256': sha(old[path]), 'final_sha256': sha(new[path]),
            'baseline_lines': len(a), 'final_lines': len(b), 'hunks': hunks,
            'bytes_outside_phpdoc_blocks_equal': outside_docs_equal,
            'all_changed_lines_have_phpdoc_form': comment_shaped_lines,
        })
    if not all(item['bytes_outside_phpdoc_blocks_equal'] and item['all_changed_lines_have_phpdoc_form'] for item in changed):
        raise ValueError('Non-PHPDoc source changes found; do not assume mutation identities can be reconciled by stable code anchors.')
    metadata = {
        'baseline_head': old_head, 'final_head': new_head,
        'source_file_count': len(old), 'changed_file_count': len(changed), 'changed_files': changed,
        'method': 'Read immutable git archives in memory. SequenceMatcher equal source-line blocks map old mutation anchors to current anchors; changed PHPDoc text is preserved in hunks. No PHP or application code executes.',
        'source_files': [{'path': path, 'baseline_sha256': sha(old[path]), 'final_sha256': sha(new[path])} for path in sorted(old)],
    }
    return old, maps, metadata


def load_inputs(args) -> dict:
    catalogue_doc = json.loads(args.catalogue.read_text())
    entries = [enrich(entry) for entry in catalogue_doc['entries']]
    if len(entries) != 552 or len({e['id'] for e in entries}) != 552:
        raise ValueError('Expected the complete unique 552-ID starting catalogue.')
    aggregate = json.loads(args.aggregate.read_text())
    if aggregate.get('errors'):
        raise ValueError('Aggregate has mechanical errors; do not treat its witness set as final.')
    faults = [f for f in aggregate['executed_pest_tdd']['faults'] if f['kind'] == 'catalogued_production_mutant']
    witnesses = {f['id']: f for f in faults}
    if len(faults) != 57 or len(witnesses) != 57 or not set(witnesses).issubset({e['id'] for e in entries}):
        raise ValueError('Expected exactly 57 unique validated catalogue IDs contained in the 552 baseline records.')
    old_sources, maps, alignment = source_alignment(args.repo, args.baseline_head, args.final_head)
    for entry in entries:
        if sha(old_sources[entry['path']]) != entry['source_sha256']:
            raise ValueError('Catalogue source hash differs from baseline git source: ' + entry['path'])
        entry['predicted_final_line'] = maps[entry['path']].get(entry['line'])
    return {'catalogue_doc': catalogue_doc, 'entries': entries, 'witnesses': witnesses, 'alignment': alignment}


def candidate_matches(final: dict, baseline: list[dict]) -> dict:
    same_id = [b for b in baseline if b['id'] == final['id']]
    family = [b for b in baseline if b['path'] == final['path'] and b['mutator'] == final['mutator']]
    same_delta = [b for b in family if b['delta_sha256'] == final['delta_sha256']]
    aligned_delta = [b for b in same_delta if b['predicted_final_line'] == final['line']]
    same_context = [b for b in same_delta if b['context_sha256'] == final['context_sha256']]
    if same_id:
        item = same_id[0]
        if item in aligned_delta:
            return {'status': 'matched_same_id', 'baseline_id': item['id'], 'candidates': [item['id']], 'reason': 'ID, path, mutator, exact changed PHP lines and mapped source line all agree.'}
        return {'status': 'ambiguous', 'baseline_id': None, 'candidates': sorted({item['id']} | {b['id'] for b in aligned_delta}), 'reason': 'An exact ID exists but its code delta or mapped source anchor does not agree; no automatic match.'}
    if len(aligned_delta) == 1:
        item = aligned_delta[0]
        return {'status': 'matched_reidentified', 'baseline_id': item['id'], 'candidates': [item['id']], 'reason': 'New ID, same path/mutator/exact changed PHP lines and unique mapped executable source line.'}
    if len(aligned_delta) > 1:
        narrowed = [b for b in aligned_delta if b['context_sha256'] == final['context_sha256']]
        if len(narrowed) == 1:
            item = narrowed[0]
            return {'status': 'matched_reidentified', 'baseline_id': item['id'], 'candidates': [item['id']], 'reason': 'Mapped line and exact changed PHP lines admit siblings; unchanged printed context identifies one uniquely.'}
        return {'status': 'ambiguous', 'baseline_id': None, 'candidates': [b['id'] for b in aligned_delta], 'reason': 'Multiple baseline mutations share the exact delta and mapped source line.'}
    if len(same_context) == 1 and same_context[0]['predicted_final_line'] is None:
        item = same_context[0]
        return {'status': 'matched_reidentified', 'baseline_id': item['id'], 'candidates': [item['id']], 'reason': 'Exact delta and complete printed context uniquely agree; baseline anchor lies outside an equal line block.'}
    if same_delta:
        return {'status': 'ambiguous', 'baseline_id': None, 'candidates': [b['id'] for b in same_delta], 'reason': 'Exact code delta exists, but line/context alignment is not uniquely consistent.'}
    return {'status': 'unmatched_to_baseline_untested', 'baseline_id': None, 'candidates': [], 'reason': 'No exact delta match in the prior UNTESTED catalogue. This is not automatically a new defect or a newly generated mutation.'}


def compare(parsed: dict, inputs: dict) -> dict:
    rows = []
    for entry in parsed['entries']:
        rows.append({**entry, 'match': candidate_matches(entry, inputs['entries'])})
    assignments = collections.defaultdict(list)
    for row in rows:
        if row['match']['baseline_id']:
            assignments[row['match']['baseline_id']].append(row)
    for identifier, matching in assignments.items():
        if len(matching) > 1:
            for row in matching:
                row['match'] = {'status': 'ambiguous', 'baseline_id': None, 'candidates': [identifier], 'reason': 'Multiple final IDs map to one baseline ID; no greedy/non-bijective assignment is accepted.'}
    matched = {row['match']['baseline_id'] for row in rows if row['match']['baseline_id']}
    ambiguous = {candidate for row in rows if row['match']['status'] == 'ambiguous' for candidate in row['match']['candidates']}
    baseline_by_id = {entry['id']: entry for entry in inputs['entries']}
    witness_results = []
    for identifier, witness in sorted(inputs['witnesses'].items()):
        entry = baseline_by_id[identifier]
        present = [row for row in rows if row['match']['baseline_id'] == identifier]
        uncertain = [row for row in rows if row['match']['status'] == 'ambiguous' and identifier in row['match']['candidates']]
        if parsed['parse_errors']:
            status = 'unverified_incomplete_or_inconsistent_log'
        elif present:
            status = 'still_reported_untested'
        elif uncertain:
            status = 'ambiguous_possible_remaining_untested'
        elif entry['predicted_final_line'] is None:
            status = 'unverified_source_anchor'
        else:
            status = 'absent_from_final_untested'
        witness_results.append({
            'baseline_id': identifier, 'path': entry['path'], 'mutator': entry['mutator'],
            'baseline_line': entry['line'], 'predicted_final_line': entry['predicted_final_line'],
            'delta_sha256': entry['delta_sha256'], 'status': status,
            'matched_final_ids': [r['id'] for r in present], 'ambiguous_final_ids': [r['id'] for r in uncertain],
            'validated_declarations': witness['declarations'], 'validation_runtimes': witness.get('runtimes', []),
            'explanation': 'This checks reporting as UNTESTED in the actual final mutation run. Absence alone does not distinguish killed from timeout; per-ID timeout outcomes are not present in this log format.',
        })
    observed_counts = collections.Counter(row['match']['status'] for row in rows)
    counts = {status: observed_counts[status] for status in [
        'matched_same_id', 'matched_reidentified', 'ambiguous', 'unmatched_to_baseline_untested',
    ]}
    witness_counts = dict(collections.Counter(row['status'] for row in witness_results))
    absent = sorted(set(baseline_by_id) - matched - ambiguous)
    return {
        'final_survivor_records': rows, 'match_counts': counts,
        'baseline_ids_matched': sorted(matched), 'baseline_ids_ambiguous': sorted(ambiguous),
        'baseline_ids_not_matched_to_final_untested': absent,
        'validated_catalogue_witnesses': witness_results, 'witness_status_counts': witness_counts,
        'all_57_validated_witnesses_absent_from_untested': witness_counts == {'absent_from_final_untested': 57},
        'raw_identifier_comparison': {
            'baseline_ids_not_literally_present': sorted(set(baseline_by_id) - {row['id'] for row in rows}),
            'final_ids_not_literally_in_baseline': sorted({row['id'] for row in rows} - set(baseline_by_id)),
            'qualification': 'These are literal ID differences before source-context reconciliation; they must not be reported as newly discovered defects.',
        },
        'additional_baseline_ids_absent_without_prior_executed_witness': [
            {'id': identifier, 'path': baseline_by_id[identifier]['path'],
             'line': baseline_by_id[identifier]['line'], 'mutator': baseline_by_id[identifier]['mutator']}
            for identifier in absent if identifier not in inputs['witnesses']
        ],
    }


def prepare(args, inputs: dict) -> dict:
    baseline_log = parse_log(args.baseline_log, inputs['catalogue_doc']['execution_commit'])
    if baseline_log['parse_errors']:
        raise ValueError('Baseline parser control failed: ' + '; '.join(baseline_log['parse_errors']))
    if baseline_log['artifact']['sha256'] != inputs['catalogue_doc']['raw_log_sha256']:
        raise ValueError('Saved baseline raw log hash differs from the catalogue provenance.')
    parsed_by_id = {entry['id']: entry for entry in baseline_log['entries']}
    mismatches = []
    for entry in inputs['entries']:
        other = parsed_by_id.get(entry['id'])
        if other is None or any(entry[key] != other[key] for key in ['path', 'line', 'mutator', 'delta_sha256']):
            mismatches.append(entry['id'])
    if mismatches or len(parsed_by_id) != 552:
        raise ValueError('Baseline catalogue/parser disagreement: ' + ', '.join(mismatches))
    unmapped = [entry['id'] for entry in inputs['entries'] if entry['predicted_final_line'] is None]
    report = {
        'status': 'ready' if not unmapped else 'ready_with_unmapped_anchors_for_manual_review',
        'purpose': 'Preparation only. No final mutation result is asserted and no unfinished CI log was polled.',
        'generated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'script': artifact(Path(__file__)), 'catalogue': artifact(args.catalogue), 'aggregate': artifact(args.aggregate),
        'baseline_parser_control': {
            'raw_log': baseline_log['artifact'], 'checkout_heads': baseline_log['checkout_heads'],
            'parsed_untested': len(parsed_by_id), 'footer': baseline_log['summaries'][0],
            'catalogue_id_metadata_delta_mismatches': mismatches,
            'validated_witness_ids_present_in_original_catalogue': len(set(inputs['witnesses']) & set(parsed_by_id)),
        },
        'source_alignment': inputs['alignment'],
        'baseline_anchor_count': len(inputs['entries']), 'unmapped_baseline_anchor_ids': unmapped,
        'witness_ids': sorted(inputs['witnesses']),
        'future_command': ['python', str(Path(__file__)), '--log', str(BASE / 'final-ci/132816082600.log'), '--output', str(BASE / 'mutation-survivor-comparison.json')],
        'limits': [
            'No test, mutation, PHP process, network request or CI polling occurs in this script.',
            'ID changes are reconciled through exact diff content plus source-line mapping; unresolved matches remain explicit.',
            'The original catalogue contains only previous UNTESTED mutants, not all generated mutations. An unmatched final record is not automatically a new defect.',
            'Final absence from UNTESTED cannot independently distinguish a killed mutation from a timeout.',
        ],
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--log', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--final-catalogue-output', type=Path)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--catalogue', type=Path, default=BASE / 'survivors-detail.json')
    parser.add_argument('--aggregate', type=Path, default=BASE / 'aggregate-review.json')
    parser.add_argument('--baseline-log', type=Path, default=BASE.parent / 'reaudit/ci-132782343098.raw.log')
    parser.add_argument('--baseline-head', default=BASELINE_HEAD)
    parser.add_argument('--final-head', default=FINAL_HEAD)
    args = parser.parse_args()
    if args.prepare == bool(args.log):
        parser.error('Select exactly one mode: --prepare, or --log <completed raw log>.')
    inputs = load_inputs(args)
    if args.prepare:
        report = prepare(args, inputs)
        destination = args.output or BASE / 'mutation-comparison-readiness.json'
        summary = {'status': report['status'], 'baseline_untested': 552, 'validated_witnesses': 57,
                   'unmapped_source_anchors': len(report['unmapped_baseline_anchor_ids']),
                   'changed_source_files': report['source_alignment']['changed_file_count']}
    else:
        parsed = parse_log(args.log, args.final_head)
        comparison = compare(parsed, inputs)
        report = {
            'status': 'complete' if not parsed['parse_errors'] else 'incomplete_or_inconsistent_log',
            'generated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'script': artifact(Path(__file__)), 'catalogue': artifact(args.catalogue), 'aggregate': artifact(args.aggregate),
            'baseline_mutation_execution_commit': inputs['catalogue_doc']['execution_commit'],
            'baseline_source_snapshot': args.baseline_head, 'final_source_snapshot': args.final_head,
            'source_alignment': inputs['alignment'],
            'final_log': {key: value for key, value in parsed.items() if key != 'entries'},
            'baseline_untested_count': 552, 'actual_final_untested_count': len(parsed['entries']),
            **comparison,
            'limits': [
                'The final count and witnesses are read from the completed raw CI log; source comparison is static and does not rerun tests or mutants.',
                'Mapped new IDs refer to the same exact changed PHP lines at corresponding source anchors, not automatically to new defects.',
                'Unmatched and ambiguous records require explicit follow-up interpretation; they are never silently assigned to a baseline witness.',
                'A catalogue ID absent from UNTESTED is not independently classified as killed versus timeout because this raw format lacks per-ID timeout detail.',
                'The historical baseline and final jobs are distinct CI executions, not a paired performance experiment.',
            ],
        }
        destination = args.output or BASE / 'mutation-survivor-comparison.json'
        final_catalogue_path = args.final_catalogue_output or destination.with_name('survivors-final.json')
        final_hashes = {entry['path']: entry['final_sha256'] for entry in inputs['alignment']['source_files']}
        final_catalogue = {
            'schema_version': 1, 'execution_commit': args.final_head,
            'source_job_from_log_filename': int(args.log.stem) if args.log.stem.isdigit() else None,
            'raw_log': parsed['artifact'], 'checkout_heads_verified': parsed['checkout_heads'],
            'parsed_untested_count': len(parsed['entries']), 'reported_mutation_summaries': parsed['summaries'],
            'parser': artifact(Path(__file__)), 'parse_errors': parsed['parse_errors'],
            'entries': [
                {**{key: entry[key] for key in ['path', 'line', 'mutator', 'id', 'diff_context', 'raw_log_header_line', 'raw_log_diff_end_line']},
                 'source_sha256': final_hashes[entry['path']]}
                for entry in parsed['entries']
            ],
        }
        final_catalogue_path.write_text(json.dumps(final_catalogue, indent=2, ensure_ascii=False) + '\n')
        report['parsed_final_catalogue'] = artifact(final_catalogue_path)
        report['reconciliation_totals'] = {
            'baseline_untested': 552, 'final_untested': len(parsed['entries']),
            'same_ids': comparison['match_counts']['matched_same_id'],
            'reidentified_ids': comparison['match_counts']['matched_reidentified'],
            'ambiguous': comparison['match_counts']['ambiguous'],
            'unmatched_to_previous_untested': comparison['match_counts']['unmatched_to_baseline_untested'],
            'baseline_ids_absent_after_reconciliation': len(comparison['baseline_ids_not_matched_to_final_untested']),
            'validated_witness_ids_absent': comparison['witness_status_counts'].get('absent_from_final_untested', 0),
            'additional_absent_without_prior_witness': len(comparison['additional_baseline_ids_absent_without_prior_executed_witness']),
            'literal_id_removals_before_reconciliation': len(comparison['raw_identifier_comparison']['baseline_ids_not_literally_present']),
            'literal_new_ids_before_reconciliation': len(comparison['raw_identifier_comparison']['final_ids_not_literally_in_baseline']),
        }
        summary = {'status': report['status'], 'baseline_untested': 552,
                   'actual_final_untested': report['actual_final_untested_count'],
                   'matches': report['match_counts'], 'witnesses': report['witness_status_counts'],
                   'all57_absent_from_untested': report['all_57_validated_witnesses_absent_from_untested'],
                   'parse_errors': parsed['parse_errors']}
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({**summary, 'output': str(destination), 'sha256': sha(destination.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
