from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, tarfile, datetime

base=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/8f6c1df8ef3b/di')
out=base/'preserved-variants-proof'
isolated=out/'isolated'
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
out.mkdir(exist_ok=False)
isolated.mkdir()
data=subprocess.check_output(['git','archive',baseline,'--','src','tests','composer.json','phpunit.xml','.php-cs-fixer.dist.php','phpstan.neon.dist'],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    archive.extractall(isolated,filter='data')
vendor=isolated/'vendor';vendor.mkdir()
for entry in (repo/'vendor').iterdir():
    target=vendor/entry.name
    if entry.name in ['composer','bin','pestphp']:
        shutil.copytree(entry,target,symlinks=False)
    elif entry.is_file():shutil.copy2(entry,target)
    else:target.symlink_to(entry,target_is_directory=True)


bootstrap=base/'core/proof-bootstrap.php'
classes=['Componenta\\DI\\Container','Componenta\\DI\\Internal\\AliasResolver','Componenta\\DI\\Internal\\EntryCache','Componenta\\DI\\Internal\\Resolver\\Parameter\\VariadicArguments','Componenta\\DI\\Resolver\\Parameter\\ParametersResolver']
records=[]
evidence={'baseline':baseline,'purpose':'Retain original inline-decorator and variadic-only variants while preserving the newly proved boundary checks.','scope':'Entire corresponding test file in each of four phases, on PHP84/85.','records':records}
cases=[
 {'id':'645741cb54a634ec','source':'src/Container.php','test':'tests/Contract/AliasPipelineInvalidationContractTest.php','needle':'$dependencyId = (string) $dependencyId;','replacement':'$dependencyId = $dependencyId;'},
 {'id':'de65523c18587937','source':'src/Internal/Resolver/Parameter/VariadicArguments.php','test':'tests/Contract/VariadicResolutionContractTest.php','needle':'[$target->position, array_values($values)]','replacement':'[$target->position, $values]'},
]
def run(label,version,expected,whole=False):
    origins=out/(label+'-php'+version+'-origins.json')
    hashes={cls:hashlib.sha256((isolated/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()).hexdigest() for cls in classes}
    env=os.environ.copy();env.update({'R3_CORE_ROOT':str(isolated),'R3_CORE_PROVENANCE':str(origins),'R3_CORE_HASHES':json.dumps(hashes)})
    command=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-d','opcache.enable_cli=0','vendor/bin/pest']
    command += [str(test.relative_to(isolated))]
    command += ['--bootstrap='+str(bootstrap),'--compact','--colors=never','--do-not-cache-result','--order-by=random','--random-order-seed=2026111533']
    before={str(p.relative_to(isolated)):hashlib.sha256(p.read_bytes()).hexdigest() for prefix in ['src','tests'] for p in (isolated/prefix).rglob('*') if p.is_file()}
    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    process=subprocess.run(command,cwd=isolated,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    log=out/(label+'-php'+version+'.log');log.write_bytes(process.stdout)
    after={str(p.relative_to(isolated)):hashlib.sha256(p.read_bytes()).hexdigest() for prefix in ['src','tests'] for p in (isolated/prefix).rglob('*') if p.is_file()}
    record={'label':label,'php':version,'started_utc':timestamp,'command':command,'cwd':str(isolated),'exit':process.returncode,'expected_exit':expected,'log':str(log),'log_sha256':hashlib.sha256(process.stdout).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'mutant':case['id'],'source':case['source'],'test':case['test'],'origins':str(origins),'unchanged_during_run':before==after,'source_test_fingerprint':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
    if origins.exists():
        record['origins_sha256']=hashlib.sha256(origins.read_bytes()).hexdigest()
        origin_data=json.loads(origins.read_text());assert origin_data['pest_root']==str(isolated)
    records.append(record);(out/'proof.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(label,version,process.returncode,process.stdout.decode(errors='replace')[-300:],flush=True)
    assert process.returncode==expected and origins.exists() and before==after,(label,process.returncode)

for case in cases:
    source=isolated/case['source']; original=source.read_text()
    test=isolated/case['test']; old=test.read_bytes(); improved=(repo/case['test']).read_bytes()
    try:
        for version in ['84','85']:run(case['id']+'-old-production',version,0)
        assert original.count(case['needle'])==1
        source.write_text(original.replace(case['needle'],case['replacement']))
        for version in ['84','85']:run(case['id']+'-old-mutant',version,0)
        test.write_bytes(improved)
        for version in ['84','85']:run(case['id']+'-new-mutant',version,1)
        source.write_text(original)
        for version in ['84','85']:run(case['id']+'-new-production',version,0)
    finally:
        source.write_text(original);test.write_bytes(old)
        (out/'proof.json').write_text(json.dumps(evidence,indent=2)+'\n')
