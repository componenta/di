from pathlib import Path
import collections
import copy
import datetime
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
ROUND = BASE.parent
REPO = Path('/workspace/scratch/8f6c1df8ef3b/di')
BASELINE = '2eb36241787a971e1a8185149aaa08b90304d426'
FINAL_SNAPSHOT = sys.argv[1] if len(sys.argv) > 1 else '141feff3d4747a70a2d4ac4c3841de53eb55fa73'
REVIEWER = '/root/attributes_audit'
sha = lambda value: hashlib.sha256(value).hexdigest()

checkpoint = BASE / 'fresh-baseline-manual-review.json'
if not checkpoint.exists():
    checkpoint.write_bytes((BASE / 'review.json').read_bytes())
review = json.loads(checkpoint.read_text())
ast_path = ROUND / 'final-test-declarations.json'
ast = json.loads(ast_path.read_text())
survivor_path = BASE / 'survivor-review.json'
survivor = json.loads(survivor_path.read_text())
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()

def ref(path):
    p = Path(path)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}

file_notes = {
    'CallableCacheParityContractTest.php': 'Reviewed the uncached comparison control, resolver counters, all callable forms, rebound scopes, diagnostics, weak ownership and repeated reflector fixtures. Parity comparisons are distinguished from independent expected-value assertions; only the explicit weak-reference tests establish collection.',
    'CallableCaseCacheRetentionContractTest.php': 'Reviewed disposable-container warmup, native symbol spelling effects, measured container separation and the bounded allocation oracle across three case-variation datasets. This is a policy-specific retention budget, not a wall-clock benchmark or proof that all allocations vanish.',
    'CallableFailureDiagnosticsContractTest.php': 'Reviewed missing service versus inaccessible/missing method ownership and repeated failures. Strengthened class/method cache-key separation with two legal aliases whose undelimited names collide; exact public exception metadata now distinguishes the owners.',
    'CallableInvocationSnapshotContractTest.php': 'Reviewed mutations occurring inside resolver support/value callbacks and the current invocation boundary. Side-effect observations and recovery calls distinguish a frozen invocation from accidental reuse of stale classifications.',
    'CallableMagicRetentionContractTest.php': 'Reviewed arbitrary magic name streams and collection of instance owners. The tests cover retention of input history and owner lifetimes, while ordinary native symbol interning is outside the owner-collection assertion.',
    'CallableNameBoundariesContractTest.php': 'Reviewed case-insensitive native declaration names alongside case-sensitive opaque service IDs and late autoload. The assertions separate native lookup normalization from service registry identity.',
    'CallablePlanIsolationContractTest.php': 'Reviewed plan owner isolation and shared callable identity across containers. Assertions exercise different dependency environments instead of inspecting private cache slots.',
    'ClassDefinitionRequestTransportTest.php': 'Reviewed ClassDefinition forwarding of HTTP transport and the boundary between transport context and ordinary constructor parameters. Request identity is checked at the consuming entry.',
    'ClosureParameterResolutionContractTest.php': 'Reviewed distinct/rebound closure signatures and explicit parameter overrides. The fixtures keep declaration metadata separate from the closure owner and runtime values.',
    'CompletedParameterAttributesContractTest.php': 'Reviewed completed-parameter metadata changes caused by later resolver/autoload activity. Failure and side-effect assertions exercise the completion fence rather than only checking a final value.',
    'InternalCallableDefaultsContractTest.php': 'Reviewed native omission versus explicit null, named arguments after gaps, internal constructors, bootstrap replacement and ordinary defaults. Added a real PDO native optional-plus-variadic witness; extension absence is explicitly skipped and both local PHP runtimes executed the witness.',
    'LateParameterTransformerContractTest.php': 'Reviewed late attribute transformer availability and classification refresh. Tests distinguish attributes discovered after initial metadata inspection from repeated construction of already-known handlers.',
    'MagicCallableSyntaxContractTest.php': 'Reviewed native magic routing, exact service-ID precedence and invalid methods. Expanded both instance/static magic owners and string/array forms to __invoke and __INVOKE, preserving method spelling and complete positional arguments.',
    'NativeCallableInvokerContractTest.php': 'Reviewed strict native invocation, argument layout, prepared arguments and native exceptions. A title mentioning non-retention is not treated as an independent weak-reference lifetime proof where assertions only observe results.',
    'NumericRequestMappingContractTest.php': 'Reviewed numeric transport keys and named DTO mapping. The negative oracle rejects positional injection instead of accepting accidental PHP argument rebinding.',
    'ParameterClassificationRefreshContractTest.php': 'Reviewed mutable classification and invocation-time refresh; resolver support counters and output values jointly distinguish cached metadata from cached resolver results.',
    'ParameterExecutionRevisionContractTest.php': 'Reviewed revision changes during resolver execution and the recovery path. The test observes the revision boundary through public invocation behavior.',
    'ParameterPipelineContractTest.php': 'Reviewed priority, null continuation, resolver context and the generic positional/named source chain. Assertions distinguish a resolved null from absence and verify already-resolved inputs.',
    'ParameterTargetContractTest.php': 'Reviewed target reflection metadata, attribute grouping and cacheability. Factory-created target identity is separated from constructor-created reflectors and runtime invocation values.',
    'ParameterTargetDiscoveryContractTest.php': 'Reviewed unknown names, autoload failure, interfaces, aliases and repeated discovery. Native class availability is used without permanently negative-caching names; cleanup of registered loaders is explicit.',
    'ParameterTargetFirstAttributeDiscoveryContractTest.php': 'Reviewed first-match order across initially unavailable attribute classes and single instantiation after discovery. Assertions distinguish selecting a reflector from constructing its attribute instance.',
    'Php85AttributeCallableContractTest.php': 'Reviewed all four declarations, fixture subprocess handling and version-local expectations. Native callable syntax probes and E1 trait-boundary observations are not evidence for release provenance or a promise that every PHP 8.5 feature is supported.',
    'PreparedCallableContractTest.php': 'Reviewed adapter reuse, mutation refresh, callable binding and ownership. Prepared metadata is not treated as a frozen set of dependency values.',
    'RelativeTypeInspectionContractTest.php': 'Reviewed self/parent resolution and intersection acceptance against declaration context. The positive intersection cases alone do not independently establish every negative DNF/intersection branch.',
    'RequestAndProxyBoundariesContractTest.php': 'Reviewed mapped request, authority and lazy/proxy boundary combinations with explicit request identity and side-effect checks. Proxy timing is distinguished from request-source provenance.',
    'RequestCacheParityContractTest.php': 'Reviewed repeated requests through warmed/fresh callable and mapping paths. Different request/dependency identities catch value reuse, but identity assertions are not reported as whole-container weak-reference collection tests.',
    'RequestExtractorBoundariesContractTest.php': 'Reviewed inferred names, required values, invalid extraction shapes and failure ownership. Exact values and public exception contracts are separated from compatible-class/message matching.',
    'RequestExtractorDefaultsContractTest.php': 'Reviewed absent versus explicitly null source values and extractor-owned defaults. Dataset outcomes distinguish fallback decisions from target-language defaults.',
    'RequestMappingBoundariesContractTest.php': 'Reviewed map/exclude/default/cast and nested DTO boundaries. Exact output maps and negative source collisions are evaluated separately from helper implementation details.',
    'RequestProviderRecoveryContractTest.php': 'Reviewed lazy provider failure followed by recovery and current-container ownership. A failed provider lookup is not allowed to poison the next request.',
    'RequestSharedSourcesContractTest.php': 'Reviewed selected and wildcard shared request attributes/files, duplicate conflicts and identity of shared values. Selection is tested independently from generic transport keys.',
    'RequestSourceAvailabilityContractTest.php': 'Reviewed request-source metadata that appears after an earlier availability probe and the mapped DTO guard. This does not settle every diagnostic contract for permanently unavailable DTO classes.',
    'RequestSourceDiscoveryContractTest.php': 'Reviewed attribute class discovery and side effects before mapping a request DTO. The guard is exercised through source ownership, not private metadata cache contents.',
    'RequestValidationFailureContractTest.php': 'Reviewed failed validation propagation and object identity at the public boundary. Validation failure is kept separate from extraction/casting failures.',
    'SealedParameterPipelineContractTest.php': 'Reviewed sealed resolver registration and the state visible to invocation. The fixture observes public mutation rejection rather than depending on a particular collection implementation.',
    'UnionAutowiringContractTest.php': 'Reviewed all named/union/intersection/DNF availability, ambiguity, explicit override and contextual-type cases. Added two real PHP 8.4 contextual alias counterexamples with explicit PHP 8.5 compile-boundary skip; no PHP 8.5 mutant kill is claimed for those cases.',
    'VariadicEnvironmentContractTest.php': 'Reviewed environment-provided variadic collections and scalar conversion constraints. Missing input and an explicit collection remain separate invocation cases.',
    'VariadicResolutionContractTest.php': 'Reviewed every variadic shape, fixed prefix, custom resolver, by-reference rejection and collection transformer. The final dataset preserves both pure variadic and fixed-leading variants; root final controlled proof is canonical for the expanded declaration.',
    'CallableContractTest.php': 'Reviewed public callable/prepared boundaries, parameter filtering and error propagation. Invocation output assertions and lifetime assertions are not conflated.',
    'CallableResolutionContractTest.php': 'Reviewed every documented callable form, identity and opaque ID precedence. Added the object-service/missing-method dataset so an invalid method cannot fall through to a generic callable-value diagnostic.',
    'CallableRetentionTest.php': 'Reviewed callable owner, closure and prepared-adapter weak references with explicit release/collection. Tests keep the container alive while checking that invocation-owned inputs are not retained.',
    'ClassDefinitionRequestParityTest.php': 'Reviewed request forwarding through class definitions and nested mapped DTO construction. Assertions compare actual contextual values and conflicts at the public construction boundary.',
    'ConfigProviderCompositionParityTest.php': 'Reviewed configuration providers and resolver/factory composition. An invokable class may also be autowired, so a class-only successful result does not independently prove the numeric provider registration route.',
    'CurrentRequestAttributesSmokeTest.php': 'Reviewed current request/URI smoke cases with supplied HTTP transport and authoritative source semantics. These are integration value checks, not an exhaustive mapping matrix.',
    'CurrentRequestContextTest.php': 'Reviewed current request/URI authority, unavailable context, constructor rejection and bare types. Strengthened the bare union case so excluding canonical request transport does not suppress a valid UriInterface keyed alternative; the expected URI object is captured once.',
    'ParameterAttributeCompositionTest.php': 'Reviewed provider/transformer combinations and invalid source composition across constructor and callable parameters. Side-effect counters distinguish planning rejection from execution.',
    'ParameterResolverContractTest.php': 'Reviewed resolver support, priority, context, null continuation and reserved core wiring. Assertions cover public behavior and recovery rather than only instance types.',
    'ParameterResolverPriorityParityTest.php': 'Reviewed deterministic priority and equal-priority registration behavior with observed resolver events and values. No timing or undocumented tie-breaking policy is inferred beyond the fixtures.',
    'PreparedParameterPlanTest.php': 'Reviewed prepared-plan refresh and contextual resolution against a fresh invocation. Prepared plans retain metadata and owner identity, not previously resolved input values.',
    'RequestActorAliasParityTest.php': 'Reviewed request-derived actor identity through alias resolution. The exact request-owned actor distinguishes source lookup from unrelated caller parameters.',
    'RequestExtractorIsolationTest.php': 'Reviewed extraction across distinct requests/containers and failure/retry paths. Mutable extractor/provider state is not allowed to leak resolved values between invocations.',
    'RequestLazyAliasParityTest.php': 'Reviewed lazy aliased request construction and initialization-time context. Identity and constructor observations distinguish alias routing from eager creation.',
    'RequestMappingContractTest.php': 'Reviewed all mapper contracts, DTO/default/cast boundaries and conflict policies, including exact output maps. Unsupported malformed mapper configuration is distinguished from valid missing-source input.',
    'RequestMappingTest.php': 'Reviewed all PSR-7 sources, nested request provenance, wildcard selection and mapper failures. Strengthened absent parsed-body, accepted-duplicate tail and Query-before-selected-Attributes FirstWins behavior; all original valid duplicate variants remain present.',
    'RequestTypedKeyParityTest.php': 'Reviewed exact canonical transport keys, compatible typed alternatives, named/positional overrides and exclusion of transport from generic typed DI. The cases assert identity and rejection at the public API boundary.',
    'SpecializedRequestMapperSelectionTest.php': 'Reviewed specialized request attributes/files mapping selection independently from the general MapRequest convenience behavior. Exact selected maps distinguish wildcard inclusion from named selection.',
    'ValueResolutionParityTest.php': 'Reviewed attribute source precedence, casts, property creation context, environment conversion and missing entries. Added named/positional explicit null, valid second typed key and non-transport union arm; a title referring to initialized property state is not stronger than its actual fixture.',
}

renames = {
    ('tests/V5/RequestMappingTest.php', 'MapRequest FirstWins keeps the first provider value for duplicate source keys'):
        'MapRequest preserves source order and later fields after accepted duplicate keys',
    ('tests/V5/ValueResolutionParityTest.php', 'explicit named parameters keep precedence over Config parameter resolution'):
        'explicit parameters including null keep precedence over Config parameter resolution',
}

def manual(contract, oracle, fault, dataset, limit, labels):
    return {
        'contract': contract, 'actual_oracle': oracle, 'meaningful_fault_counterexample': fault,
        'dataset_edges': dataset, 'quality_finding_or_limitation': limit,
        'evidence_status': 'executed_RED_with_four_phase_controls', 'proof_labels': labels,
    }

updates = {
 ('tests/Contract/MagicCallableSyntaxContractTest.php', 'string and array callable syntax preserve magic arguments'): manual(
    'Native magic __call/__callStatic may resolve a method named __invoke without the owner being a Closure or an invokable instance.',
    'Both string and array syntax must return the exact original method spelling and complete positional input array for the same owner.',
    'CallableExecutor InstanceOfToTrue replaces a magic callable tuple with a non-callable owner when its method is __invoke or __INVOKE.',
    'Instance and static owner modes crossed with dynamic, __invoke and __INVOKE names; existing ordinary syntax cases remain.',
    'A real native magic dispatch counterexample. This proof is not attributed to distinct Internal/functions trampoline mutations.', ['magic-invoke']),
 ('tests/Contract/CallableFailureDiagnosticsContractTest.php', 'method classification remains specific to both declaring class and method across repeated failures'): manual(
    'The callable classification cache must keep declaring class and method boundaries distinct across repeated failures.',
    'Two legal class aliases form an undelimited method-plus-class collision; explicit InvalidCallableException metadata distinguishes inaccessible method from the absent owner service, repeatedly.',
    'ConcatSwitchSides in CallableResolver class/method cache key aliases two supported method specifications and reuses the wrong diagnostic classification.',
    'Both owner/method pairs are invoked twice; old independent class/method checks remain.',
    'Opaque service IDs and legal native class aliases are used; the assertion does not pin a private cache-key string format.', ['callable-classification-boundary']),
 ('tests/V5/CallableResolutionContractTest.php', 'public resolve reports invalid callable specifications precisely'): manual(
    'An object service with no requested method must fail as an invalid method specification, with the public diagnostic for that method.',
    'The existing invalid callable dataset gains [not.callable, missing] and requires the missing-method message substring in InvalidCallableException.',
    'AND-to-OR in CallableResolver::resolveMethod lets an invalid object/method tuple pass and changes failure ownership to a generic callable-value error.',
    'All previous invalid value/string/array forms plus the object-service/missing-method tuple.',
    'toThrow(class, message) checks a compatible exception class and literal message substring, not identity or exact full text.', ['callable-service-method']),
 ('tests/V5/CurrentRequestContextTest.php', 'bare request and URI types do not imply the current HTTP context'): manual(
    'The canonical request transport key is excluded from generic type injection, while a distinct compatible URI arm remains eligible in a bare union.',
    'Original bare request/URI negative and explicit override assertions remain; ServerRequestInterface|UriInterface returns the exact captured URI object keyed by UriInterface.',
    'ArrayTypedResolver continue-to-break stops scanning the union after the transport arm and loses the valid following typed key.',
    'Single request type, single URI type and request-or-URI union; expected URI is obtained once before invocation.',
    'The test does not rely on companion getUri() returning the same object across separate calls.', ['request-typed-union']),
 ('tests/V5/ValueResolutionParityTest.php', 'explicit parameters including null keep precedence over Config parameter resolution'): manual(
    'Explicit generic parameter presence, including null, overrides a Config provider when the nullable target accepts it.',
    'Named non-null, named null and positional null each construct ConfigOverrideTarget and assert the exact expected property value; the fixture property is nullable.',
    'AttributeParameterResolver isset() on a positional key treats present null as absent and falls back to the configured string.',
    'Named value, named null and positional null datasets with a non-null configured fallback.',
    'Null is a supported declared value here; this is not a malformed-type mutation test.', ['attributed-positional-null']),
 ('tests/V5/ValueResolutionParityTest.php', 'HTTP request transport is not a generic attributed typed override'): manual(
    'Canonical HTTP transport must not become a generic attributed override; excluding it must still allow a compatible second union arm.',
    'Original request transport assertions remain, and an attributed ServerRequestInterface|AttributedTypedOverrideA fixture returns the exact supplied A instance keyed by A.',
    'AttributeParameterResolver transport continue-to-break prevents scanning the later ordinary typed override key.',
    'Request-only transport exclusion plus mixed request/ordinary class union.',
    'This does not relax authoritative request-source attributes: it tests ordinary attributed typed override semantics.', ['attributed-request-union']),
 ('tests/V5/ValueResolutionParityTest.php', 'attributed typed overrides must satisfy the type named by their key'): manual(
    'A supplied typed override must match its own key, and a valid later union type key must be considered when the first key is absent.',
    'Existing invalid-key/value and valid-first-key assertions remain; a B-only supplied key is required to return the exact B instance.',
    'AttributeParameterResolver continue-to-break on an absent first union key prevents valid later-key lookup.',
    'Incompatible value under a first class key, compatible first key and absent-first/valid-second key.',
    'The additional case distinguishes key traversal from general union acceptance.', ['attributed-second-type-key']),
 ('tests/V5/RequestMappingTest.php', 'MapRequest exposes every declared PSR-7 source through one public mapping'): manual(
    'Every configured PSR-7 source contributes its mapped values; a null parsed body contributes an empty payload source.',
    'An exact complete source map is asserted, including uploaded-file identity, with payload present and absent.',
    'Removing MapRequest null-body return calls get_object_vars(null), rejecting a valid absent PSR parsed body.',
    'Boolean dataset parsed payload / absent parsed body; all other source bags remain populated in both cases.',
    'Peer source discovery by core; test/proof executed by attributes. This proof snapshot predates later independent declarations in the same file.', ['request-null-payload']),
 ('tests/V5/RequestMappingTest.php', 'MapRequest preserves source order and later fields after accepted duplicate keys'): manual(
    'Accepted duplicate values preserve subsequent unique keys, and explicit source ordering remains authoritative when selected attributes are also configured.',
    'Each dataset asserts exactly id plus after. FirstWins payload/query chooses payload; Reject with identical duplicate keeps payload and tail; Query then selected Attributes chooses query, excludes an unselected attribute and keeps tail.',
    'RequestMapper continue-to-break drops the unique tail; MapRequest AND-to-OR preinserts selected Attributes and changes FirstWins from query to attribute.',
    'Three named datasets retain both original duplicate variants and add Query-before-selected-Attributes; explicit concrete fixture class selection keeps static types precise.',
    'Both mutations were executed, with distinct exact snapshot hashes. The source-order proof uses already-strengthened old tests; earlier duplicate-tail proof predates this additional dataset.', ['request-duplicate-tail', 'request-source-order']),
 ('tests/Contract/VariadicResolutionContractTest.php', 'attributes provide and transform a variadic collection once per invocation'): manual(
    'Variadic attribute providers/transformers receive one properly reindexed argument collection per invocation, including after a fixed positional prefix.',
    'Exact returned collections, caster call count four and every input collection are asserted; observed positional collections must be [one,two] with keys0,1.',
    'Removing array_values in VariadicArguments keeps positional keys1,2 after the prefix; a key-preserving caster can expose this supported input difference.',
    'Final root dataset preserves pure variadic and fixed-parameter-then-variadic signatures; configured, positional, explicit empty and absent transformer-only inputs.',
    'Root final preserved-variants proof is canonical for the expanded current bytes. The earlier attributes proof is retained as a predecessor, not counted as a second distinct mutation.', ['variadic-collection-keys']),
}

new_tests = {
 ('tests/Contract/UnionAutowiringContractTest.php', 'PHP 8.4 contextual union aliases select one deterministic service id'): manual(
    'PHP 8.4 contextual aliases denoting one native class deduplicate case-insensitively and select one deterministic exact service ID.',
    'A runtime-generated self|lowercase-FQ-self signature has distinct exact-ID bindings pointing to distinct objects of the same class; public invocation must return the canonical object by identity.',
    'Removing strtolower reports false ambiguity; changing first-wins coalescing to assignment selects the other exact service ID.',
    'Two actual mutation variants execute on PHP84. PHP85 explicitly skips because native compilation rejects the redundant contextual union.',
    'No PHP85 mutant RED or DI production bug is claimed for its native compile rejection. Randomized fixture names avoid repeated declaration collisions; the lowercase versus canonical ordering remains deterministic.', ['union-context-case-dedup', 'union-context-case-choice']),
 ('tests/Contract/InternalCallableDefaultsContractTest.php', 'internal optional gaps reject positional variadic tails before native invocation'): manual(
    'A positional variadic tail cannot follow an intentionally omitted native optional argument, because it would bind to the wrong native parameter.',
    'A real PDOStatement::fetchAll call omits mode and supplies string-valued positional args; ResolutionException must contain the native-omission diagnostic before native mode binding.',
    'Removing array_keys checks variadic values instead of keys, misses the positional tail and produces a different native TypeError diagnostic.',
    'SQLite in-memory query creates a real internal method fixture. Explicit availability skip applies only if PDO/SQLite is absent; PHP84 and PHP85 local canonical phases executed it.',
    'toThrow uses compatible exception class and substring message. This does not require PDO SQLite for consumers or claim coverage on a runtime where the test is skipped.', ['native-optional-variadic']),
}

manual_fields = ['contract', 'actual_oracle', 'meaningful_fault_counterexample', 'dataset_edges', 'quality_finding_or_limitation', 'evidence_status']
baseline_tests = {}
current_tests = {}
for file in review['files']:
    path = file['path']
    raw = (REPO / path).read_bytes()
    file['baseline_lines'] = file['lines']
    file['current_sha256'] = sha(raw)
    file['current_lines'] = len(raw.splitlines())
    file['lines'] = file['current_lines']
    file['current_bytes_verified_utc'] = now
    file['reviewer'] = REVIEWER
    file['changed_since_baseline'] = file['baseline_sha256'] != file['current_sha256']
    if file['scope'] == 'production':
        assert file['review_notes']
        assert not file['changed_since_baseline'], ('Assigned source changed after fresh read', path)
        continue
    assert file['current_sha256'] == ast[path]['sha256'], ('AST stale', path)
    file['review_notes'] = file_notes[Path(path).name]
    current = {t['name']: t for t in ast[path]['tests']}
    processed = []
    for old in file['tests']:
        t = copy.deepcopy(old)
        baseline_tests[(path, old['name'])] = old
        name = renames.get((path, old['name']), old['name'])
        declaration = current.pop(name)
        for key in ['name', 'line', 'end_line', 'body_sha256']:
            t['baseline_' + key] = old[key]
        t.update(declaration)
        t['current_line'] = declaration['line']
        t['current_end_line'] = declaration['end_line']
        t['current_body_sha256'] = declaration['body_sha256']
        t['reviewer'] = REVIEWER
        t['current_body_reviewed'] = True
        t['added_in_round3'] = False
        if (path, name) in updates:
            t['baseline_manual_review'] = {k: old[k] for k in manual_fields}
            t.update(updates[(path, name)])
            t['current_oracle_freshly_reviewed'] = True
        else:
            assert old['body_sha256'] == declaration['body_sha256'], ('Unreviewed changed body', path, name)
        t['baseline_runtime_case_ids'] = []
        t['current_runtime_case_ids'] = None
        current_tests[(path, name)] = t
        processed.append(t)
    for name, declaration in current.items():
        key = (path, name)
        assert key in new_tests, ('Unreviewed new declaration', key)
        t = {**declaration, **new_tests[key], 'reviewer': REVIEWER, 'fresh_manual_review': True,
             'current_body_reviewed': True, 'current_oracle_freshly_reviewed': True, 'added_in_round3': True,
             'baseline_name': None, 'baseline_line': None, 'baseline_end_line': None, 'baseline_body_sha256': None,
             'current_line': declaration['line'], 'current_end_line': declaration['end_line'],
             'current_body_sha256': declaration['body_sha256'], 'baseline_runtime_case_ids': [], 'current_runtime_case_ids': None}
        processed.append(t)
        current_tests[key] = t
    file['tests'] = sorted(processed, key=lambda t: t['line'])
    file['baseline_test_declaration_count'] = len(file['baseline_declarations'])
    file['current_test_declaration_count'] = len(file['tests'])

baseline_cases = {}
for runtime in ['84', '85']:
    xml_path = ROUND / ('baseline' + runtime + '.xml')
    tree = ET.parse(xml_path)
    for case in tree.findall('.//testcase'):
        source = case.get('file', '').split('::', 1)[0]
        candidates = []
        for (path, name), t in baseline_tests.items():
            if path != source:
                continue
            for prefix in [name, 'it ' + name]:
                if case.get('name') == prefix or case.get('name', '').startswith(prefix + ' with data set '):
                    candidates.append((path, name))
                    break
        if not candidates:
            assert not any(path == source for path, name in baseline_tests), ('Unmapped baseline case', source, case.attrib)
            continue
        assert len(candidates) == 1, ('Ambiguous case', case.attrib)
        key = candidates[0]
        identifier = source + '::' + case.get('name')
        status = 'skipped' if case.find('skipped') is not None else ('failed' if case.find('failure') is not None or case.find('error') is not None else 'passed')
        item = baseline_cases.setdefault(identifier, {'id': identifier, 'path': source, 'name': case.get('name'), 'declaration_name': key[1], 'outcomes': {}})
        item['outcomes']['php' + runtime] = {'status': status, 'assertions': int(case.get('assertions', '0'))}
for item in baseline_cases.values():
    key = (item['path'], renames.get((item['path'], item['declaration_name']), item['declaration_name']))
    current_tests[key]['baseline_runtime_case_ids'].append(item['id'])
for key, t in current_tests.items():
    if not t['added_in_round3']:
        assert t['baseline_runtime_case_ids'], ('No baseline cases', key)

current_cases = {}
final_xml_trees = {}
for runtime in ['84', '85']:
    xml_path = ROUND / ('final' + runtime + '.xml')
    tree = ET.parse(xml_path)
    final_xml_trees[runtime] = tree
    for case in tree.findall('.//testcase'):
        source = case.get('file', '').split('::', 1)[0]
        candidates = []
        for (path, name), t in current_tests.items():
            if path != source:
                continue
            for prefix in [name, 'it ' + name]:
                if case.get('name') == prefix or case.get('name', '').startswith(prefix + ' with data set '):
                    candidates.append((path, name))
                    break
        if not candidates:
            assert not any(path == source for path, name in current_tests), ('Unmapped current case', source, case.attrib)
            continue
        assert len(candidates) == 1, ('Ambiguous current case', case.attrib)
        key = candidates[0]
        identifier = source + '::' + case.get('name')
        status = 'skipped' if case.find('skipped') is not None else ('failed' if case.find('failure') is not None or case.find('error') is not None else 'passed')
        item = current_cases.setdefault(identifier, {'id': identifier, 'path': source, 'name': case.get('name'), 'declaration_name': key[1], 'dataset_id': case.get('name').split(' with data set ', 1)[1] if ' with data set ' in case.get('name') else None, 'outcomes': {}})
        item['outcomes']['php' + runtime] = {'status': status, 'assertions': int(case.get('assertions', '0'))}
for t in current_tests.values():
    t['current_runtime_case_ids'] = []
for item in current_cases.values():
    current_tests[(item['path'], item['declaration_name'])]['current_runtime_case_ids'].append(item['id'])
for key, t in current_tests.items():
    assert t['current_runtime_case_ids'], ('No final cases', key)
for item in current_cases.values():
    assert set(item['outcomes']) == {'php84', 'php85'}, ('Missing version case', item['id'])
    assert all(outcome['status'] != 'failed' for outcome in item['outcomes'].values())

proof_labels = [
 'magic-invoke', 'request-null-payload', 'request-duplicate-tail', 'request-source-order',
 'variadic-collection-keys', 'callback-position-minus', 'callback-position-plus', 'callback-position-missing',
 'callable-classification-boundary', 'callable-service-method', 'union-context-case-dedup', 'union-context-case-choice',
 'request-typed-union', 'attributed-positional-null', 'attributed-request-union', 'attributed-second-type-key', 'native-optional-variadic',
]
root_variant_path = ROUND / 'preserved-variants-proof/proof.json'
root_variant = json.loads(root_variant_path.read_text())
proofs = {}
for label in proof_labels:
    path = BASE / (label + '-proof.json')
    p = json.loads(path.read_text())
    assert len(p['runs']) == (4 if label.startswith('union-context-case-') else 8)
    for run in p['runs']:
        assert run['exit'] == run['expected_exit']
        assert sha(Path(run['log_path']).read_bytes()) == run['log_sha256']
        assert sha(Path(run['origins_path']).read_bytes()) == run['origins_sha256']
        origin = json.loads(Path(run['origins_path']).read_text())
        assert origin['pest_root'] == str(BASE / 'isolated')
    proofs[label] = {
        'label': label, 'mutant_id': p['case']['mutant_id'], 'source': p['case']['source'], 'test': p['case']['test'],
        'contract': p['case']['contract'], 'production_snapshot': BASELINE,
        'production_sha256': p['production_sha256'], 'mutant_sha256': p['mutant_sha256'],
        'old_test_sha256': p['old_test_sha256'], 'improved_test_sha256': p['improved_test_sha256'],
        'runtime_versions': sorted({r['runtime'] for r in p['runs']}),
        'four_phase_run_count': len(p['runs']), 'executed_by': REVIEWER,
        'discovered_by': p['case'].get('discovered_by', REVIEWER),
        'canonical_proof': ref(path), 'scope': p['scope'],
        'current_file_sha256': sha((REPO / p['case']['test']).read_bytes()),
        'current_source_sha256': sha((REPO / p['case']['source']).read_bytes()),
        'source_bytes_match_current': sha((REPO / p['case']['source']).read_bytes()) == p['production_sha256'],
        'file_bytes_match_improved_proof': sha((REPO / p['case']['test']).read_bytes()) == p['improved_test_sha256'],
        'snapshot_qualification': 'Exact per-phase source/test hashes and loaded origins are recorded. Later independent test strengthening in the same file is not relabeled as this earlier exact-byte execution; current test bodies are separately reviewed and root final suite gates apply to the final checkout.',
    }
    if 'old_test_origin' in p['case']:
        proofs[label]['old_test_origin'] = p['case']['old_test_origin']
    if label == 'variadic-collection-keys':
        records = [r for r in root_variant['records'] if r['mutant'] == 'de65523c18587937']
        assert len(records) == 8
        for run in records:
            assert run['exit'] == run['expected_exit']
            assert sha(Path(run['log']).read_bytes()) == run['log_sha256']
            assert sha(Path(run['origins']).read_bytes()) == run['origins_sha256']
            origin = json.loads(Path(run['origins']).read_text())
            assert origin['pest_root'] == run['cwd']
            loaded = [c for c in origin['classes'] if c['class'] == 'Componenta\\DI\\Internal\\Resolver\\Parameter\\VariadicArguments']
            assert len(loaded) == 1 and loaded[0]['sha256'] == run['source_sha256']
            assert loaded[0]['file'] == run['cwd'] + '/' + run['source']
        new_runs = [r for r in records if r['label'].endswith('-new-production')]
        assert all(r['test_sha256'] == sha((REPO / p['case']['test']).read_bytes()) for r in new_runs)
        proofs[label]['predecessor_proof'] = ref(path)
        proofs[label]['canonical_proof'] = {**ref(root_variant_path), 'record_selector': {'mutant': 'de65523c18587937'}}
        proofs[label]['executed_by'] = '/root'
        proofs[label]['test_strengthening_by'] = [REVIEWER, '/root']
        proofs[label]['improved_test_sha256'] = new_runs[0]['test_sha256']
        proofs[label]['file_bytes_match_improved_proof'] = True
        proofs[label]['snapshot_qualification'] = 'Root reran all four phases on both PHP versions after preserving both pure-variadic and fixed-prefix dataset variants. Only those eight root records are canonical for the current declaration; the earlier attributes proof is not double-counted.'

for e in survivor['entries']:
    e['baseline_test_anchors'] = e.get('baseline_test_anchors', e['test_anchors'])
    current_anchors = []
    for anchor in e['baseline_test_anchors']:
        if ':' not in anchor:
            current_anchors.append(anchor)
            continue
        anchor_path, anchor_line = anchor.rsplit(':', 1)
        if not anchor_line.isdigit():
            current_anchors.append(anchor)
            continue
        if anchor_path == 'tests/Contract/AttributeCallbackInvocationContractTest.php':
            match = next(t for t in ast[anchor_path]['tests'] if t['name'] == 'semantic callback first arguments reject incompatible types')
            current_anchors.append(anchor_path + ':' + str(match['line']))
            continue
        matches = [(path, name) for (path, name), t in baseline_tests.items() if path == anchor_path and t['line'] <= int(anchor_line) <= t['end_line']]
        if len(matches) == 1:
            path, name = matches[0]
            match = current_tests[(path, renames.get((path, name), name))]
            current_anchors.append(path + ':' + str(match['line']))
        else:
            current_anchors.append(anchor)
    e['test_anchors'] = current_anchors
    e['test_anchor_snapshot'] = FINAL_SNAPSHOT
    if e['id'] == 'de65523c18587937':
        e['executed_evidence'] = str(root_variant_path)
        e['executed_evidence_record_selector'] = {'mutant': 'de65523c18587937'}
        e['predecessor_evidence'] = str(BASE / 'variadic-collection-keys-proof.json')
        e['execution_reviewer'] = '/root'
        e['limitation'] = 'Final root proof preserves both pure variadic and fixed-prefix cases; predecessor attributes proof is retained but not counted twice.'
    # Map code anchors remain baseline locations, while tests follow the reviewed current declaration.
    linked = [p for p in proofs.values() if p['mutant_id'] == e['id']]
    if linked:
        e['current_test_file_sha256'] = linked[0]['current_file_sha256']
        e['code_anchor_snapshot'] = BASELINE
survivor_path.write_text(json.dumps(survivor, indent=2, ensure_ascii=False) + '\n')

delegated_path = 'tests/Contract/AttributeCallbackInvocationContractTest.php'
delegated_name = 'semantic callback first arguments reject incompatible types'
delegated_ast = next(t for t in ast[delegated_path]['tests'] if t['name'] == delegated_name)
delegated = {
    'path': delegated_path, 'whole_file_primary_reviewer': '/root/core_audit', 'declaration_patch_and_proof_reviewer': REVIEWER,
    'fresh_supporting_full_file_read': True, 'counted_in_owned_scope': False,
    'current_sha256': sha((REPO / delegated_path).read_bytes()),
    'declaration': {**delegated_ast, **manual(
        'An incompatible semantic callback first argument must expose the correct public parameter diagnostic payload.',
        'A narrow ResolutionException catch follows mandatory failure on unexpected success; message contains $semantic, parameterName semantic, parameterPosition0, parameterType int and exact resolvedParameterTypes [0=>string].',
        'Three production mutations remove or shift the diagnostic index while preserving the thrown exception class/message previously asserted.',
        'Static callback int $semantic receives string7; three separate index mutations run on both PHP versions.',
        'The test asserts exact diagnostic fields, not exception object identity. The full file and other declarations belong to core review.',
        ['callback-position-minus', 'callback-position-plus', 'callback-position-missing'])},
}
delegated['current_runtime_evidence'] = {}
for runtime, tree in final_xml_trees.items():
    matches = [c for c in tree.findall('.//testcase') if c.get('file', '').split('::', 1)[0] == delegated_path and c.get('name') == delegated_name]
    assert len(matches) == 1
    case = matches[0]
    delegated['current_runtime_evidence']['php' + runtime] = {'id': delegated_path + '::' + delegated_name, 'status': 'passed', 'assertions': int(case.get('assertions', '0'))}
    assert case.find('failure') is None and case.find('error') is None and case.find('skipped') is None

findings = []
for (path, name), t in sorted(current_tests.items()):
    labels = t.get('proof_labels', [])
    if not labels:
        continue
    findings.append({
        'kind': 'test_oracle_gap', 'production_bug_confirmed': False, 'path': path, 'declaration': name,
        'line': t['line'], 'contract': t['contract'], 'actual_improvement': t['actual_oracle'],
        'mutant_ids': [proofs[label]['mutant_id'] for label in labels], 'proof_labels': labels,
        'version_or_scope_limit': t['quality_finding_or_limitation'],
    })
findings.append({
    'kind': 'test_oracle_gap', 'production_bug_confirmed': False, 'path': delegated_path,
    'declaration': delegated_name, 'line': delegated_ast['line'], 'contract': delegated['declaration']['contract'],
    'actual_improvement': delegated['declaration']['actual_oracle'],
    'mutant_ids': [proofs[label]['mutant_id'] for label in delegated['declaration']['proof_labels']],
    'proof_labels': delegated['declaration']['proof_labels'], 'ownership': 'One declaration delegated by core; excluded from 57 owned test files and 218 owned declarations.',
})

review.update({
    'schema_version': 2, 'status': 'complete',
    'generated_utc': now, 'current_head_observed': head,
    'current_snapshot_qualification': 'Current code head ' + FINAL_SNAPSHOT + '. File hashes and final AST/JUnit are authoritative; unrelated peer/root changes are not attributed as fresh reads to this reviewer. A later harness-only follow-up does not relabel earlier exact-source mutant executions.',
    'scope_definition': {'production': '37 explicitly assigned src/**/*.php paths', 'tests': '57 explicitly assigned tests/**/*.php paths', 'fixtures_and_benchmarks': 'Not added to these counts. Root/peer fresh reviews own fixtures, benchmark files and unrelated support files.', 'delegated_callback': 'One separately attributed declaration; not double-counted as an owned file or declaration.', 'supplemental_portable_audit_cli': 'One new test declaration and one audit harness bug are recorded in availability-cli-review.json. Root owns the new declaration in the global unique scope; it is excluded from this primary37/57/218 scope.'},
    'hash_algorithm': 'SHA-256 over exact file bytes; declaration body hashes use the fresh PhpParser inventory source slice. No whitespace normalization. Aggregate owned-source fingerprint uses sorted path + NUL + hex SHA-256 + LF records encoded as UTF-8.',
    'inputs': [ref(checkpoint), ref(ast_path), ref(survivor_path), ref(ROUND / 'survivors-detail.json'), ref(BASE / 'proof-bootstrap.php'), ref(BASE / 'run-proof.py'), ref(BASE / 'isolation-manifest.json'), ref(Path(__file__))],
    'survivors': survivor['entries'], 'survivor_classification_counts': dict(collections.Counter(e['classification'] for e in survivor['entries'])),
    'findings': findings, 'executed_evidence': list(proofs.values()),
    'delegated_declarations': [delegated],
    'baseline_runtime_evidence': {'snapshot': BASELINE, 'sources': [ref(ROUND / 'baseline84.xml'), ref(ROUND / 'baseline85.xml')], 'cases': sorted(baseline_cases.values(), key=lambda c: c['id'])},
    'current_runtime_evidence': {'status': 'complete', 'snapshot': FINAL_SNAPSHOT, 'sources': [ref(ROUND / 'final84.xml'), ref(ROUND / 'final85.xml'), ref(ast_path)], 'case_ids_inferred_from_old_runs': False, 'cases': sorted(current_cases.values(), key=lambda c: c['id'])},
    'supporting_reviews_outside_primary_counts': [ref(BASE / 'windows-path-review.json'), ref(BASE / 'availability-cli-review.json')],
    'excluded_or_superseded_attempts': [
        {'path': str(BASE / 'magic-first-attempt'), 'php_test_runs': 3, 'reason': 'The initial driver expected exit1 while the genuine native invalid-call RED exited2; the incomplete sequence was excluded and eight canonical phases rerun. A separate Python unique-needle assertion failed before any PHP test or source mutation.'},
        {'path': str(BASE / 'request-union-before-uri-witness'), 'php_test_runs': 8, 'reason': 'Superseded by exact proof after capturing one expected URI identity before the call.'},
        {'path': str(BASE / 'request-source-order-before-fixture-types'), 'php_test_runs': 8, 'reason': 'Behavioral proof passed but the first generic class-string fixture form did not pass PHPStan; excluded from final snapshot evidence.'},
        {'path': str(BASE / 'request-source-order-before-concrete-fixtures'), 'php_test_runs': 8, 'reason': 'Behavioral proof passed but a closure PHPDoc annotation did not supply the intended static type; superseded by concrete fixture selection and final canonical proof.'},
        {'path': str(BASE / 'variadic-collection-keys-proof.json'), 'php_test_runs': 8, 'reason': 'Valid predecessor proof; final current test expands the dataset to retain the original pure-variadic signature, so root eight-run proof replaces it in canonical totals.'},
    ],
    'domain_conclusions': [
        {'area': 'Callable architecture and diagnostics', 'conclusion': 'Resolution, native invocation and cached signature classification are separate boundaries. Supported magic __invoke syntax and class/method classification collisions were weakly observed by previous tests; concrete public counterexamples now cover them. No production fix was required in the freshly read implementation.', 'anchors': ['src/CallableExecutor.php:94', 'src/CallableResolver.php:127', 'src/CallableResolver.php:148', 'tests/Contract/MagicCallableSyntaxContractTest.php', 'tests/Contract/CallableFailureDiagnosticsContractTest.php']},
        {'area': 'Request input and source ownership', 'conclusion': 'Canonical HTTP transport exclusion must skip only that candidate, not all remaining union arms. Explicit nullable parameter presence and source order are real application inputs. Source guards and request DTO provenance remain enforced; the test improvements expose potential regression paths without weakening authority rules.', 'anchors': ['src/Resolver/Parameter/ArrayTypedResolver.php', 'src/Resolver/Parameter/AttributeParameterResolver.php', 'src/Internal/Resolver/Parameter/Request/MappedRequestParameterSourceGuard.php', 'tests/V5/CurrentRequestContextTest.php', 'tests/V5/ValueResolutionParityTest.php', 'tests/V5/RequestMappingTest.php']},
        {'area': 'Native argument omission', 'conclusion': 'Omission is distinct from resolved null. A native optional argument followed by a variadic collection creates a valid positional rebinding hazard; the PDO witness checks the DI boundary before native invocation on both supported runtime versions.', 'anchors': ['src/Resolver/Parameter/ParametersResolver.php:279', 'tests/Contract/InternalCallableDefaultsContractTest.php']},
        {'area': 'Callback payload and variadic collections', 'conclusion': 'Public diagnostics must retain the position and resolved type of an incompatible semantic first argument. Variadic transformers can legitimately observe collection keys before spreading; result-only tests missed this distinction. Exact metadata and collection-input assertions now cover these contracts.', 'anchors': ['src/Internal/AttributeCallbackInvoker.php:49', 'src/Internal/Resolver/Parameter/VariadicArguments.php:28', 'tests/Contract/AttributeCallbackInvocationContractTest.php:' + str(delegated_ast['line']), 'tests/Contract/VariadicResolutionContractTest.php:131']},
        {'area': 'Cache lifetime and performance', 'conclusion': 'Fresh review verified explicit plan owner/revision refresh, avoidance of callable-owner retention and request-specific value recomputation. Several survivors change cache reuse or collection shape without a demonstrated current public result difference. They are not treated as proven performance-equivalent; no new timing/load test was run merely to increase mutation score.', 'anchors': ['src/CallableExecutor.php:118', 'src/Resolver/Parameter/ParametersResolver.php', 'src/Resolver/Target/ParameterTargetFactory.php', 'tests/Contract/CallableCacheParityContractTest.php', 'tests/Contract/CallableCaseCacheRetentionContractTest.php'], 'limitation': 'The 33 needs-decision survivor records include standalone helper API, intermediate metadata fencing and performance-policy questions; no blanket safety assertion is made.'},
        {'area': 'Version boundaries', 'conclusion': 'PHP84 contextual self aliases expose deterministic service-ID selection that PHP85 rejects at native compile time. The regression is deliberately version-local. Existing PHP85 attribute callable probes are kept distinct from release provenance and the trait-callable E1 acceptance gate.', 'anchors': ['src/Resolver/TypeHints.php:91', 'tests/Contract/UnionAutowiringContractTest.php', 'tests/Contract/Php85AttributeCallableContractTest.php'], 'limitation': 'Only PHP84 executions count as RED evidence for the two contextual union mutations; a PHP85 skip is not a kill.'},
        {'area': 'Security and architectural scope', 'conclusion': 'No new exploitable vulnerability or architecture-changing production defect was confirmed in these 37 assigned source files. Source-authority, typed key and mapped request checks were reviewed through their public boundaries. Open survivor classifications preserve uncertainty instead of inventing unsupported-input guarantees.', 'anchors': ['src/Internal/Resolver/Parameter/ParameterResolutionBoundary.php', 'src/Internal/Resolver/Parameter/Request/MappedRequestContext.php', 'src/Internal/Resolver/Parameter/Request/MappedRequestParameterSourceGuard.php', 'src/Resolver/Parameter/AttributeParameterResolver.php'], 'limitation': 'This domain conclusion does not replace the parallel fresh reviews of the other source files, nor does it assert an exhaustive security proof.'},
    ],
    'limitations': [
        'Every assigned file and every executable declaration was read afresh in this round; 218 current owned declarations were manually reviewed, but only 12 owned declarations plus one delegated declaration have newly executed meaningful mutant RED evidence.',
        'Current CI survivor data came from execution1e867ba/job132782343098 and exact diffs were checked against the unchanged source bytes at2eb. A survivor record alone is not a meaningful-gap proof; each of112 received an individual reachable-contract classification.',
        'Canonical four-phase evidence comprises17 distinct production faults and128 targeted file executions;120 were executed by attributes and8 final variadic executions by root. It is not a claim that every test was independently mutation-validated or that every mutant survived an entire final suite.',
        'No production source in this37-file assignment changed between the fresh read and the recorded current snapshot. Concurrent production fixes in other agents domains are not attributed to this review.',
        'toThrow(ExceptionClass, message) asserts compatible exception type and message substring. toThrow(Throwable) does not establish object identity. Exact identity is claimed only where toBe or equivalent explicit identity checks occur.',
        'The native PDO regression has an explicit environment skip; the two contextual union mutations execute only on PHP84. Local successful execution on a version is not a claim about other releases or extensions.',
        'Thirty-three needs-decision classifications remain reasoned rather than newly executed. They include valid auxiliary API shapes and uncertain metadata/performance boundaries and are not declared safe solely because an optimized private path is redundant in built-in wiring.',
        'Final runtime-case IDs and outcomes are joined from root final AST/JUnit at ' + FINAL_SNAPSHOT + '; baseline IDs/outcomes are derived from actual 2eb JUnit. Neither runtime layer is inferred from old manual reviews, and the 13 declarations with new RED evidence are counted separately from all 218 manually reviewed owned declarations.',
    ],
})

owned_source = [f for f in review['files'] if f['scope'] == 'production']
owned_tests = [f for f in review['files'] if f['scope'] == 'tests']
review['owned_source_fingerprint_sha256'] = sha(''.join(f['path'] + '\0' + f['current_sha256'] + '\n' for f in sorted(owned_source, key=lambda f: f['path'])).encode())
review['summary'] = {
    'assigned_source_files': 37, 'reviewed_source_files': len(owned_source),
    'assigned_test_files': 57, 'reviewed_test_files': len(owned_tests),
    'baseline_owned_declarations': len(baseline_tests), 'current_owned_declarations': len(current_tests),
    'fresh_current_manual_records': sum(t.get('fresh_manual_review', False) for t in current_tests.values()),
    'added_owned_declarations': sum(t['added_in_round3'] for t in current_tests.values()),
    'strengthened_owned_existing_declarations': sum(bool(t.get('proof_labels')) and not t['added_in_round3'] for t in current_tests.values()),
    'owned_declarations_with_executed_counterexamples': sum(bool(t.get('proof_labels')) for t in current_tests.values()),
    'additional_delegated_declarations_with_executed_counterexamples': 1,
    'assigned_survivors': 112, 'classified_survivors': len(survivor['entries']), 'pending_survivors': len(survivor['pending_ids']),
    'meaningful_assigned_survivors_with_execution': sum(e['classification'] == 'meaningful gap' for e in survivor['entries']),
    'additional_peer_source_mutants_executed': 3,
    'distinct_meaningful_mutant_ids_executed': len({p['mutant_id'] for p in proofs.values()}),
    'canonical_four_phase_executions': sum(p['four_phase_run_count'] for p in proofs.values()),
    'canonical_executions_by_attributes': sum(p['four_phase_run_count'] for p in proofs.values() if p['executed_by'] == REVIEWER),
    'canonical_executions_by_root': sum(p['four_phase_run_count'] for p in proofs.values() if p['executed_by'] == '/root'),
    'baseline_runtime_cases': len(baseline_cases), 'current_runtime_cases': len(current_cases),
    'current_runtime_php84_outcomes': dict(collections.Counter(c['outcomes']['php84']['status'] for c in current_cases.values())),
    'current_runtime_php85_outcomes': dict(collections.Counter(c['outcomes']['php85']['status'] for c in current_cases.values())),
    'baseline_runtime_mapping_gaps': 0, 'current_runtime_mapping_gaps': 0,
    'source_sha_mismatches': 0, 'test_ast_sha_mismatches': 0,
    'unreviewed_current_declarations': 0, 'missing_manual_oracles': 0,
    'production_bugs_confirmed_in_assigned_source': 0,
}
assert len(owned_source) == 37 and len(owned_tests) == 57
assert len(baseline_tests) == 216 and len(current_tests) == 218
assert len(survivor['entries']) == 112 and survivor['pending_ids'] == []
assert len(findings) == 13
assert review['summary']['canonical_four_phase_executions'] == 128
assert head == FINAL_SNAPSHOT, head
assert all(p['source_bytes_match_current'] for p in proofs.values())
(BASE / 'review.json').write_text(json.dumps(review, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(review['summary'], indent=2))
print('review_sha256=' + sha((BASE / 'review.json').read_bytes()))
