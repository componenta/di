from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys
BASE=Path(__file__).resolve().parent
REPO=BASE/'isolated'
RUNTIME=Path('/workspace/scratch/8f6c1df8ef3b/runtime')
sha=lambda data:hashlib.sha256(data).hexdigest()
label=sys.argv[1]
config=json.loads((BASE/(label+'-config.json')).read_text())
source=Path(config['source']);test=Path(config['test'])
production=(REPO/source).read_bytes();restored_test=(REPO/test).read_bytes();old=(BASE/config['old_test_file']).read_bytes() if 'old_test_file' in config else restored_test;new=(BASE/config['improved_file']).read_bytes()
needle=config['needle'].encode();replacement=config['replacement'].encode()
assert production.count(needle)==1
mutant=production.replace(needle,replacement)
classes=['Componenta\\DI\\CallableExecutor','Componenta\\DI\\CallableResolver','Componenta\\DI\\Resolver\\Parameter\\ParametersResolver','Componenta\\DI\\Resolver\\Target\\ParameterTarget']+config.get('extra_classes',[])
evidence={'baseline':'2eb36241787a971e1a8185149aaa08b90304d426','reviewer':'/root/attributes_audit','case':config,'production_sha256':sha(production),'mutant_sha256':sha(mutant),'old_test_sha256':sha(old),'improved_test_sha256':sha(new),'scope':'targeted entire test file; no claim of full current suite mutant survival','runs':[]}
for kind,before,after,path in [('mutant',production,mutant,source),('test',old,new,test)]:
 (BASE/(label+'-'+kind+'.patch')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+str(path),tofile='b/'+str(path))))
try:
 for runtime in config.get('runtimes',['php84','php85']):
  for phase,src,tests,expected in [('old-production',production,old,0),('old-mutant',mutant,old,0),('improved-mutant',mutant,new,config.get('red_exit',1)),('improved-production',production,new,0)]:
   (REPO/source).write_bytes(src);(REPO/test).write_bytes(tests)
   name=label+'-'+runtime+'-'+phase
   hashes={cls:sha((REPO/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()) for cls in classes}
   origin=BASE/(name+'-origins.json');log=BASE/(name+'.log')
   envvars={'R3_ATTRIBUTES_ROOT':str(REPO),'R3_ATTRIBUTES_PROVENANCE':str(origin),'R3_ATTRIBUTES_HASHES':json.dumps(hashes)}
   env=os.environ.copy();env.update(envvars)
   cmd=[str(RUNTIME/runtime/'php'),'-d','opcache.enable_cli=0','vendor/bin/pest',str(test),'--bootstrap='+str(BASE/'proof-bootstrap.php'),'--compact','--colors=never','--do-not-cache-result']
   result=subprocess.run(cmd,cwd=REPO,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
   log.write_text(result.stdout)
   item={'phase':phase,'runtime':runtime,'command':cmd,'cwd':str(REPO),'environment':envvars,'exit':result.returncode,'expected_exit':expected,'log_path':str(log),'log_sha256':sha(log.read_bytes()),'origins_path':str(origin),'test_sha256':sha(tests),'source_sha256':sha(src)}
   if origin.exists(): item['origins_sha256']=sha(origin.read_bytes())
   evidence['runs'].append(item)
   (BASE/(label+'-proof.json')).write_text(json.dumps(evidence,indent=2)+'\n')
   print(name+': '+str(result.returncode)+'\n'+result.stdout,flush=True)
   assert result.returncode==expected,name
   assert origin.exists(),name
   assert json.loads(origin.read_text())['pest_root']==str(REPO),name
finally:
 (REPO/source).write_bytes(production);(REPO/test).write_bytes(restored_test)
 (BASE/(label+'-proof.json')).write_text(json.dumps(evidence,indent=2)+'\n')
