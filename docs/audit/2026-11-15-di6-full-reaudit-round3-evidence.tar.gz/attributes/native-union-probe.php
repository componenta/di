<?php
declare(strict_types=1);
require '/workspace/scratch/8f6c1df8ef3b/di/tests/bootstrap.php';
class CaseUnionDomain {
 public function receive(self|caseuniondomain $value): self { return $value; }
}
$method=new ReflectionMethod(CaseUnionDomain::class,'receive');
$type=$method->getParameters()[0]->getType();
$first=new CaseUnionDomain();$second=new CaseUnionDomain();
$di=(new Componenta\DI\Tests\Support\ContainerBuilder())->addService(CaseUnionDomain::class,$first)->addService('caseuniondomain',$second)->build();
echo json_encode(['php'=>PHP_VERSION,'types'=>array_map(static fn($v)=>(string)$v,$type->getTypes()),'candidates'=>Componenta\DI\Resolver\TypeHints::simpleUnionClassNames($type,new ReflectionClass(CaseUnionDomain::class)),'selected_first'=>$di->call([$first,'receive'])===$first],JSON_THROW_ON_ERROR),"\n";
