from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
catalog=json.loads((BASE/'survivors.json').read_text())
entries={e['id']:e for e in catalog['entries']}
output=BASE/'survivor-review.json'
records={e['id']:e for e in json.loads(output.read_text()).get('entries',[])} if output.exists() else {}
def verdict(identifier, category, reason, reachability, anchors, evidence=None, limitation=None):
    assert identifier in entries,identifier
    assert category in ['meaningful gap','equivalent-under-contract','defensive-outside-supported-input','redundant path','needs decision']
    records[identifier]={**entries[identifier], 'reviewer':'/root/attributes_audit','fresh_diff_review':True,'classification':category,'reason':reason,'reachability':reachability,'code_anchor':entries[identifier]['path']+':'+str(entries[identifier]['line']),'test_anchors':anchors,'evidence_status':'executed_RED_with_controls' if evidence else 'reasoned_only_no_new_mutant_execution','executed_evidence':str(BASE/evidence) if evidence else None,'limitation':limitation}
def save():
    output.write_text(json.dumps({'baseline':catalog['baseline'],'fresh_ci_execution_commit':catalog['execution_commit'],'source_job':catalog['source_job'],'raw_log_sha256':catalog['raw_log_sha256'],'classification_scope':'Individual fresh CI survivors in assigned37 production PHP files; additional peers source mutants are in separate proof records. Classification does not assert blanket safety.','classified':len(records),'assigned':len(entries),'pending_ids':sorted(set(entries)-set(records)),'entries':[records[k] for k in entries if k in records]},indent=2,ensure_ascii=False)+'\n')
