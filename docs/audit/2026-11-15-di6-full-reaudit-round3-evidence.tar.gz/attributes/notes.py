import datetime
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/8f6c1df8ef3b/di')

def record(path, rows, note='Read every line afresh, including helpers, fixtures, dataset tails and cleanup paths.'):
    report = json.loads((BASE / 'review.json').read_text())
    file = next(f for f in report['files'] if f['path'] == path)
    ast = file.get('baseline_declarations', [])
    assert len(ast) == len(rows), (path, len(ast), len(rows))
    data = (REPO / path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == file['baseline_sha256']
    file['fresh_full_read'] = True
    file['review_notes'] = note
    file['reviewed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    file['tests'] = []
    for declaration, row in zip(ast, rows):
        contract, oracle, fault, edges, limitation = row
        file['tests'].append({**declaration, 'fresh_manual_review': True,
            'contract': contract, 'actual_oracle': oracle,
            'meaningful_fault_counterexample': fault, 'dataset_edges': edges,
            'quality_finding_or_limitation': limitation,
            'evidence_status': 'reasoned_counterexample_not_executed_RED'})
    (BASE / 'review.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')

def source(path, note):
    report = json.loads((BASE / 'review.json').read_text())
    file = next(f for f in report['files'] if f['path'] == path)
    assert file['scope'] == 'production'
    assert hashlib.sha256((REPO / path).read_bytes()).hexdigest() == file['baseline_sha256']
    file['review_notes'] = note
    file['reviewed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (BASE / 'review.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
