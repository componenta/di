from pathlib import Path
import hashlib, json, subprocess

base=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/8f6c1df8ef3b/di')
baseline='2eb36241787a971e1a8185149aaa08b90304d426'
names=['ExceptionInterface','InvalidConfigurationException','InvalidCallableException','MutationRetirementException','RequestDataConflictException','RequestParameterSourceConflictException']
original={name:(repo/'src/Exception'/f'{name}.php').read_text() for name in names}
for name,text in original.items():
    assert text==subprocess.check_output(['git','show',f'{baseline}:src/Exception/{name}.php'],cwd=repo,text=True)
cases=[
('a0d01feb64bfe5f5','InvalidCallableException','is_object($callable[0])','is_object($callable[1])'),
('82375b9bcdb2756a','RequestDataConflictException','(string) $key,','$key,'),
('b0f38dc73fb5ba15','RequestParameterSourceConflictException','$parameter === null','!($parameter === null)'),
('b3c5cbf535dc68ab','RequestParameterSourceConflictException','$parameter === null','$parameter !== null'),
('4a86692ce3c9b1f5','MutationRetirementException','$causes === [] || !array_is_list($causes)','$causes === [] && !array_is_list($causes)'),
('0f873c4be08e641b','MutationRetirementException','foreach ($causes as $cause)','foreach ([] as $cause)'),
('baa3f82ec086cc2b','MutationRetirementException','!$cause instanceof Throwable','!true'),
('1f1715a779ba54cf','MutationRetirementException','$id === null','!($id === null)'),
('e28f0a9fb13928c4','MutationRetirementException','$id === null','$id !== null'),
]
evidence={'baseline':baseline,'kind':'diagnostic observations, not Pest TDD proof','variants':[]}
for id,name,needle,replacement in [('original',None,None,None)]+cases:
    destination=base/'root-diagnostics'/id
    destination.mkdir(parents=True,exist_ok=True)
    for file,text in original.items():
        if file==name:
            assert text.count(needle)==1
            text=text.replace(needle,replacement)
        (destination/f'{file}.php').write_text(text)
    record={'id':id,'source_files_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in destination.glob('*.php')},'runs':[]}
    for version in ['84','85']:
        command=[f'/workspace/scratch/8f6c1df8ef3b/runtime/php{version}/php','-n',str(base/'root-diagnostic-observations.php'),str(destination)]
        run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
        assert run.returncode==0 and not run.stderr,(id,run.returncode,run.stderr,run.stdout)
        result=json.loads(run.stdout)
        file=destination/f'php{version}.json';file.write_bytes(run.stdout)
        record['runs'].append({'command':command,'exit':run.returncode,'log':str(file),'log_sha256':hashlib.sha256(run.stdout).hexdigest(),'php':result['php'],'observations':result['observations'],'origins':result['origins']})
    evidence['variants'].append(record)
(base/'root-diagnostic-observations.json').write_text(json.dumps(evidence,indent=2)+'\n')
for row in evidence['variants']:
    before=evidence['variants'][0]['runs'][0]['observations'];after=row['runs'][0]['observations']
    print(row['id'],[key for key in before if before[key]!=after[key]])
