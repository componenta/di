from pathlib import Path
import hashlib,json,os,subprocess
BASE=Path(__file__).resolve().parent; REPO=BASE/'isolated'; MAIN=Path('/workspace/scratch/8f6c1df8ef3b/di'); RUNTIME=Path('/workspace/scratch/8f6c1df8ef3b/runtime')
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
plan=Path('src/Attribute/Composition/AttributePlanBuilder.php');rule=Path('src/Attribute/Composition/Rule/ProxyCompositionRule.php')
original_sources={p:(REPO/p).read_text() for p in [plan,rule]}
improved={}; originals={}
p=Path('tests/V5/AttributeCompositionTest.php');old=(REPO/p).read_text();originals[p]=old
new=old.replace('use Componenta\\DI\\Attribute\\Composition\\Capability\\ValueProvider;','use Componenta\\DI\\Attribute\\Composition\\Capability\\ValueProvider;\nuse Componenta\\DI\\Attribute\\Composition\\Capability\\ValueTransformer;')
new+=r'''

#[Attribute(Attribute::TARGET_PARAMETER)]
final readonly class SourceScanMetadata {}

#[Attribute(Attribute::TARGET_PARAMETER)]
final readonly class SourceScanTransformer {}

#[Attribute(Attribute::TARGET_PARAMETER)]
final readonly class SourceScanFirst {}

#[Attribute(Attribute::TARGET_PARAMETER)]
final readonly class SourceScanSecond {}

test('parameter source conflicts remain visible after metadata and transformer usages', function (bool $transformer): void {
    $container = (new ContainerBuilder())
        ->addAttributeDefinition(new AttributeDefinition(SourceScanMetadata::class))
        ->addAttributeDefinition(new AttributeDefinition(SourceScanTransformer::class, new CustomValueHandler(), [ValueTransformer::class]))
        ->addAttributeDefinition(new AttributeDefinition(SourceScanFirst::class, new CustomValueHandler()))
        ->addAttributeDefinition(new AttributeDefinition(SourceScanSecond::class, new CustomValueHandler()))
        ->build();
    $callable = $transformer
        ? static fn(#[SourceScanTransformer, SourceScanFirst, SourceScanSecond] string $value): string => $value
        : static fn(#[SourceScanMetadata, SourceScanFirst, SourceScanSecond] string $value): string => $value;

    expect(fn() => $container->call($callable))
        ->toThrow(AttributeCompositionException::class, 'multiple parameter source handlers');
})->with(['metadata first' => false, 'transformer first' => true]);
'''
improved[p]=new
p=Path('tests/V5/AttributeTargetContractTest.php');old=(REPO/p).read_text();originals[p]=old
new=old.replace('use Componenta\\DI\\Attribute\\Init;','use Componenta\\DI\\Attribute\\Composition\\AttributeDefinition;\nuse Componenta\\DI\\Attribute\\Config as ConfigAttribute;\nuse Componenta\\DI\\Attribute\\Init;')
new+=r'''

#[Attribute(Attribute::TARGET_PROPERTY)]
final readonly class PromotedPropertyMetadata {}

#[Attribute(Attribute::TARGET_PARAMETER)]
final readonly class PromotedParameterMetadata {}

final class PromotedFollowingParameterAttribute
{
    public function __construct(
        #[PromotedPropertyMetadata, ConfigAttribute('value')]
        public string $value = 'constructor',
    ) {}
}

final class PromotedFollowingPropertyAttribute
{
    public function __construct(
        #[PromotedParameterMetadata, Init([self::class, 'initialize'])]
        public string $value = 'constructor',
    ) {}

    public static function initialize(): string
    {
        return 'property';
    }
}

test('promotion keeps valid attributes following a copy for the other target', function (bool $property): void {
    $container = ContainerBuilder::configure(new \Componenta\Config\Config(
        ['value' => 'parameter'],
        new \Componenta\Config\Environment([]),
    ))
        ->addAttributeDefinition(new AttributeDefinition(PromotedPropertyMetadata::class))
        ->addAttributeDefinition(new AttributeDefinition(PromotedParameterMetadata::class))
        ->build();
    $entry = $property
        ? $container->make(PromotedFollowingPropertyAttribute::class)
        : $container->make(PromotedFollowingParameterAttribute::class);

    expect($entry->value)->toBe($property ? 'property' : 'parameter');
})->with(['parameter target' => false, 'property target' => true]);
'''
improved[p]=new
p=Path('tests/V5/InvocationOnlyValueProviderTest.php');old=(REPO/p).read_text();originals[p]=old
new=old.replace('#[Attribute(Attribute::TARGET_PARAMETER)]','#[Attribute(Attribute::TARGET_ALL)]',1)
needle="test('custom invocation-only capabilities are rejected on constructor parameters', function (): void {"
assert new.count(needle)==1
new=new.replace(needle,r'''#[InvocationOnlyFixture]
final readonly class InvocationOnlyClassFixture {}

final class InvocationOnlyPropertyFixture
{
    #[InvocationOnlyFixture]
    public string $value = 'default';
}

final class InvocationOnlyMethodFixture
{
    #[InvocationOnlyFixture]
    public function marker(): void {}
}

test('custom invocation-only capabilities are rejected outside callable parameters', function (string $class, string $message): void {''')
oldend=r'''    expect(fn() => $container->make(InvocationOnlyConstructorFixture::class))
        ->toThrow(AttributeCompositionException::class, 'is invocation-only and cannot target constructor parameter');
});'''
newend=r'''    expect(fn() => $container->make($class))
        ->toThrow(AttributeCompositionException::class, $message);
})->with([
    'constructor parameter' => [InvocationOnlyConstructorFixture::class, 'is invocation-only and cannot target constructor parameter'],
    'class' => [InvocationOnlyClassFixture::class, 'is invocation-only and can target callable parameters only'],
    'property' => [InvocationOnlyPropertyFixture::class, 'is invocation-only and can target callable parameters only'],
    'method' => [InvocationOnlyMethodFixture::class, 'is invocation-only and can target callable parameters only'],
]);'''
assert new.count(oldend)==1;new=new.replace(oldend,newend);improved[p]=new.replace("test('custom invocation-only capabilities are rejected outside callable parameters', function (string $class, string $message): void {\n    $container", "test('custom invocation-only capabilities are rejected outside callable parameters', function (string $class, string $message): void {\n    if (!class_exists($class)) {\n        throw new \\LogicException('Expected an invocation-only target fixture.');\n    }\n    $container")
p=Path('tests/V5/ProxyCompositionRegressionTest.php');old=(REPO/p).read_text();originals[p]=old
needle="test('Proxy cannot compete with another value source on one injection point', function (): void {"
new=old.replace(needle,r'''final class ProxyConflictingPropertyTarget
{
    #[Proxy, ConfigAttribute('value')]
    public ProxyCompositionValue $value;
}

test('Proxy cannot compete with another value source on one injection point', function (bool $property): void {''')
oldend=r'''    expect(fn() => $container->make(ProxyConflictingSourceTarget::class))
        ->toThrow(AttributeCompositionException::class, 'multiple parameter source handlers');
});'''
newend=r'''    expect(fn() => $container->make($property ? ProxyConflictingPropertyTarget::class : ProxyConflictingSourceTarget::class))
        ->toThrow(AttributeCompositionException::class, $property
            ? 'cannot be combined with value provider'
            : 'multiple parameter source handlers');
})->with(['parameter' => false, 'property' => true]);'''
assert new.count(oldend)==1;new=new.replace(oldend,newend);improved[p]=new
for p,data in improved.items():(BASE/(p.stem+'-improved.php')).write_text(data)
cases=[]
def case(label,id,source,needle,replacement,test):
 assert original_sources[source].count(needle)==1,(label,'needle');cases.append(dict(label=label,id=id,source=source,needle=needle,replacement=replacement,test=Path(test)))
case('source-after-metadata','74e2ebe61e898ddf',plan,"if (!$handler instanceof ParameterAttributeHandlerInterface) {\n                continue;", "if (!$handler instanceof ParameterAttributeHandlerInterface) {\n                break;",'tests/V5/AttributeCompositionTest.php')
case('source-after-transformer','b1b58e292ed47c31',plan,"if ($usage->hasCapability(ValueTransformer::class)) {\n                continue;", "if ($usage->hasCapability(ValueTransformer::class)) {\n                break;",'tests/V5/AttributeCompositionTest.php')
case('promoted-following','87c5cf293f31fd04',plan,"if (self::isPromotedDuplicateTarget($target)\n                    && ($this->attributeTargetFlags($attributeClass) & (Attribute::TARGET_PARAMETER | Attribute::TARGET_PROPERTY)) !== 0\n                ) {\n                    continue;", "if (self::isPromotedDuplicateTarget($target)\n                    && ($this->attributeTargetFlags($attributeClass) & (Attribute::TARGET_PARAMETER | Attribute::TARGET_PROPERTY)) !== 0\n                ) {\n                    break;",'tests/V5/AttributeTargetContractTest.php')
case('invocation-only-object','0860dab69116b715',plan,'if (!$target instanceof ReflectionParameter) {\n            throw new AttributeCompositionException(sprintf(\n                \'#[%s] is invocation-only','if (!true) {\n            throw new AttributeCompositionException(sprintf(\n                \'#[%s] is invocation-only','tests/V5/InvocationOnlyValueProviderTest.php')
condition='$attribute->target instanceof ReflectionParameter\n            || $attribute->target instanceof ReflectionProperty'
case('proxy-rule-negated','ae25b50329c6c7be',rule,condition,'!('+condition+')','tests/V5/ProxyCompositionRegressionTest.php')
case('proxy-rule-intersection','0d13064718a9fa23',rule,condition,'$attribute->target instanceof ReflectionParameter\n            && $attribute->target instanceof ReflectionProperty','tests/V5/ProxyCompositionRegressionTest.php')
case('proxy-rule-no-property','b8d233fd3bb0146a',rule,'$attribute->target instanceof ReflectionProperty','false','tests/V5/ProxyCompositionRegressionTest.php')
case('proxy-rule-no-providers','25ac7dafdf61be97',rule,'$set->all(ValueProvider::class)','[]','tests/V5/ProxyCompositionRegressionTest.php')
classes=['Componenta\\DI\\Attribute\\Composition\\AttributePlanBuilder','Componenta\\DI\\Attribute\\Composition\\Rule\\ProxyCompositionRule','Componenta\\DI\\Resolver\\Attribute\\AttributeProcessor']
evidence={'baseline':'2eb36241787a971e1a8185149aaa08b90304d426','cases':[],'tests':{str(p):{'old_sha256':sha(originals[p]),'new_sha256':sha(new),'improved_copy':str(BASE/(p.stem+'-improved.php'))} for p,new in improved.items()}}
try:
 for c in cases:
  if os.environ.get('R3_CASE') and c['label'] != os.environ['R3_CASE']: continue
  prod=original_sources[c['source']];mutant=prod.replace(c['needle'],c['replacement']);record={k:str(v) if isinstance(v,Path) else v for k,v in c.items()};record.update(production_sha256=sha(prod),mutant_sha256=sha(mutant),runs=[]);evidence['cases'].append(record)
  for runtime in ['php84','php85']:
   for phase,source,test,expected in [('old-production',prod,originals[c['test']],0),('old-mutant',mutant,originals[c['test']],0),('improved-mutant',mutant,improved[c['test']],1),('improved-production',prod,improved[c['test']],0)]:
    for p,data in original_sources.items():(REPO/p).write_text(data)
    (REPO/c['source']).write_text(source);(REPO/c['test']).write_text(test)
    label=c['label']+'-'+runtime+'-'+phase;origins=BASE/(label+'-origins.json')
    hashes={cls:hashlib.sha256((REPO/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()).hexdigest() for cls in classes}
    envvalues={'R3_CORE_ROOT':str(REPO),'R3_CORE_PROVENANCE':str(origins),'R3_CORE_HASHES':json.dumps(hashes)};env=os.environ.copy();env.update(envvalues)
    cmd=[str(RUNTIME/runtime/'php'),'-d','opcache.enable_cli=0','vendor/bin/pest',str(c['test']),'--bootstrap='+str(BASE/'proof-bootstrap.php'),'--compact','--colors=never','--do-not-cache-result']
    r=subprocess.run(cmd,cwd=REPO,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60);log=BASE/(label+'.log');log.write_text(r.stdout)
    record['runs'].append(dict(phase=phase,php=runtime,command=cmd,cwd=str(REPO),environment=envvalues,exit=r.returncode,expected_exit=expected,stdout=str(log),origins=str(origins)))
    (BASE/('semantic-proofs-'+os.environ['R3_CASE']+'.json' if os.environ.get('R3_CASE') else 'semantic-proofs.json')).write_text(json.dumps(evidence,indent=2)+'\n')
    print(label+': '+str(r.returncode)+'\n'+r.stdout,flush=True)
    assert r.returncode==expected,(label,r.returncode)
    assert origins.exists(),label
  (REPO/c['test']).write_text(originals[c['test']])
finally:
 for p,data in original_sources.items():(REPO/p).write_text(data)
 for p,data in originals.items():(REPO/p).write_text(data)
 (BASE/('semantic-proofs-'+os.environ['R3_CASE']+'.json' if os.environ.get('R3_CASE') else 'semantic-proofs.json')).write_text(json.dumps(evidence,indent=2)+'\n')
