from pathlib import Path
import hashlib,json,os,subprocess

BASE=Path(__file__).resolve().parent
REPO=BASE/'isolated'
MAIN=Path('/workspace/scratch/8f6c1df8ef3b/di')
RUNTIME=Path('/workspace/scratch/8f6c1df8ef3b/runtime')
BASELINE='2eb36241787a971e1a8185149aaa08b90304d426'
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
plan=Path('src/Attribute/Composition/AttributePlanBuilder.php')
guard=Path('src/Internal/CompletedAttributeGuard.php')
original_sources={p:(REPO/p).read_text() for p in [plan,guard]}
originals={};improved={}

p=Path('tests/Contract/AttributeExecutionOrderContractTest.php')
old=(REPO/p).read_text();originals[p]=old
needle="""it('does not impose execution phases on metadata without a runtime handler', function (): void {
    $log = new AttributeOrderLog();
    $container = (new ContainerBuilder())
        ->addService(AttributeOrderLog::class, $log)
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedFirst::class,
            phase: AttributePhase::BeforeInstantiation,
        ))
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedSecond::class,
            new OrderedHandler($log, 'second'),
            before: [OrderedFirst::class],
            phase: AttributePhase::AfterInstantiation,
        ))
        ->build();

    $container->make(PhasedOrderTarget::class);

    expect($log->events)->toBe(['constructor', 'second']);
});"""
replacement="""it('does not impose execution phases on metadata without a runtime handler', function (bool $metadataPrecedes): void {
    $log = new AttributeOrderLog();
    $container = (new ContainerBuilder())
        ->addService(AttributeOrderLog::class, $log)
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedFirst::class,
            before: $metadataPrecedes ? [OrderedSecond::class] : [],
            phase: $metadataPrecedes ? AttributePhase::AfterInstantiation : AttributePhase::BeforeInstantiation,
        ))
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedSecond::class,
            new OrderedHandler($log, 'second'),
            before: $metadataPrecedes ? [] : [OrderedFirst::class],
            phase: $metadataPrecedes ? AttributePhase::BeforeInstantiation : AttributePhase::AfterInstantiation,
        ))
        ->build();

    $container->make(PhasedOrderTarget::class);

    expect($log->events)->toBe($metadataPrecedes ? ['second', 'constructor'] : ['constructor', 'second']);
})->with(['metadata follows the handler' => false, 'metadata precedes the handler' => true]);"""
assert old.count(needle)==1
new=old.replace(needle,replacement)+r'''

it('examines every phase-order branch after handler boundaries and repeated metadata nodes', function (bool $convergingMetadata): void {
    $log = new AttributeOrderLog();
    $container = (new ContainerBuilder())
        ->addService(AttributeOrderLog::class, $log)
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedFirst::class,
            new OrderedHandler($log, 'first'),
            phase: AttributePhase::BeforeInstantiation,
        ))
        ->addAttributeDefinition(new AttributeDefinition(
            PhaseOrderMarker::class,
            $convergingMetadata ? null : new OrderedHandler($log, 'bridge'),
            phase: AttributePhase::Both,
        ))
        ->addAttributeDefinition(new AttributeDefinition(
            PhaseOrderSecondMarker::class,
            before: $convergingMetadata ? [PhaseOrderMarker::class] : [],
        ))
        ->addAttributeDefinition(new AttributeDefinition(
            OrderedSecond::class,
            new OrderedHandler($log, 'second'),
            before: $convergingMetadata
                ? [OrderedFirst::class, PhaseOrderMarker::class, PhaseOrderSecondMarker::class]
                : [OrderedFirst::class, PhaseOrderMarker::class],
            phase: AttributePhase::AfterInstantiation,
        ))
        ->build();

    expect(fn() => $container->make(LongerMetadataPhaseOrderTarget::class))
        ->toThrow(AttributeCompositionException::class, 'execution phases')
        ->and($log->events)->toBe([]);
})->with(['handler boundary' => false, 'converging metadata' => true]);
'''
improved[p]=new

p=Path('tests/Contract/BootstrapLateAttributesContractTest.php')
old=(REPO/p).read_text();originals[p]=old
new=old.replace('use Componenta\\DI\\Exception\\InvalidConfigurationException;', 'use Componenta\\DI\\Exception\\InvalidConfigurationException;\nuse Componenta\\DI\\Resolver\\Attribute\\AttributeHandlerInterface;\nuse Componenta\\DI\\Resolver\\Entry\\ObjectCreationContext;')
new=new.replace('use LogicException;', 'use LogicException;\nuse Reflector;')
new+=r'''

interface BootstrapGenericDefinition {}

#[Attribute(Attribute::TARGET_CLASS)]
final readonly class BootstrapSpecificDefinition implements BootstrapGenericDefinition {}

#[BootstrapSpecificDefinition]
final class BootstrapDefinitionIdentityTarget {}

final class BootstrapDefinitionIdentityLog
{
    /** @var list<string> */
    public array $events = [];
}

final readonly class BootstrapDefinitionIdentityHandler implements AttributeHandlerInterface
{
    public function __construct(private BootstrapDefinitionIdentityLog $log, private string $label) {}

    public function handle(object $attribute, Reflector $target, ObjectCreationContext $context): void
    {
        $this->log->events[] = $this->label;
    }
}

it('rejects bootstrap dependencies created through a definition replaced by a later more specific registration', function (): void {
    $log = new BootstrapDefinitionIdentityLog();

    expect(fn() => container([
        ConfigKey::ATTRIBUTE_DEFINITIONS => [
            new AttributeDefinition(
                BootstrapGenericDefinition::class,
                new BootstrapDefinitionIdentityHandler($log, 'generic'),
            ),
            static function (Container $container) use ($log): AttributeDefinition {
                $dependency = $container->get(BootstrapDefinitionIdentityTarget::class);
                if (!$dependency instanceof BootstrapDefinitionIdentityTarget) {
                    throw new LogicException('Expected the bootstrap definition identity fixture.');
                }

                return new AttributeDefinition(
                    BootstrapSpecificDefinition::class,
                    new BootstrapDefinitionIdentityHandler($log, 'specific'),
                );
            },
        ],
    ]))->toThrow(InvalidConfigurationException::class, 'DI bootstrap used ' . BootstrapDefinitionIdentityTarget::class)
        ->and($log->events)->toBe(['generic']);
});
'''
improved[p]=new

for p,data in {**original_sources,**originals}.items():
    expected=subprocess.run(['git','show',BASELINE+':'+str(p)],cwd=MAIN,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=True).stdout
    assert expected==data,(p,'snapshot mismatch')
for p,data in improved.items():(BASE/(p.stem+'-closing-improved.php')).write_text(data)

cases=[]
def case(label,id,source,needle,replacement,test):
    assert original_sources[source].count(needle)==1,(label,'needle')
    cases.append(dict(label=label,id=id,source=source,needle=needle,replacement=replacement,test=Path(test)))
case('phase-metadata-root','8cf8c5ce93196367',plan,'if (!$before->definition->handler instanceof AttributeHandlerInterface\n                ||','if (!true\n                ||','tests/Contract/AttributeExecutionOrderContractTest.php')
case('phase-visited-branch','fafde72e22578511',plan,'if (isset($visited[$index])) {\n                    continue;','if (isset($visited[$index])) {\n                    break;','tests/Contract/AttributeExecutionOrderContractTest.php')
case('phase-handler-branch','5c261ea54702220d',plan,'// Both has separate invocations in each phase; only metadata is transparent here.\n                    continue;','// Both has separate invocations in each phase; only metadata is transparent here.\n                    break;','tests/Contract/AttributeExecutionOrderContractTest.php')
case('bootstrap-definition-identity','74afcb61d3acb937',guard,'                $usage->definition,\n','', 'tests/Contract/BootstrapLateAttributesContractTest.php')
classes=['Componenta\\DI\\Attribute\\Composition\\AttributePlanBuilder','Componenta\\DI\\Internal\\CompletedAttributeGuard','Componenta\\DI\\Internal\\ObjectAttributeSequence','Componenta\\DI\\Internal\\BootstrapResolutionGuard','Componenta\\DI\\Object\\ObjectPipeline']
evidence={'baseline':BASELINE,'cases':[],'tests':{str(p):{'old_sha256':sha(originals[p]),'new_sha256':sha(new),'improved_copy':str(BASE/(p.stem+'-closing-improved.php'))} for p,new in improved.items()},'limits':['Target-file four-phase proofs; no claim that every test declaration executed an independent RED.','Mutants change only isolated production source; main production is not mutated.']}
try:
    for c in cases:
        if os.environ.get('R3_CASE') and c['label']!=os.environ['R3_CASE']:continue
        prod=original_sources[c['source']];mutant=prod.replace(c['needle'],c['replacement'])
        record={k:str(v) if isinstance(v,Path) else v for k,v in c.items()};record.update(production_sha256=sha(prod),mutant_sha256=sha(mutant),runs=[]);evidence['cases'].append(record)
        for runtime in ['php84','php85']:
            for phase,source,test,expected in [('old-production',prod,originals[c['test']],0),('old-mutant',mutant,originals[c['test']],0),('improved-mutant',mutant,improved[c['test']],2 if c['label']=='phase-metadata-root' else 1),('improved-production',prod,improved[c['test']],0)]:
                for p,data in original_sources.items():(REPO/p).write_text(data)
                (REPO/c['source']).write_text(source);(REPO/c['test']).write_text(test)
                label='closing-'+c['label']+'-'+runtime+'-'+phase;origins=BASE/(label+'-origins.json')
                hashes={cls:hashlib.sha256((REPO/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()).hexdigest() for cls in classes}
                envvalues={'R3_CORE_ROOT':str(REPO),'R3_CORE_PROVENANCE':str(origins),'R3_CORE_HASHES':json.dumps(hashes)};env=os.environ.copy();env.update(envvalues)
                cmd=[str(RUNTIME/runtime/'php'),'-d','opcache.enable_cli=0','vendor/bin/pest',str(c['test']),'--bootstrap='+str(BASE/'proof-bootstrap.php'),'--compact','--colors=never','--do-not-cache-result']
                r=subprocess.run(cmd,cwd=REPO,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60);log=BASE/(label+'.log');log.write_text(r.stdout)
                record['runs'].append(dict(phase=phase,php=runtime,command=cmd,cwd=str(REPO),environment=envvalues,exit=r.returncode,expected_exit=expected,stdout=str(log),origins=str(origins)))
                (BASE/'closing-proofs.json').write_text(json.dumps(evidence,indent=2)+'\n')
                print(label+': '+str(r.returncode)+'\n'+r.stdout,flush=True)
                assert r.returncode==expected,(label,r.returncode)
                assert origins.exists(),label
        (REPO/c['test']).write_text(originals[c['test']])
finally:
    for p,data in original_sources.items():(REPO/p).write_text(data)
    for p,data in originals.items():(REPO/p).write_text(data)
    (BASE/'closing-proofs.json').write_text(json.dumps(evidence,indent=2)+'\n')
