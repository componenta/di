<?php

declare(strict_types=1);

$root = getenv('R3_CORE_ROOT');
$destination = getenv('R3_CORE_PROVENANCE');
$expected = json_decode((string) getenv('R3_CORE_HASHES'), true, flags: JSON_THROW_ON_ERROR);
if (!is_string($root) || !is_string($destination) || !is_array($expected)) {
    throw new RuntimeException('Missing source provenance inputs.');
}
require $root . '/tests/bootstrap.php';
$origins = [];
foreach ($expected as $class => $hash) {
    $reflection = new ReflectionClass($class);
    $file = $reflection->getFileName();
    $relative = 'src/' . str_replace('\\', '/', substr($class, strlen('Componenta\\DI\\'))) . '.php';
    if ($file === false || realpath($file) !== $root . '/' . $relative || hash_file('sha256', $file) !== $hash) {
        throw new RuntimeException('Unexpected loaded class or hash: ' . $class);
    }
    $origins[] = ['class' => $class, 'file' => $file, 'sha256' => $hash];
}
$functions = [];
foreach (get_defined_functions()['user'] as $function) {
    if (!str_starts_with($function, 'componenta\\di\\internal\\')) {
        continue;
    }
    $reflection = new ReflectionFunction($function);
    $file = $reflection->getFileName();
    if ($file === false || realpath($file) !== $root . '/src/Internal/functions.php') {
        throw new RuntimeException('Unexpected eager function origin: ' . $function);
    }
    $functions[] = ['name' => $function, 'file' => $file, 'sha256' => hash_file('sha256', $file)];
}
if (count($functions) !== 6) {
    throw new RuntimeException('Expected six DI eager helper functions.');
}
$classmap = [];
$missingClassmap = [];
foreach ($loader->getClassMap() as $class => $file) {
    if (str_starts_with($class, 'Componenta\\DI\\') && !str_starts_with($class, 'Componenta\\DI\\Tests\\')) {
        if (!is_file($file)) {
            $missingClassmap[$class] = $file;
            continue;
        }
        if (!str_starts_with(realpath($file) ?: '', $root . '/src/')) {
            throw new RuntimeException('Foreign DI classmap entry: ' . $class);
        }
        $classmap[$class] = $file;
    }
}
file_put_contents($destination, json_encode([
    'php' => PHP_VERSION,
    'binary' => PHP_BINARY,
    'classes' => $origins,
    'eager_functions' => $functions,
    'verified_existing_classmap_count' => count($classmap),
    'missing_unloaded_classmap_entries' => $missingClassmap,
    'composer_loader' => (new ReflectionClass($loader))->getFileName(),
    'pest_root' => \Pest\TestSuite::getInstance()->rootPath,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
