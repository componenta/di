# DI v6 round-three audit: unresolved helper API boundaries

Baseline: `2eb36241787a971e1a8185149aaa08b90304d426`.
Final code reviewed: `141feff3d4747a70a2d4ac4c3841de53eb55fa73`.

These are compatibility decisions, not proposed emergency runtime refactors. The audit found no need to replace the object pipeline, composition registry, completed-phase proofs or property staging architecture. It did identify three exposed helper surfaces whose intended standalone guarantees cannot be inferred solely from their visibility or from their absence in current production call sites. Eleven surviving mutations are attached to these decisions in `review.json`.

No API was removed, made private, renamed or deprecated during this audit. The only production change in this domain is a PHPDoc generic-input correction in `ObjectPipeline`; its runtime token stream is unchanged on PHP 8.4 and 8.5.

## 1. `InstanceCreator` standalone convenience and prepared methods

### What exists and what is used

`src/Resolver/Entry/InstanceCreator.php` is a public final class without an `@internal` class annotation. Its `create()` and `initialize()` methods prepare constructor targets and delegate to `createPrepared()` and `initializePrepared()`. The prepared methods expose an optional nullable `beforeConstructor` callback.

A fresh search across `src`, `tests` and the PHP/Markdown files in `docs` found no call to the two convenience wrappers. `ContainerFactory` constructs one `InstanceCreator` and passes it into `ObjectPipeline`; it does not register `InstanceCreator` as a separate core service. The pipeline calls `createPrepared()` from its handlerless and eager paths and `initializePrepared()` from its lazy path. All three call sites supply a non-null completed-phase guard callback. Proxy construction delegates through the same eager path.

This is evidence about this repository, not proof that downstream consumers never instantiate the class directly.

### Why the distinction matters

Five mutations break the unused wrappers: two reverse constructor-target selection in `create()`, two do so in `initialize()`, and one removes initialization entirely. Three more remove nullsafe calls to the optional prepared-method callback. A ninth removes the constructorless early return, causing empty parameter resolution and a second guard/callback invocation before one allocation through `newInstanceArgs([])`.

These are plainly observable differences for a direct caller of those public methods. They do not establish that the container's active eager/lazy/proxy paths have the same gaps. Creating tests only against those branches would silently decide that standalone helper construction is a supported API; treating the methods as private merely because current callers do not use them would silently decide the opposite.

### Available decisions

**Support the standalone surface.** Document direct construction, accepted parameter source semantics, exception normalization, and whether the optional callback must run exactly once immediately before allocation/invocation. Add small public-method tests for constructorless and argument-bearing creation, initialization of an allocated object, omitted callback and supplied callback, and error causes. Keep the convenience wrappers delegating to the existing prepared implementation. The gain is a clear, usable lower-level construction API. The cost is a continuing compatibility and validation obligation for an additional entry point.

**Treat it as an implementation surface with a transition.** First inventory downstream use, including Composer consumers and documented examples. Add a consistent `@internal`/documentation boundary only after deciding what compatibility policy applies; if direct use has been published or is relied on, deprecate rather than immediately remove methods or change their visibility. Keep `ObjectPipeline` and `ContainerFactory` as the supported construction entry points. The gain is a smaller supported surface and fewer overlapping contracts. The risk is breaking consumers that inferred support from public visibility, so no removal is justified by the current repository-only search.

Either choice preserves one object-construction implementation. There is no evidence here that a new abstraction, another cache or a second creator implementation would improve correctness.

Relevant tests: `tests/Contract/ObjectPipelineLifecycleContractTest.php`, `tests/V5/PreparedObjectPipelineTest.php`, `tests/Contract/SkippedConstructorContractTest.php`, and the deferred lifecycle/retention contracts. They establish pipeline behavior and do not establish every direct `InstanceCreator` method contract.

## 2. `AttributeProcessor::prepare()` failure timing

### Current boundary

The public `prepare(ReflectionClass $class)` method currently calls the private `executionPlan()` builder, which discovers and validates composition. Normal `ObjectPipeline` preparation calls its own metadata method and obtains the processor inventory through `hasHandlers()`, not through this wrapper. Direct processor tests call `prepare()` and check metadata/lifetime behavior, but they do not require a particular invalid-composition failure to occur at that call.

Removing the wrapper's only call loses eager warming and eager validation. It does not remove validation from subsequent `hasHandlers()` or processing. That makes the mutation an API timing question rather than a demonstrated failure of normal object execution.

### Decision and tradeoff

If `prepare()` is a validation API, document that invalid native targets, repeatability and composition must be rejected before runtime handlers or constructors execute. Then add a negative public `prepare()` case with a specific invalid composition and a positive no-runtime-construction control. The gain is a useful deterministic validation seam.

If it is only an optional performance warmup, document that callers must not rely on it as the sole correctness gate. A test should then establish that normal execution remains correct with or without warming, without pinning private cache hits or validation callback counts. The gain is freedom to change warming strategy without a false compatibility promise.

This decision must remain distinct from `ObjectPipeline::prepare()`, whose constructor-attribute validation is already asserted in `ObjectPipelineLifecycleContractTest.php`.

## 3. Protected `ExtractsRequestData::extractSharedData()`

### Current callers

All seven built-in legacy mapper attributes use `extractSharedSources()` and merge those named sources with their primary source. The protected `extractSharedData()` helper is defined in the trait but has no source/test caller. The fresh search found only its declaration.

The surviving mutation returns an empty array from this unused helper. Built-in mapper behavior therefore cannot kill it. An external mapper subclass that intentionally calls the protected method would observe a real loss of selected request attributes/files.

### Decision and tradeoff

If protected mapper helpers are a supported subclassing API, retain the method, document source conflict/selection behavior, and test it through a representative public subclass `extract()` method. That would prove an actual extension use case and preserve its compatibility.

If the trait is implementation-only, document that boundary and check consumers before deprecating or removing the dead helper. Its removal would reduce unused surface, but it is not a performance improvement in built-in paths because those paths never call it.

Do not test the protected method through reflection solely to increase mutation score; that would leave the extension contract unresolved.

## Evidence and limits

- `review.json` gives every affected survivor ID, path, reachability condition and corresponding code/test anchors.
- `object-pipeline-generic-proof/proof.json` records the separate confirmed static-input defect: an actual `ReflectionClass<Concrete>` argument was rejected by invariant PHPDoc, then accepted after method-generic annotations. It is a static analyzer RED/GREEN, not a runtime test RED.
- The active object pipeline retains revision-aware metadata, fresh runtime attributes, phase completion checks and attempt-local staged property writes. The executed phase-graph and bootstrap-definition proofs are in `closing-proofs.json`; they strengthen tests of the current architecture.
- No application workload benchmark was run for these API decisions. Potential reduction in supported surface or maintenance burden is a qualitative benefit, not a measured throughput or memory claim.
- No claim is made that trusted PHP extension handlers, attribute constructors or autoloaders are sandboxed, or that arbitrary application side effects can be rolled back.
