from pathlib import Path
import hashlib,json,os,subprocess
BASE=Path(__file__).resolve().parent
REPO=BASE/'isolated'
MAIN=Path('/workspace/scratch/8f6c1df8ef3b/di')
RUNTIME=Path('/workspace/scratch/8f6c1df8ef3b/runtime')
BASELINE='2eb36241787a971e1a8185149aaa08b90304d426'
sha=lambda data:hashlib.sha256(data.encode()).hexdigest()
registry=Path('src/Attribute/Composition/AttributeDefinitionRegistry.php')
attribute_set=Path('src/Attribute/Composition/AttributeSet.php')
original_sources={p:(REPO/p).read_text() for p in [registry,attribute_set]}
cases=[]

test=Path('tests/Contract/AttributePlanSingleSelectionContractTest.php');old=(REPO/test).read_text()
new=old.replace('use Componenta\\DI\\Attribute\\Composition\\AttributePlanBuilder;','use Componenta\\DI\\Attribute\\Composition\\AttributePlanBuilder;\nuse Componenta\\DI\\Attribute\\Composition\\AttributeSet;')
needle="        ->toThrow(AttributeCompositionException::class, 'Capability \"' . ValueTransformer::class . '\" is not singular in this plan.');"
assert new.count(needle)==1
new=new.replace(needle,needle[:-1]+"\n        ->and(fn() => (new AttributeSet($plan->usages))->one(ValueTransformer::class))\n        ->toThrow(AttributeCompositionException::class, 'Selector \"' . ValueTransformer::class . '\" is not singular in this attribute set.');")
cases.append({'label':'set-singularity','id':'a547d82118dc5e1e','source':attribute_set,'needle':'if (count($matches) > 1) {','replacement':'if (count($matches) > 2) {','test':test,'old':old,'new':new})

test=Path('tests/V5/CompositionArchitectureTest.php');old=(REPO/test).read_text()
new=old.replace('use Componenta\\DI\\Attribute\\Composition\\AttributeUsage;','use Componenta\\DI\\Attribute\\Composition\\AttributeUsage;\nuse Componenta\\DI\\Attribute\\Composition\\CapabilityPolicy;')
needle="    expect($plans->build($parameter)->usages)->toHaveCount(1);\n\n    $registry->register(new AttributeDefinition(RuleB::class));"
assert new.count(needle)==1
new=new.replace(needle,"    expect($plans->build($parameter)->usages)->toHaveCount(1);\n\n    $registry->defineCapability(new CapabilityPolicy(AuditSelectorCapability::class, 2));\n    $registry->register(new AttributeDefinition(RuleB::class, capabilities: [AuditSelectorCapability::class]));")
cases.append({'label':'registry-revision','id':'032b473414545e17','source':registry,'needle':"            $this->policies[$capability] = $policy;\n            ++$this->generation;",'replacement':"            $this->policies[$capability] = $policy;\n            --$this->generation;",'test':test,'old':old,'new':new})

test=Path('tests/Contract/AttributeCapabilityPolicyContractTest.php');old=(REPO/test).read_text()
needle="    expect($policies)->toBe(["
assert old.count(needle)==1
new=old.replace(needle,"    expect(array_is_list($registry->policies()))->toBeTrue()\n        ->and($policies)->toBe([")
cases.append({'label':'policies-list','id':'6692af229221aa47','source':registry,'needle':'return array_values($this->policies);','replacement':'return $this->policies;','test':test,'old':old,'new':new})

classes=['Componenta\\DI\\Attribute\\Composition\\AttributeSet','Componenta\\DI\\Attribute\\Composition\\AttributeDefinitionRegistry','Componenta\\DI\\Attribute\\Composition\\AttributeDefinition','Componenta\\DI\\Attribute\\Composition\\AttributePlanBuilder']
evidence={'baseline':BASELINE,'reviewer':'/root/core_audit','cases':[]}
try:
 for case in cases:
  production=original_sources[case['source']];assert production.count(case['needle'])==1
  mutant=production.replace(case['needle'],case['replacement'])
  record={k:str(v) if isinstance(v,Path) else v for k,v in case.items() if k not in ['old','new']}
  record.update({'production_sha256':sha(production),'mutant_sha256':sha(mutant),'old_test_sha256':sha(case['old']),'new_test_sha256':sha(case['new']),'runs':[]});evidence['cases'].append(record)
  (BASE/(case['label']+'-improved.php')).write_text(case['new'])
  for runtime in ['php84','php85']:
   for phase,source,test,expected in [('old-production',production,case['old'],0),('old-mutant',mutant,case['old'],0),('improved-mutant',mutant,case['new'],1),('improved-production',production,case['new'],0)]:
    for p,data in original_sources.items():(REPO/p).write_text(data)
    (REPO/case['source']).write_text(source);(REPO/case['test']).write_text(test)
    label=case['label']+'-'+runtime+'-'+phase
    hashes={cls:hashlib.sha256((REPO/('src/'+cls[len('Componenta\\DI\\'):].replace('\\','/')+'.php')).read_bytes()).hexdigest() for cls in classes}
    origins=BASE/(label+'-origins.json')
    overrides={'R3_CORE_ROOT':str(REPO),'R3_CORE_PROVENANCE':str(origins),'R3_CORE_HASHES':json.dumps(hashes)}
    env=os.environ.copy();env.update(overrides)
    command=[str(RUNTIME/runtime/'php'),'-d','opcache.enable_cli=0','vendor/bin/pest',str(case['test']),'--bootstrap='+str(BASE/'proof-bootstrap.php'),'--compact','--colors=never','--do-not-cache-result']
    run=subprocess.run(command,cwd=REPO,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
    log=BASE/(label+'.log');log.write_text(run.stdout)
    record['runs'].append({'phase':phase,'php':runtime,'command':command,'cwd':str(REPO),'environment':overrides,'exit':run.returncode,'expected_exit':expected,'stdout':str(log),'origins':str(origins)})
    (BASE/'composition-proofs.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(label+': '+str(run.returncode)+'\n'+run.stdout,flush=True)
    assert run.returncode==expected,label
    assert origins.exists(),label
  (REPO/case['test']).write_text(case['old'])
finally:
 for p,data in original_sources.items():(REPO/p).write_text(data)
 for case in cases:(REPO/case['test']).write_text(case['old'])
 (BASE/'composition-proofs.json').write_text(json.dumps(evidence,indent=2)+'\n')
