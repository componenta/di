from pathlib import Path
import collections,copy,hashlib,json,xml.etree.ElementTree as ET
from notes import read,write

BASE=Path(__file__).resolve().parent
ROUND=BASE.parent
REPO=Path('/workspace/scratch/8f6c1df8ef3b/di')
FINAL='141feff3d4747a70a2d4ac4c3841de53eb55fa73'
ast=json.loads((ROUND/'final-test-declarations.json').read_text())
runtime={v:list(ET.parse(ROUND/f'final{v}.xml').getroot().iter('testcase')) for v in ['84','85']}
r=read()
r['final_code_head']=FINAL
r['status']='complete: fresh file/declaration review and individual survivor classification; explicit execution limits retained'
r['test_record_schema']='files[].tests preserves the 299 baseline declaration reviews; files[].current_tests reviews all 303 declarations at final_code_head and maps each runtime dataset case.'

owned_proofs={}
for filename,commit in [
    ('composition-proofs.json','660fe404a2335f73e975fd6000719398680a6d4d'),
    ('semantic-proofs.json','5bc9756a3848dd8be62859635fce6157fe7dc7b9'),
    ('closing-proofs.json','141feff3d4747a70a2d4ac4c3841de53eb55fa73'),
]:
    evidence=json.loads((BASE/filename).read_text())
    for c in evidence['cases']:
        assert len(c['runs'])==8
        assert all(x['exit']==x['expected_exit'] for x in c['runs'])
        for run in c['runs']:
            assert Path(run['stdout']).is_file() and Path(run['origins']).is_file()
        owned_proofs[c['id']]={'path':str(BASE/filename),'case':c['label'],'id':c['id'],'commit':commit,'owner':'/root/core_audit','canonical_runs':8,'test_path':c['test']}

external_proofs={
 '2929d8501519f199':{'path':str(ROUND/'attributes/request-null-payload-proof.json'),'owner':'/root/attributes_audit'},
 '0d1d22d0fdcba5f6':{'path':str(ROUND/'attributes/request-duplicate-tail-proof.json'),'owner':'/root/attributes_audit'},
 'beeee44b92664646':{'path':str(ROUND/'attributes/request-source-order-proof.json'),'owner':'/root/attributes_audit','commit':'95bfa68907dde860ee307ebf74de491f10c0c419','old_test_scope':'Current strengthened RequestMappingTest at b90b58f; production remains exact baseline 2eb, as recorded in delegated proof.'},
 'd65a6e1e64a158b3':{'path':str(ROUND/'attribute-parameter-identity/proof.json'),'owner':'/root','commit':'f48d7fc5c9787a399df7671ce77e8d336c00575d'},
 '4ee7976ff00e11a1':{'path':str(ROUND/'attribute-parameter-identity/proof.json'),'owner':'/root','commit':'f48d7fc5c9787a399df7671ce77e8d336c00575d'},
 '1d6cfa6279fb43b9':{'path':str(ROUND/'inherited-property-identity-v2/proof.json'),'owner':'/root','commit':'7d771478d170ac594a8c9872c119f00bb7f32059','superseded_proof':'v1 is not canonical; v2 fixes fixture typing and re-executes all phases.'},
 '6d14b6b0ee74a098':{'path':str(ROUND/'inherited-property-identity-v2/proof.json'),'owner':'/root','commit':'7d771478d170ac594a8c9872c119f00bb7f32059'},
 'e71f5d6b520c53c2':{'path':str(ROUND/'inherited-property-identity-v2/proof.json'),'owner':'/root','commit':'7d771478d170ac594a8c9872c119f00bb7f32059'},
 '165273e57fdff011':{'path':str(ROUND/'parameters/eligibility-proof/trait-consumer-final/results.json'),'old_green_path':str(ROUND/'parameters/eligibility-proof/results.json'),'owner':'/root/parameters_audit','scope_note':'Final negative cases use a concrete trait consumer positive control; old-mutant GREEN is retained in the preceding baseline proof.'},
}
for evidence in external_proofs.values():assert Path(evidence['path']).is_file()
all_proofs={**owned_proofs,**external_proofs}
confirmed_explanations={
 '8cf8c5ce93196367':'Executed exact-mutant proof: the old target file passes 20 tests/53 assertions; the strengthened metadata-only declaration adds a legitimate metadata-before-before-handler case. Mutant raises a false AttributeCompositionException (one failed/22 passed), while restored production passes 23/60 on PHP 8.4 and 8.5. No production fix was needed.',
 'fafde72e22578511':'Executed exact-mutant proof: an after root reaches the same transparent metadata node through two branches while a separate before-handler branch remains pending. Breaking at the repeated node misses the phase contradiction. Old 20/53 stays green; the new converging-metadata case fails; restored production is 23/60 on both runtimes.',
 '5c261ea54702220d':'Executed exact-mutant proof: an after root has both a Both-handler branch and a separate before-handler branch. Breaking at the first executable handler abandons the latter conflict. The new public composition case requires rejection before any handler/constructor event. Old 20/53 is green; improved mutant fails; restored production is 23/60 on both runtimes.',
 '74afcb61d3acb937':'Executed exact-mutant proof: bootstrap resolves an object through a generic definition, then registers a more-specific definition for the same already-known native attribute. The mutant accepts stale semantics because class/order match; the improved test requires the bootstrap error and log [generic]. Old 7/14 is green; improved mutant fails; restored production is 8/17 on both runtimes.',
 'beeee44b92664646':'Executed delegated proof: with declared source order Query then Attributes, selected request attributes and FirstWins, the mutant pre-inserts attributes and returns attribute instead of query. The already strengthened old RequestMapping file remains green at 19/40; improved mutant fails; restored final fixture passes 20/41 on PHP 8.4/8.5. Exact old-test version and final SHA are recorded in the delegated proof.',
}
for s in r['survivors']:
    assert s['verdict'] is not None and s['review_status']=='classified'
    if s['id'] in confirmed_explanations:s['explanation']=confirmed_explanations[s['id']]
    s['source_anchor_revision']=r['baseline']
    if s['id'] in all_proofs:
        s['evidence_status']='executed old-production GREEN / old-mutant GREEN / improved-mutant RED / restored-production GREEN on PHP 8.4 and PHP 8.5'
        s['executed_proof']=all_proofs[s['id']]
        s['disposition']='confirmed oracle gap closed by a public behavior test; production runtime behavior unchanged'
    elif s['verdict']=='meaningful gap':
        s['evidence_status']='reasoned supported-behavior or diagnostic counterexample only; no improved-test RED executed for this ID'
        s['disposition']='retained test question, not a confirmed defect in unmutated production and not a completed TDD proof'
    elif s['verdict']=='needs architecture decision':
        s['evidence_status']='fresh caller/contract review; standalone API support decision remains open'
        s['architecture_note']=str(BASE/'architecture-boundaries.md')
        s['disposition']='no API change; evaluate documented support and downstream compatibility before implementation'
    else:
        s['evidence_status']='reasoned contract/reachability classification, not an executed equivalent-mutant proof'
        s['disposition']='no test added solely to raise mutation score'

decl_proofs={
 ('tests/Contract/AttributePlanSingleSelectionContractTest.php','singular plan selection refuses two usages even when the capability permits repetition'):['a547d82118dc5e1e'],
 ('tests/V5/CompositionArchitectureTest.php','plan memoization invalidates when registry semantics change'):['032b473414545e17'],
 ('tests/Contract/AttributeCapabilityPolicyContractTest.php','core capability policies expose singular providers and repeatable transformations and lifecycle hooks'):['6692af229221aa47'],
 ('tests/V5/AttributeCompositionTest.php','parameter source conflicts remain visible after metadata and transformer usages'):['74e2ebe61e898ddf','b1b58e292ed47c31'],
 ('tests/V5/AttributeTargetContractTest.php','promotion keeps valid attributes following a copy for the other target'):['87c5cf293f31fd04'],
 ('tests/V5/InvocationOnlyValueProviderTest.php','custom invocation-only capabilities are rejected outside callable parameters'):['0860dab69116b715'],
 ('tests/V5/ProxyCompositionRegressionTest.php','Proxy cannot compete with another value source on one injection point'):['ae25b50329c6c7be','0d13064718a9fa23','b8d233fd3bb0146a','25ac7dafdf61be97'],
 ('tests/Contract/AttributeExecutionOrderContractTest.php','does not impose execution phases on metadata without a runtime handler'):['8cf8c5ce93196367'],
 ('tests/Contract/AttributeExecutionOrderContractTest.php','examines every phase-order branch after handler boundaries and repeated metadata nodes'):['fafde72e22578511','5c261ea54702220d'],
 ('tests/Contract/BootstrapLateAttributesContractTest.php','rejects bootstrap dependencies created through a definition replaced by a later more specific registration'):['74afcb61d3acb937'],
}
current_notes={
 ('tests/Contract/AttributePlanSingleSelectionContractTest.php','singular plan selection refuses two usages even when the capability permits repetition'):(
 'Both AttributePlan::one and rule-facing AttributeSet::one reject exactly two matching usages even when the capability itself permits repeats.',
 'Raising the singularity threshold from >1 to >2 in AttributeSet would return one of an ambiguous pair.',
 'The same existing declaration now checks both public selection surfaces and kills the exact threshold mutant.'),
 ('tests/V5/CompositionArchitectureTest.php','plan memoization invalidates when registry semantics change'):(
 'After warming a plan, defining a new capability and registering a second attribute yields a plan with both actual usages.',
 'Decrementing capability generation creates an ABA revision equal to the old cached generation after registration, returning a stale one-usage plan.',
 'Tests observed plan semantics, not a private revision number; exact old/new/restored proof is retained.'),
 ('tests/Contract/AttributeCapabilityPolicyContractTest.php','core capability policies expose singular providers and repeatable transformations and lifecycle hooks'):(
 'The public policies result is a list, and its entries expose the independently expected core cardinalities.',
 'Removing array_values preserves values but violates the declared list return shape, which the old map-building assertion masked.',
 'The list shape is explicitly promised by the public method PHPDoc. No downstream foreach failure is claimed.'),
 ('tests/V5/AttributeCompositionTest.php','parameter source conflicts remain visible after metadata and transformer usages'):(
 'Container.call rejects two distinct parameter source handlers with the multiple-source composition diagnostic even when metadata or a transformer precedes them.',
 'Changing either skip to break stops scanning before the conflicting source pair.',
 'Metadata-first and transformer-first variants each kill their corresponding exact mutant; both retain production rejection before value resolution.'),
 ('tests/V5/AttributeTargetContractTest.php','promotion keeps valid attributes following a copy for the other target'):(
 'The promoted parameter path returns configured parameter, and the promoted property path returns initialized property, instead of the constructor seed.',
 'Breaking after skipping the opposite-target promoted attribute drops a later valid Config/Init usage.',
 'Two directions have independent literal outputs and exact mutant proof; the fixtures preserve native target declarations.'),
 ('tests/V5/InvocationOnlyValueProviderTest.php','custom invocation-only capabilities are rejected outside callable parameters'):(
 'Constructor, class, property and method targets each raise the appropriate invocation-only composition diagnostic.',
 'Removing the non-parameter target guard lets three object-target cases fail later with the wrong operation/error.',
 'The original constructor negative is preserved and three object targets added. A real class_exists fixture guard satisfies static class-string typing without suppressions.'),
 ('tests/V5/ProxyCompositionRegressionTest.php','Proxy cannot compete with another value source on one injection point'):(
 'Parameter and property Proxy+Config compositions both reject, with separate source-handler versus Proxy-rule diagnostics.',
 'Disabling the property gate/loop accepts a competing property source even though the parameter case still fails earlier.',
 'Four exact ProxyCompositionRule mutants are killed by the new property variant; the earlier parameter case remains a positive rejection control.'),
 ('tests/Contract/AttributeExecutionOrderContractTest.php','does not impose execution phases on metadata without a runtime handler'):(
 'Metadata labelled Before may follow an after handler, and metadata labelled After may precede a before handler; exact logs are constructor/second and second/constructor respectively.',
 'Treating metadata as an executable after-phase root falsely rejects the second legal configuration.',
 'One existing declaration strengthened with the converse metadata ordering case; the original behavior remains covered.'),
 ('tests/Contract/AttributeExecutionOrderContractTest.php','examines every phase-order branch after handler boundaries and repeated metadata nodes'):(
 'Both graph variants throw an execution-phase composition error before any handler or constructor log event.',
 'Break at a Both-handler boundary or at a revisited transparent metadata node abandons a different pending before-handler conflict.',
 'Two public composition datasets independently distinguish the two exact branch-truncation mutants; no traversal order or private graph structure is asserted.'),
 ('tests/Contract/BootstrapLateAttributesContractTest.php','rejects bootstrap dependencies created through a definition replaced by a later more specific registration'):(
 'Bootstrap rejects the affected target after the generic handler ran exactly once; the log is [generic] and the later specific handler is not replayed.',
 'Dropping selected definition identity from completed semantics treats the earlier generic behavior as equal to the new specific definition.',
 'Uses public extension registration and real container get during bootstrap. Both native attribute class and declaration order stay unchanged, isolating semantic definition identity.'),
 ('tests/Contract/AttributeCallbackInvocationContractTest.php','semantic callback first arguments reject incompatible types'):(
 'A narrow ResolutionException catch checks the semantic name, position 0, type int, message containing $semantic, and resolvedParameterTypes exactly [0 => string]; absence of an exception fails.',
 'Shifting or removing the resolved semantic argument from diagnostics can preserve the broad exception while losing its public position/type payload.',
 'Delegated attributes_audit proof kills three exact source mutants. The mandatory failure is only the success-path guard of the negative assertion, not an artificial RED.'),
}
callback_proofs=[{'path':str(ROUND/('attributes/callback-position-'+suffix+'-proof.json')),'owner':'/root/attributes_audit','id':id,'commit':'b88c079a1a62312a5f4f7bb2f335385627998a81'} for suffix,id in [('minus','82012d3cdf628c1b'),('plus','97b58f08a201452d'),('missing','546ca70a56274c89')]]
renames={'custom invocation-only capabilities are rejected outside callable parameters':'custom invocation-only capabilities are rejected on constructor parameters'}
for f in r['files']:
    source=(REPO/f['path']).read_bytes()
    f['baseline_sha256']=f['sha256']
    f['current_sha256']=hashlib.sha256(source).hexdigest()
    f['current_lines']=source.count(b'\n')+(not source.endswith(b'\n'))
    f['current_head']=FINAL
    f['fresh_full_read']=True
    f['baseline_full_read_attestation']='Read afresh in this round, including helpers and dataset declarations; no earlier-round read attestation reused.'
    if f['scope']=='production':
        if f['path']=='src/Object/ObjectPipeline.php':
            f['current_followup_review']='Reviewed the five method-generic PHPDoc changes. Runtime-token hashes match baseline on both PHP versions; static exact RED/GREEN evidence is attached.'
            f['current_change_evidence']=str(BASE/'object-pipeline-generic-proof/proof.json')
        else:assert f['current_sha256']==f['baseline_sha256'],f['path']
        continue
    assert ast[f['path']]['sha256']==f['current_sha256'],f['path']
    old_by_name={x['name']:x for x in f['tests']}
    current=[]
    for declaration in ast[f['path']]['tests']:
        key=(f['path'],declaration['name'])
        old=old_by_name.get(renames.get(declaration['name'],declaration['name']))
        if old:
            t=copy.deepcopy(old)
            t['baseline_line']=old['line'];t['baseline_name']=old['name']
        else:
            assert key in current_notes,key
            t={'baseline_line':None,'baseline_name':None,'contract':declaration['name'],'evidence_status':'new public behavior declaration with executed mutant proof','executed_evidence':[]}
        t.update(line=declaration['line'],end_line=declaration['end_line'],name=declaration['name'],kind=declaration['kind'],current_body_sha256=declaration['body_sha256'])
        if key in current_notes:
            t['actual_oracle'],t['meaningful_fault'],t['variants_and_quality']=current_notes[key]
            t['contract']=declaration['name']
        t['quality_finding']=t['variants_and_quality']
        if key in decl_proofs:
            t['executed_evidence']=[owned_proofs[id] for id in decl_proofs[key]]
            t['evidence_status']='executed meaningful isolated production mutation: old tests GREEN, current test RED, restored production GREEN, PHP 8.4 and PHP 8.5'
            if old:
                old['current_strengthening_proof']=t['executed_evidence']
                old['baseline_oracle_status']='passed the corresponding meaningful mutant; current declaration was strengthened'
        if key==('tests/Contract/AttributeCallbackInvocationContractTest.php','semantic callback first arguments reject incompatible types'):
            t['executed_evidence']=callback_proofs
            t['evidence_status']='delegated executed meaningful mutation proof on PHP 8.4 and PHP 8.5; exact final patch reviewed here'
            t['proof_owner']='/root/attributes_audit'
        description=('it ' if declaration['kind']=='it' else '')+declaration['name']
        t['current_runtime_cases']={}
        for version,cases in runtime.items():
            matches=[c for c in cases if c.attrib['file'].split('::')[0]==f['path'] and (c.attrib['name']==description or c.attrib['name'].startswith(description+' with data set '))]
            assert matches,(f['path'],declaration['name'],version)
            t['current_runtime_cases']['PHP'+version]=[{'name':c.attrib['name'],'status':'skipped' if c.find('skipped') is not None else 'passed','assertions':int(c.attrib['assertions'])} for c in matches]
        current.append(t)
    f['current_tests']=current
    f['current_followup_review']='Unchanged baseline bytes retain the fresh full-file review; any changed declarations/helpers were reviewed through the exact own or delegated patch and current AST/hash comparison.'

r['findings']=[
 {'id':'R3-CORE-01','survivors':['a547d82118dc5e1e'],'kind':'confirmed weak oracle; runtime production correct','summary':'Rule-facing singular selection now rejects exactly two ambiguous usages.','proof':str(BASE/'composition-proofs.json'),'commit':'660fe404a2335f73e975fd6000719398680a6d4d'},
 {'id':'R3-CORE-02','survivors':['032b473414545e17'],'kind':'confirmed weak oracle; runtime production correct','summary':'Registry revision ABA is exposed by actual fresh plan usages after capability then attribute registration.','proof':str(BASE/'composition-proofs.json'),'commit':'660fe404a2335f73e975fd6000719398680a6d4d'},
 {'id':'R3-CORE-03','survivors':['6692af229221aa47'],'kind':'confirmed public return-shape test gap; production correct','summary':'The declared public capability-policy list shape is independently checked.','proof':str(BASE/'composition-proofs.json'),'commit':'660fe404a2335f73e975fd6000719398680a6d4d'},
 {'id':'R3-CORE-04','survivors':['74e2ebe61e898ddf','b1b58e292ed47c31'],'kind':'confirmed source-handler conflict oracle gap','summary':'Metadata and transformer usages must not truncate later source-conflict validation.','proof':str(BASE/'semantic-proofs.json'),'commit':'5bc9756a3848dd8be62859635fce6157fe7dc7b9'},
 {'id':'R3-CORE-05','survivors':['87c5cf293f31fd04'],'kind':'confirmed promoted-target tail oracle gap','summary':'Skipping a promoted attribute copy must preserve later valid parameter/property metadata.','proof':str(BASE/'semantic-proofs.json'),'commit':'5bc9756a3848dd8be62859635fce6157fe7dc7b9'},
 {'id':'R3-CORE-06','survivors':['0860dab69116b715'],'kind':'confirmed invocation-only object-target oracle gap','summary':'Class/property/method targets receive semantic rejection before parameter-only operations.','proof':str(BASE/'semantic-proofs.json'),'commit':'5bc9756a3848dd8be62859635fce6157fe7dc7b9'},
 {'id':'R3-CORE-07','survivors':['ae25b50329c6c7be','0d13064718a9fa23','b8d233fd3bb0146a','25ac7dafdf61be97'],'kind':'confirmed property Proxy conflict oracle gap','summary':'The property rule has an independent failure oracle, beyond earlier parameter-handler rejection.','proof':str(BASE/'semantic-proofs.json'),'commit':'5bc9756a3848dd8be62859635fce6157fe7dc7b9'},
 {'id':'R3-CORE-08','survivors':['8cf8c5ce93196367','fafde72e22578511','5c261ea54702220d'],'kind':'confirmed phase-graph oracle gaps','summary':'Metadata has no physical phase, and phase validation must inspect other pending branches after a handler boundary or a visited metadata node.','proof':str(BASE/'closing-proofs.json'),'commit':'141feff3d4747a70a2d4ac4c3841de53eb55fa73'},
 {'id':'R3-CORE-09','survivors':['74afcb61d3acb937'],'kind':'confirmed bootstrap definition-identity oracle gap','summary':'The same native attribute class/order can select a different semantic definition during bootstrap.','proof':str(BASE/'closing-proofs.json'),'commit':'141feff3d4747a70a2d4ac4c3841de53eb55fa73'},
 {'id':'R3-CORE-10','survivors':[],'kind':'confirmed static PHPDoc generic-input defect','summary':'Concrete ReflectionClass<T> arguments were rejected by invariant ReflectionClass<object> annotations; generic method inputs now describe the already-supported runtime API.','proof':str(BASE/'object-pipeline-generic-proof/proof.json'),'commit':'3ca6ca3ac987ebc71ddedcfdc7fa6f6696941f85','runtime_tokens_changed':False},
]
r['cross_scope_completed_findings']=[{'survivor':id,**proof} for id,proof in external_proofs.items()]
r['delegated_owned_test_proofs']=callback_proofs
r['executed_checks']=[
 {'kind':'own exact isolated production mutants','evidence':str(BASE/'composition-proofs.json'),'canonical_runs':24,'excluded_bootstrap_attempt':str(BASE/'excluded-bootstrap-attempt.json')},
 {'kind':'own exact isolated production mutants','evidence':str(BASE/'semantic-proofs.json'),'canonical_runs':64,'note':'Final invocation-only fixture reproof is merged; superseded test bytes are identified in the evidence.'},
 {'kind':'own exact isolated production mutants','evidence':str(BASE/'closing-proofs.json'),'canonical_runs':32,'incomplete_runner_attempt':str(BASE/'closing-initial-exit-code-attempt.json'),'note':'The initial valid exception RED stopped on a controller expectation of exit 1 instead of 2. The complete rerun is canonical; the partial attempt is not counted.'},
 {'kind':'main targeted checks','evidence':str(BASE/'composition-main-checks.json'),'PHP84':'19 passed / 57 assertions','PHP85':'19 passed / 57 assertions'},
 {'kind':'main targeted checks','evidence':str(BASE/'semantic-main-checks.json'),'PHP84':'20 passed / 36 assertions','PHP85':'20 passed / 36 assertions','note':'The final invocation-only typing refinement also has a complete exact-byte reproof in semantic-proofs.json.'},
 {'kind':'main targeted checks','evidence':str(BASE/'closing-main-checks.json'),'PHP84':'31 passed / 77 assertions','PHP85':'31 passed / 77 assertions','PHPStan':'targeted maximum-level analysis clean','CS':'0 of 2 changed','note':'An initial multi-path CS invocation omitted --config and is recorded as a command-configuration error; the explicit-config rerun passed.'},
 {'kind':'PHPDoc-only static RED/GREEN','evidence':str(BASE/'object-pipeline-generic-proof/proof.json'),'PHP84':'argument.type RED then clean GREEN','PHP85':'clean GREEN','runtime_token_count':1784,'runtime_token_equality':'true within both runtimes'},
 {'kind':'root final whole-suite runtime mapping','code_head':FINAL,'PHP84_junit':str(ROUND/'final84.xml'),'PHP85_junit':str(ROUND/'final85.xml'),'scope_note':'Only matching assigned files/cases are attached to current_tests; root owns the whole-suite gate execution.'},
]
r['architecture_notes']=str(BASE/'architecture-boundaries.md')
r['limits']=[
 'Fresh full read covers exactly 86 assigned production files and 91 assigned test files. Six root-owned exception test files are excluded as stated in the assignment. New root-owned test files are not added to these file counts.',
 'All 299 baseline declarations and all 303 current declarations have individual oracle/fault/variant reviews. This is not a claim that each declaration executed a separate TDD RED.',
 'Fifteen exact own-source mutants have 120 canonical local four-phase runs. Nine additional own-source mutant IDs refer to independently executed root/sibling proofs. Counts are per unique ID; cross-scope evidence must not be double-counted in the team aggregate.',
 'Sixty-seven meaningful-gap classifications remain reasoned candidate witnesses, with no improved-test RED executed for those IDs. They are explicitly separated in unexecuted-meaningful-candidates.json and are not reported as defects in unmutated production.',
 'Equivalent/redundant classifications state their actual supported inputs and call paths. They do not assert identical timing, reflection allocation counts, arbitrary custom-rule callback counts, or behavior for forged native reflection objects.',
 'Eleven survivor records depend on standalone public/protected helper API decisions. No API visibility, deprecation or runtime architecture was changed; downstream consumer use remains to be checked before such a change.',
 'The sole production edit in this domain corrects generic PHPDoc input typing. Its actual executable token stream is unchanged on PHP 8.4 and PHP 8.5. It has a static analyzer RED/GREEN, not a runtime failure claim.',
 'The semantic callback diagnostics patch was delegated to attributes_audit; its final declaration was read here and its three external source-mutant proofs are referenced without taking source ownership.',
 'MapRequest source precedence uses exact baseline production but a later old-test snapshot that already includes two request test improvements. That distinction is retained in the delegated proof.',
 'Native PHP 8.5 attribute syntax skips on PHP 8.4 are retained by per-case final JUnit mapping. No Windows or additional PHP runtime was executed here.',
 'No performance timings or full application integration were run in this rotated pass. Performance-only mutants are not killed with private counters or arbitrary latency thresholds.',
 'Trusted PHP extension handlers, attribute constructors and autoloaders are not sandboxed. Phase guards do not roll back arbitrary application side effects; metadata preflight can call extension supports() before the later parameter/body execution boundary.',
]

assert len(r['files'])==177
assert sum(f['scope']=='production' for f in r['files'])==86
assert sum(f['scope']=='tests' for f in r['files'])==91
assert sum(len(f.get('tests',[])) for f in r['files'])==299
assert sum(len(f.get('current_tests',[])) for f in r['files'])==303
assert len(r['survivors'])==208 and len({s['id'] for s in r['survivors']})==208
assert len(all_proofs)==24
unexecuted=[s for s in r['survivors'] if s['verdict']=='meaningful gap' and 'executed_proof' not in s]
assert len(unexecuted)==67
for s in r['survivors']:
    for anchor in s['anchors']:
        path=anchor.split(':')[0].split('#')[0]
        if path.startswith(('src/','tests/')):assert (REPO/path).is_file(),(s['id'],anchor)
write(r)
(BASE/'unexecuted-meaningful-candidates.json').write_text(json.dumps({'baseline':r['baseline'],'final_code_head':FINAL,'status':'reasoned candidate test questions only; not executed RED and not confirmed production defects','count':len(unexecuted),'candidates':unexecuted},ensure_ascii=False,indent=2)+'\n')
summary={
 'baseline':r['baseline'],'final_code_head':FINAL,'review_path':str(BASE/'review.json'),
 'review_sha256':hashlib.sha256((BASE/'review.json').read_bytes()).hexdigest(),
 'files':177,'fresh_full_read_files':177,'production_files':86,'test_files':91,
 'baseline_declarations':299,'current_declarations':303,
 'current_runtime_cases':{version:sum(len(t['current_runtime_cases']['PHP'+version]) for f in r['files'] for t in f.get('current_tests',[])) for version in ['84','85']},
 'current_runtime_skips':{version:sum(c['status']=='skipped' for f in r['files'] for t in f.get('current_tests',[]) for c in t['current_runtime_cases']['PHP'+version]) for version in ['84','85']},
 'survivors':208,'classified':208,'pending':0,'verdict_counts':dict(collections.Counter(s['verdict'] for s in r['survivors'])),
 'own_source_executed_mutant_ids':sorted(all_proofs),'own_authored_executed_mutant_ids':sorted(owned_proofs),'own_authored_canonical_phase_runs':120,
 'current_declarations_with_executed_red':sum(bool(t.get('executed_evidence')) for f in r['files'] for t in f.get('current_tests',[])),
 'unexecuted_meaningful_candidates':67,'unexecuted_candidate_path':str(BASE/'unexecuted-meaningful-candidates.json'),
 'architecture_note_path':str(BASE/'architecture-boundaries.md'),
 'architecture_note_sha256':hashlib.sha256((BASE/'architecture-boundaries.md').read_bytes()).hexdigest(),
 'runtime_production_edits':0,'static_contract_fixes':1,
 'own_proof_paths':[str(BASE/f) for f in ['composition-proofs.json','semantic-proofs.json','closing-proofs.json','object-pipeline-generic-proof/proof.json']],
}
(BASE/'scope-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
