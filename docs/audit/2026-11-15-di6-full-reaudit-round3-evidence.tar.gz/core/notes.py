from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/8f6c1df8ef3b/di')
DECLARATIONS=json.loads((BASE/'test-declarations.json').read_text())
RUNTIME=list(ET.parse(BASE.parent/'baseline85.xml').getroot().iter('testcase'))
def read():return json.loads((BASE/'review.json').read_text())
def write(r):(BASE/'review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def sources(notes):
 r=read()
 for f in r['files']:
  if f['path'] in notes:
   assert f['scope']=='production'
   f.update(fresh_full_read=True,reviewed_by='/root/core_audit',reviewed_source_sha256=hashlib.sha256((REPO/f['path']).read_bytes()).hexdigest(),assessment=notes[f['path']])
 write(r)
def tests(path,notes):
 r=read();f=next(x for x in r['files'] if x['path']==path);decls=DECLARATIONS[path]['tests'];assert len(decls)==len(notes),(path,len(decls),len(notes))
 entries=[]
 for d,n in zip(decls,notes,strict=True):
  description=('it ' if d['kind']=='it' else '')+d['name']
  cases=[x.attrib['name'] for x in RUNTIME if x.attrib.get('file','').split('::')[0]==path and (x.attrib['name']==description or x.attrib['name'].startswith(description+' with data set '))]
  assert cases,(path,description)
  entries.append({'line':d['line'],'end_line':d['end_line'],'name':d['name'],'kind':d['kind'],'baseline_body_sha256':d['body_sha256'],'contract':n[0],'actual_oracle':n[1],'meaningful_fault':n[2],'variants_and_quality':n[3],'evidence_status':'reasoned counterexample; not executed unless explicitly referenced','executed_evidence':[],'baseline_runtime_cases':cases})
 f.update(fresh_full_read=True,reviewed_by='/root/core_audit',reviewed_source_sha256=hashlib.sha256((REPO/path).read_bytes()).hexdigest(),tests=entries);write(r)
def survivors(notes):
 r=read()
 for id,n in notes.items():
  s=next(x for x in r['survivors'] if x['id']==id)
  verdict,reachability,reason,anchors=n
  assert verdict in ['meaningful gap','equivalent-under-contract','defensive-outside-supported-input','redundant path','needs architecture decision']
  s.update(verdict=verdict,review_status='classified',reachability=reachability,explanation=reason,anchors=anchors,evidence_status='reasoned classification; see explicit proof for executed candidates')
 write(r)
def compact_tests(path,rows):
 decls=DECLARATIONS[path]['tests'];assert len(decls)==len(rows),(path,len(decls),len(rows))
 tests(path,[(d['name'],*row) for d,row in zip(decls,rows,strict=True)])
