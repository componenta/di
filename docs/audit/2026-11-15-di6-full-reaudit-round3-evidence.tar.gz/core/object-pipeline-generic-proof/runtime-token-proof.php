<?php

declare(strict_types=1);

$files = [
    __DIR__ . '/ObjectPipeline-baseline.php',
    '/workspace/scratch/8f6c1df8ef3b/di/src/Object/ObjectPipeline.php',
];
$records = [];
foreach ($files as $file) {
    $source = file_get_contents($file);
    if ($source === false) {
        throw new RuntimeException('Unable to read the selected source.');
    }
    $tokens = [];
    foreach (token_get_all($source, TOKEN_PARSE) as $token) {
        if (is_array($token)) {
            if (in_array($token[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                continue;
            }
            $tokens[] = [$token[0], $token[1]];
        } else {
            $tokens[] = $token;
        }
    }
    $records[] = [
        'path' => $file,
        'source_sha256' => hash('sha256', $source),
        'runtime_token_sha256' => hash('sha256', serialize($tokens)),
        'runtime_token_count' => count($tokens),
    ];
}
$equal = $records[0]['runtime_token_sha256'] === $records[1]['runtime_token_sha256'];
echo json_encode(['php' => PHP_VERSION, 'equal' => $equal, 'records' => $records], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
exit($equal ? 0 : 1);
