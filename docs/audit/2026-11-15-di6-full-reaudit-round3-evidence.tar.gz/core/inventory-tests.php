<?php

declare(strict_types=1);

require '/workspace/scratch/8f6c1df8ef3b/di/vendor/autoload.php';

$root = '/workspace/scratch/8f6c1df8ef3b/di';
$parser = (new PhpParser\ParserFactory())->createForNewestSupportedVersion();
$finder = new PhpParser\NodeFinder();
$printer = new PhpParser\PrettyPrinter\Standard();
$result = [];
$assignment = json_decode(file_get_contents(__DIR__ . '/assignment.json'), true, flags: JSON_THROW_ON_ERROR);
foreach ($assignment['files'] as $assigned) {
    if ($assigned['scope'] !== 'tests') { continue; }
    $file = new SplFileInfo($root . '/' . $assigned['path']);
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }
    $source = file_get_contents($file->getPathname());
    $ast = $parser->parse($source);
    $entries = [];
    foreach ($finder->findInstanceOf($ast, PhpParser\Node\Expr\FuncCall::class) as $call) {
        if (!$call->name instanceof PhpParser\Node\Name || !in_array($call->name->toString(), ['test', 'it'], true)) {
            continue;
        }
        $name = $call->args[0]->value ?? null;
        $body = $call->args[1]->value ?? null;
        if (!$body instanceof PhpParser\Node\Expr\Closure && !$body instanceof PhpParser\Node\Expr\ArrowFunction) {
            continue;
        }
        $expectations = [];
        foreach ($finder->findInstanceOf([$body], PhpParser\Node\Expr\MethodCall::class) as $method) {
            if (!$method->name instanceof PhpParser\Node\Identifier) {
                continue;
            }
            $methodName = $method->name->toString();
            if (str_starts_with($methodName, 'to') || str_starts_with($methodName, 'assert') || str_starts_with($methodName, 'expectException')) {
                $expectations[] = ['line' => $method->getStartLine(), 'method' => $methodName];
            }
        }
        $entries[] = [
            'line' => $call->getStartLine(),
            'end_line' => $call->getEndLine(),
            'kind' => $call->name->toString(),
            'name' => $name instanceof PhpParser\Node\Scalar\String_ ? $name->value : $printer->prettyPrintExpr($name),
            'literal_name' => $name instanceof PhpParser\Node\Scalar\String_,
            'body_sha256' => hash('sha256', substr($source, $body->getStartFilePos(), $body->getEndFilePos() - $body->getStartFilePos() + 1)),
            'expectation_calls' => $expectations,
        ];
    }
    $path = substr($file->getPathname(), strlen($root) + 1);
    $result[$path] = [
        'sha256' => hash('sha256', $source),
        'lines' => substr_count($source, "\n") + (str_ends_with($source, "\n") ? 0 : 1),
        'tests' => $entries,
    ];
}
ksort($result);
file_put_contents($argv[1] ?? __DIR__ . '/test-declarations.json', json_encode($result, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
echo json_encode(['files' => count($result), 'test_declarations' => array_sum(array_map(static fn(array $file): int => count($file['tests']), $result))], JSON_THROW_ON_ERROR) . "\n";
