# DI v6 round-three evidence

This archive preserves the actual evidence from the full re-audit of
`componenta/di`, branch `refactor/di6-definitions-callbacks`.

- Audit baseline: `2eb36241787a971e1a8185149aaa08b90304d426`.
- Validated final code: `19584c03f77036045184d5eef4b992a9e86aaad6`.
- Final code CI: https://github.com/componenta/di/actions/runs/43715494696.
- Authoritative scope: `aggregate-review.json`.
- Canonical evidence selection and deduplicated phase census:
  `aggregate-evidence-files.json`.
- Exact archive byte inventory: `BUNDLE-MANIFEST.json`.

## Reading the evidence

The human reports explain five confirmed individual defects: an even-count
median, two portable CLI source-path failures, and two PHPDoc contracts. None
required changing executable statements in `src/`. Runtime token comparisons
cover all 169 production files on both PHP runtimes.

The scope union contains 444 unique files, 762 test declarations and 552
individually classified baseline mutation survivors. There are 37 declarations
with newly executed meaningful Pest RED/GREEN, covering 57 catalogue mutations,
one bespoke trait-consumer mutation and three actual source bugs. Two PHPStan
RED/GREEN groups are separate. The other 725 declarations have individual manual
counterexample reviews and full-suite execution; they are not claimed as
individually mutation-validated.

The deduplicated canonical local phase census is 408 output artifacts (208 on
PHP 8.4 and 200 on PHP 8.5), plus two Windows CI RED/GREEN pairs. The archive includes
65 exact test-path/SHA preimages and all 240 baseline test/support/fixture files
for the six actual whole-baseline-suite controls. These are phase and file
counts, not a sum of assertions or a claim of independent RED for every test.

For the controlled runtime proofs, inspect the actual old/original GREEN,
old/mutant GREEN, improved/mutant RED and restored/improved GREEN records. Shared
controls are counted once. The two contextual-union faults have PHP 8.4 proofs
only. Windows path fixes have actual Windows CI RED/GREEN pairs, not a Linux
simulation. Test file versions, source hashes, Reflection origins, Composer
classmap remapping and eager-function origins are recorded where applicable.

## Canonical versus historical attempts

The archive deliberately retains superseded and failed attempts. Their presence
does not mean that they count as accepted RED evidence. Use the canonical
selection, `excluded_or_superseded` records, final test hashes and per-proof
qualification. In particular:

- The final inherited-property proof is `inherited-property-identity-v2`.
- `preserved-variants-proof` is canonical for final alias/variadic variants.
- The three alias-shape mutants that only changed message wording are excluded.
- The failed unused-trait PHPStan CI, malformed proof setup, failed fixture
  typing experiments and initial wrong source-origin controls are preserved.
- `prior-final141feff` contains older whole-suite logs/JUnit, not the final run.
- `checkpoint-fddf029` contains the later test-only metadata checkpoint and is
  explicitly not labelled as the earlier141feff AST.
- Direct diagnostic observations are not Pest TDD proofs.
- Native E1 PHP 8.5.8 acceptance is feature-local and remains 2/10; it does not
  prove release provenance or change the package's PHP ^8.4 requirement.

An engine timeout/nonzero status does not establish a meaningful public oracle.
The final mutation summary keeps engine counts and the completed-kill fraction
separate. Baseline survivor classification is not silently reused as a new final
mutation run.

## Reproducing and locating inputs

Historical absolute workspace paths in commands are preserved as actually run.
They identify evidence origins, not portable paths on a reader's machine.
Archive member names are relative to the audit evidence root. Adapt repository,
runtime and output roots before rerunning a driver; inspect each driver's
qualification and select only the intended proof. Do not run every retained
failed experiment as if it were a current gate.

Production source preimages are identified by Git commit, file SHA and exact
mutation diff/needle. Mutable `isolated` checkout directories, temporary Composer
trees, selected-source copies, caches and the reconstructible baseline export
are omitted. Immutable test snapshots that were actually preserved are included,
especially `parameters/immutable-test-snapshots`; their manifest checks 21 exact
test-file versions and 160 accepted proof records. Final and baseline JUnit and
AST inventories are included.

`dependency-snapshot/composer.json`, `composer.lock` and `installed.json` capture
the local dependency graph when present. The lock is evidence, not a newly
introduced repository lock policy. Hosted CI dependency installation is recorded
in its own job logs. A fresh unconstrained install at a future date may differ.

The regular final gates are the existing Composer/Pest, maximum PHPStan, CS Fixer,
Composer validation and repository CI workflows. Local commands and runtime
versions are in `checks/final*.json`. Changed reproduction scripts were checked
explicitly because the normal CS Finder covers `src`, `tests` and `benchmarks`.

CI logs are the tool's decoded UTF-8 content saved byte-for-byte, including native
line endings. Their SHA-256 values describe those saved decoded logs. They are
not SHA-256 values of GitHub's downloadable ZIP transport.

The full re-audit is a manual/source/test assessment. The required Codex Security
server tool was unavailable, so no automated Codex Security scan is represented
in this archive.
