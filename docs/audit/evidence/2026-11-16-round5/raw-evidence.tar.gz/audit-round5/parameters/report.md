# Round 5: callable, parameter and request review

## Scope and outcome

Fresh baseline: `406c8ea563d2fa304434a695c4b6b43f1f269e6f`. The assigned **41 source files and 61 test files, 10,487 lines**, were read in full, including test setup, assertions and in-file fixtures. The per-file [scope ledger](scope-review.json) records SHA-256, review reason, risks and test mappings. At final comparison against main `5365677f48b1caecd8a755d7c9288010516bc905`, all 102 assigned baseline files were still byte-identical. The two new test files are separate additions; they do not inflate the baseline review count.

**No new original-source production defect was confirmed in this assigned scope.** Two test-only units close four demonstrated mutation-survivor gaps. They add **nine runtime cases and 54 assertions per PHP runtime**, with the unmodified baseline GREEN on stable PHP 8.4.27 and 8.5.12. The source was restored after each exact mutant probe and the isolated production diff is empty. This result is scoped to the assigned files; fixes made by the other auditors are accounted for in their evidence.

## Confirmed test gaps and delivered units

| Unit | Public behavior verified | Original and restored source, each runtime | Exact mutant result, each runtime |
|---|---|---:|---|
| `SingleParameterResolutionContractTest.php` | Direct single-parameter resolution returns a reflected default or rejects an unavailable native default; it does not expose the batch omission sentinel. A late DI attribute revealed while validating the value is rejected before the result is accepted; retry observes the newly available policy. | 3 passed, 12 assertions | `ff68328d9d27c7f8` and `5c2be6392ac9f4c2`: each 2 failed / 1 passed / 7 assertions. `13886b8fae4e7683`: 1 failed / 2 passed / 7 assertions. |
| `RequestTransportValidationContractTest.php` | A warmed invokable Header consumer rejects six malformed exact PSR transport-key values with the domain diagnostic, never enters the body on rejection, and succeeds on a later valid request. | 6 passed, 42 assertions | `c685bde216825f99`: 5 failed / 1 passed / 22 assertions. The null control stays valid; non-null malformed values lose the intended diagnostic under the mutant. |

The tests were integrated by root as `122e2401e9e2e4d358e90c3e7780c145b4c49a02` and `aa22449a023bee4ed0421fa39ccecea464e389b7`. Their final bytes in main match the exact tested files. Each file passed targeted PHPStan at max level and style checks. [Single-parameter proof](single-parameter-proof.json) and [request-transport proof](request-transport-proof.json) preserve commands, runtime versions, loaded source origins, original/mutated source hashes, exact diffs and complete log references. These are test-strengthening results: the mutation failures are not RED failures of the original implementation.

## Security boundary

The review treated container configuration, callable specifications, attribute classes, extension implementations and autoloaders as trusted application code. It treated HTTP data entering the request extraction/mapping path as untrusted. The main checks were source precedence, raw-field provenance after mapping, name/type-key collisions with authoritative sources, classless setup suffix ownership, filtering of private DI metadata, malformed PSR transport values and rejection before callback effects. Relevant files and public regression oracles are listed individually in the scope ledger.

No new security bypass was confirmed. The hypothesis that validation could silently return a failure collector and let mapping proceed was rejected after reading the installed validation protocol: `THROW_ON_FAILURE_ATTRIBUTE` requires an exception on failure. An implementation that deliberately ignores that context violates the trusted extension contract; it does not demonstrate a bypass in the reviewed default path. The malformed transport test protects diagnostic ownership and recovery, rather than claiming that the baseline allowed invalid request bodies to execute.

This was a manual source/contract audit. No unavailable security-scanner result, deployment threat model or application-specific exploit is claimed. Native exception traces and application logging remain distinct from private DI provenance transport; the review does not promise generic secret redaction.

## Architecture and lifetime

The callback binder reserves the semantic first argument and sends only the suffix through the shared parameter-resolution loop. Ordinary invocation and callback suffixes share omission, variadic ordering, boundary validation and completed-work checks. The original callback reaches prepared invocation without a second DI pass or lexical rebinding. Simple-union selection stays in the shared autowire resolver, recomputes mutable service availability and validates the selected arm; explicit definitions retain their separate lifecycle and omission contract.

The review traced closure, invokable, declared method and magic callable forms, input reference-slot snapshots, native exception ownership, case-normalized metadata identity and exact opaque service-ID lookup. Invocation values and closures must not become long-lived semantic plan data. No new architecture change was necessary to deliver the two completed units.

The exact `090c1a0b20df101a` mutation was also tested with existing closure-lifetime controls: **9 passed / 19 assertions on both runtimes**, both before and after applying that mutation. It adds a WeakMap write for an otherwise uncached target, while the cache-hit path remains gated. That changes metadata ownership and write behavior even when the selected calls return the same values. Collection of the callback captures checked by these finite controls does not prove collection of every target/reflector graph or bounded retained metadata under other workloads. This negative probe did **not** reproduce a leak; it also does not establish global equivalence or justify a production optimization.

## Performance and survivor accounting

All **104 scoped survivors** from the last completed 477-survivor CI catalogue were read against the fresh source. The [survivor ledger](survivors-reviewed.json) embeds each exact raw diff and distinguishes current-path equivalence, redundant guards, performance-only changes, unsupported/unused helper boundaries and unexecuted behavioral-gap candidates. The catalogue is tied to source `299ee93` and CI run `43774753909`; its source tree matches the Round 5 baseline exactly.

Only **five exact mutants** were executed in this subtask: four were killed by the new public tests and the lifetime-related mutant above stayed GREEN. The other 99 are static classifications. The previous count of 477 is not a new post-change survivor total, and no repository-wide MSI improvement is inferred from these focused probes.

The principal unexecuted candidates remain explicit:

- `245ed746fee2be78`: removing an intermediate completed-work check may allow a third dependency's side effect before the final rejection. A public three-parameter witness is proposed in the ledger; it was not run.
- `591d0e5dc55f3f07`: removing the final guard loses a distinct discovery boundary. No fixed polling-count assertion was added to force a kill.
- `fae32c278c6b8611` / `d2d5f167e0eb1f52`: reversing one revision source is not globally equivalent when resolver registration and attribute discovery can interact. A public unsealed-pipeline interleaving witness remains a candidate.
- `b0f38dc73fb5ba15` / `b3c5cbf535dc68ab`: structured request-conflict fields are covered, while the class-only versus parameter-qualified diagnostic branch has a remaining test-gap candidate.

None of these entries is a confirmed defect in the original source. No new benchmark or application-speedup result was produced in this subtask. The known unresolved-name polling cost remains governed by the existing B2 plan, whose contract and workload prerequisites are not waived by mutation results.

## Migration and plan review

All **14 current EN/RU files under `docs/migrations` and `docs/plans`, 3,440 lines**, were read completely and compared by contract. Their [document ledger](docs-review.json) records hashes, risks, code/test oracles, language parity and limitations. All 14 documents remain byte-identical to the immutable Round 5 baseline. **No concrete correction was required: approved with limits.**

- Definition ownership, registration-free strategies, snapshots, attached-root mutation and post-publication retirement are described consistently. A nested `MutationRetirementException` does not imply the outer operation published.
- D1/A is accepted and implemented at the default adapter boundary. Custom factory delegation, native unsupported-kind errors, private ancestor slots and eager migration remain distinct. Its old local/CI totals retain their original source identity.
- B2 is conditional, G2/G3 remain blocked, and A/C are not silently adopted. Historical timings do not establish a current-source or application speedup.
- E1 limits affected native expression support; it does not change Composer `^8.4` or block the entire library. The dated plan's source-only 8.5.12 record remains historical. Root's fresh stable-8.5.12 probe, which again fails eight affected cases and passes two controls, belongs in the Round 5 evidence rather than replacing that old observation.

The document review did not rerun every linked historical proof, certify a later PHP release or change any shared-checkout file. Whole-library gates, fresh platform evidence and final CI are owned and recorded by root.
