from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import re

base = Path('/workspace/scratch/4d17f5340b2e/audit-round5')
repo = base.parent / 'di'
read = lambda name: json.loads((base / name).read_text())
inventory = read('repository-inventory.json')
identity = read('final-repository-identity.json')
baseline = {x['path']: x for x in inventory['files']}
sources = {
    'core': read('core/review-ledger.json')['files'],
    'attributes': read('attributes/scope-ledger.json')['files'],
    'parameters': read('parameters/scope-review.json')['files'],
    'root': read('root-review-ledger.json'),
}
records = []
for owner, entries in sources.items():
    for entry in entries:
        path = entry['path']
        assert path in baseline and entry['sha256'] == baseline[path]['sha256'], path
        historical = entry.get('review') == 'historical-status-provenance-and-integrity'
        full = (entry.get('reviewed_in_full') or entry.get('review_status') == 'reviewed_in_full'
                or entry.get('review') == 'read-in-full')
        assert historical or full, path
        assert entry.get('review_reason'), path
        mappings = entry.get('test_mapping', [])
        if isinstance(mappings, str):
            mappings = []  # Root test records use a narrative mapping; retain it in detail.
        for mapping in mappings:
            mapped_path = mapping['path'] if isinstance(mapping, dict) else mapping
            assert (repo / mapped_path).exists(), (path, mapped_path)
        records.append({
            'path': path, 'review_owner': owner, 'baseline_sha256': entry['sha256'],
            'final_sha256': identity['paths'][path],
            'method': 'historical-status-provenance-and-integrity' if historical else 'full-file-review',
            'review_reason': entry['review_reason'],
            'risks': entry.get('risks', entry.get('risks_checked', [])),
            'test_mapping': mappings,
            'detail': entry,
        })
assert len(records) == len({x['path'] for x in records}) == 563
assert {x['path'] for x in records} == set(baseline)
review = read('parameters/independent-change-review.json')
changes = {x['path']: x for x in review['files']}
for path in set(baseline) & set(changes):
    assert identity['paths'][path] == changes[path]['head_sha256']
additions = []
for path in sorted(set(identity['paths']) - set(baseline)):
    x = changes[path]
    assert x['status'] == 'A' and x['reviewed_file_in_full']
    additions.append({'path': path, 'final_sha256': identity['paths'][path],
                      'method': 'new-regression-file-complete-review-and-execution', 'change_review': x})
assert len(additions) == 5 and all(x['path'].startswith('tests/') for x in additions)
scope = {
    'baseline': inventory['baseline'], 'implementation_head': identity['head'],
    'baseline_counts': {'tracked': 563, 'src': 169, 'tests': 249, 'active_other': 50, 'historical_other': 95},
    'review_method_counts': dict(Counter(x['method'] for x in records)),
    'final_counts': {k: identity[k] for k in ['tracked_files', 'src_files', 'test_files']},
    'source_tests_sha256': identity['source_tests_sha256'], 'pending': 0,
    'baseline_files': sorted(records, key=lambda x: x['path']), 'new_files': additions,
    'final_change_review': review,
    'limits': ['Historical artifacts were checked for status, provenance and integrity, not all line-by-line reread or re-executed.',
               'Test mappings identify relevant behavioral evidence; they are not a claim of exhaustive branch coverage.',
               'Each changed original file retains its baseline hash and separately records the final reviewed hash.'],
}
(base / 'combined-scope.json').write_text(json.dumps(scope, indent=2, ensure_ascii=False) + '\n')

catalog = repo / 'docs/audit/evidence/2026-11-16-propertyless-lazy/coverage-mutation-job-132998417946.log.gz'
raw = gzip.decompress(catalog.read_bytes())
clean = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw.decode())
ids = re.findall(r'UNTESTED[^\n]* - ID: ([a-f0-9]+)', clean)
assert len(ids) == len(set(ids)) == 477
entries = []
for owner, data in [('core', read('core/mutation-survivors.json')['entries']),
                    ('attributes', read('attributes/mutation-scope.json')['mutants']),
                    ('parameters', read('parameters/survivors-reviewed.json')['survivors'])]:
    for x in data:
        rx = x.get('review', x)
        entries.append({'id': x['id'], 'review_owner': owner, 'path': x.get('path', x.get('file')),
                        'classification': rx['classification'], 'reason': rx['reason'], 'detail': x})
assert len(entries) == len({x['id'] for x in entries}) == 477
assert {x['id'] for x in entries} == set(ids)
killed = ['ff68328d9d27c7f8', '5c2be6392ac9f4c2', '13886b8fae4e7683', 'c685bde216825f99',
          'e28e3d4eea2832d6', '2d3da5b42f6aaf02', '989628a219306c29']
green = ['090c1a0b20df101a']
assert set(killed + green) <= set(ids)
for x in entries:
    x['fresh_focused_execution'] = 'killed-by-new-public-test-both-stable-runtimes' if x['id'] in killed else (
        'remained-green-under-finite-lifetime-controls-both-stable-runtimes' if x['id'] in green else 'not-executed-in-focused-review')
survivors = {
    'catalog_commit': '299ee93f6be6d91e3a4fc1372389f1fff953d61b', 'catalog_run': 43774753909,
    'catalog_source_tree_matches_round5_baseline': True,
    'catalog_gzip_sha256': hashlib.sha256(catalog.read_bytes()).hexdigest(),
    'catalog_uncompressed_sha256': hashlib.sha256(raw).hexdigest(),
    'historical_survivors': 477, 'reviewed': 477, 'pending': 0,
    'owner_counts': dict(Counter(x['review_owner'] for x in entries)),
    'classification_counts_by_owner': {owner: dict(Counter(x['classification'] for x in entries if x['review_owner'] == owner))
                                      for owner in ['core', 'attributes', 'parameters']},
    'focused_execution': {'exact_catalog_mutants_executed': 8, 'exact_killed_ids': killed,
                          'finite_green_ids': green, 'static_only_entries': 469,
                          'additional_synthetic_mutation': 'Factory-owner clone: old value equality GREEN, exact object identity assertions RED; not a catalog ID.'},
    'entries': sorted(entries, key=lambda x: x['id']),
    'limits': ['This is a review of the prior immutable catalogue, not the final full-CI survivor count or MSI.',
               'Seven exact kills and one finite GREEN were separately executed locally; the remaining469 entries have static reasoning.',
               'Static equivalence is conditional on each recorded invariant; candidate witness descriptions do not claim execution.',
               'A hypothetical difference in mutated code is not a confirmed defect of the original implementation.'],
}
(base / 'combined-survivors.json').write_text(json.dumps(survivors, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'baseline_file_records': len(records), 'new_files': len(additions),
                  'review_methods': scope['review_method_counts'], 'survivors': len(entries),
                  'exact_killed': len(killed), 'finite_green': len(green), 'static_only': 469}))
