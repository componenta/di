# DI v6 — round 5: атрибуты, композиция и жизненный цикл

Дата: 16 ноября 2026 года. Область: агент `attributes_audit`.

## Итог и границы доказательств

Повторно и целиком прочитаны **77 production-файлов и 75 назначенных тестовых/вспомогательных файлов — 152 файла**. Для каждого сохранены исходный SHA-256, конкретные проверенные риски, заметки о поведении и связь с тестами в [scope-ledger.json](scope-ledger.json). Начальная ревизия чтения — `406c8ea563d2fa304434a695c4b6b43f1f269e6f`; исходные хеши не подменены хешами последующих исправлений. Для изменённых файлов отдельно указаны фактически проверенные рабочие байты. Новый регрессионный файл учтён как дополнительная проверка, а не как увеличение исходного охвата.

Результат этой области — **один подтверждённый production-баг и два усиления тестовых oracle**. Исправление и тесты уже переданы родительскому агенту и интегрированы. Родитель сообщает итоговый код/тесты `5365677` и 1648 суммарных локальных runtime cases; это его сводный результат. Приведённые ниже собственные доказательства относятся к указанным файлам, версиям PHP и сохранённым байтам, а не заменяют финальные общие gates.

Все **146** записей исторического mutation-каталога, относящихся к назначенному source scope, классифицированы; незавершённых записей нет. **Новых необязательных прогонов и расширений scope при закрытии ledger не выполнялось.**

## 1. Исправленный production-баг: Proxy для продукта с непубличным конструктором

`MakeHandler::resolveProxyClass()` использовал `ReflectionClass::isInstantiable()`. Этот предикат отклонял конкретный класс с private/protected конструктором ещё до передачи управления фабрике. Однако продукт законно создаёт пользовательская фабрика; альтернативно приложение явно выбирает `#[NoConstructor]`. Непубличный конструктор сам по себе не означает, что virtual proxy невозможно получить.

Исправление заменяет эту проверку точной ранней проверкой interface/trait/abstract/enum. Общий native eligibility gate в MakeHandler не добавлен. Default `ProxyFactory` сохраняет принятую D1-проверку backed instance properties и свою нормализацию native ошибок. Пользовательские реализации factory interfaces сохраняют собственную границу ответственности.

В новом `NonPublicConstructorProxyContractTest.php` проверены parameter/property injection, private/protected фабричные продукты, отложенный запуск фабрики ровно один раз, точная identity реально созданного backing object, `NoConstructor` с отложенным SetUp, четыре неподдерживаемых вида классов и propertyless D1 без factory/constructor/destructor side effects.

| Доказательство на окончательных байтах теста | PHP 8.4.27 | PHP 8.5.12 |
|---|---:|---:|
| Baseline MakeHandler + новый тест | 8 failed, 4 passed, 24 assertions | 8 failed, 4 passed, 24 assertions |
| Исправленный MakeHandler + тот же тест | 12 passed, 82 assertions | 12 passed, 82 assertions |

Каноническое доказательство: [nonpublic-proxy-proof-final.json](nonpublic-proxy-proof-final.json). SHA-256 окончательного теста: `37c987938752e570ddf06fdc38dda36dc903fa8d86747afc8926e7909beb1aeb`.

Первоначальный commit исправления — `ce0c0a6414d649eb86bf099cc88f2559b63baa1e`. Полный CI обнаружил unused trait в первоначальной тестовой фикстуре, который адресный PHPStan не выявил. После реального использования trait в уже проверяемом abstract Product RED/GREEN повторены на окончательных байтах; промежуточное доказательство сохранено отдельно. Это ограничение адресной проверки отражено явно, а не скрыто за первым GREEN.

## 2. Усиленные тестовые oracle

### Точная identity владельца callback-фабрики

В `FactoryDefinitionSnapshotContractTest.php` структурное сравнение Product было дополнено `owner->toBe($original)` для bootstrap/runtime и cold/warm вариантов. Структурно равный клон владельца теперь не принимается за исходный объект.

Специальный **synthetic**, не каталожный, mutant клонировал владельца object-array factory перед вызовом. Старый связанный файл оставался GREEN — 7 cases / 24 assertions. Усиленный файл дал RED — 4 failed, 3 passed / 22 assertions на обеих PHP. Это подтверждённый недостаток прежнего oracle, а не новый production-баг.

### Capability LifecycleHook у встроенного SetUp

Новый case в `SetUpPropertyOrderContractTest.php` регистрирует пользовательский after-instantiation handler с публичным селектором `before: [LifecycleHook::class]`. Он должен предшествовать SetUp даже при более поздней декларации атрибута; порядок проверен в двух последовательных созданиях.

Точный mutant каталога `e28e3d4eea2832d6` убирает `LifecycleHook::class` из определения SetUp в ContainerFactory. Старый связанный файл: 9 cases / 26 assertions GREEN. Усиленный: 1 failed, 9 passed / 27 assertions RED, обе PHP. После восстановления production два изменённых файла вместе дают 17 cases / 60 assertions GREEN. Дельта этого тестового участка — один runtime case и десять assertions.

Доказательство: [attribute-test-gaps-proof.json](attribute-test-gaps-proof.json). Patch: [factory-owner-and-setup-capability-tests.patch](factory-owner-and-setup-capability-tests.patch). В доказательстве приведены команды, точные мутации, исходные/итоговые хеши и сырые результаты. Проверялись названные связанные файлы; утверждения о полном старом suite здесь нет.

## 3. Все 146 mutation dispositions

Машинный результат: [mutation-scope.json](mutation-scope.json). В нём сохранены исходные ID/diff/строка, обоснование каждого решения, связь с тестами и отдельное поле перспективного witness. Каждый из 146 результатов помечен `analysis_mode: static`, `runtime_witness: null`.

| Классификация | Число |
|---|---:|
| Эквивалентность при явно указанных инвариантах native metadata / validated plans / текущих вызовов | 45 |
| Производительность, удержание metadata или момент discovery | 25 |
| Статический кандидат на недостающий публичный contract oracle | 37 |
| Порядок защитных проверок / defense in depth | 10 |
| Защита от некорректного доверенного extension/provider/PSR implementation | 12 |
| Недостижимая ветка внутреннего метода в текущем production call graph | 6 |
| Отличие диагностики или порядка диагностического обхода | 5 |
| Нормализация входа вне документированного list-контракта | 4 |
| Абсолютное непрозрачное значение revision при сохранённом сравнении поколений | 2 |
| **Всего** | **146** |

Все 477 заголовков записей в сохранённом историческом логе имеют метку `UNTESTED`. Число 146 означает сопоставленную и разобранную часть каталога; оно не означает 146 новых запусков Infection или 146 найденных production-багов. Показатель MSI этим чтением не пересчитан.

37 статических contract-кандидатов и 10 timing-кандидатов **не объявлены подтверждёнными дефектами baseline**. Это различия, которые могут потребовать более точного oracle. Для части timing-сценариев другой guard ещё может остановить выполнение раньше предполагаемого эффекта; такая достижимость явно оставлена непроверенной. Доказанный SetUp mutant относится к source scope core и вынесен отдельно; synthetic owner clone также не включён в эти 146.

Наиболее конкретные оставшиеся статические направления — Env с explicit name, отличающимся от имени аргумента, caller override Env и union/untyped target; property Cast fallback; metadata-only parameter usages; cache для `ReflectionMethod` объекта Closure; момент фиксации property transaction при discovery; side effects до более позднего completed-phase guard. Существующий код не изменён ради этих гипотез, новые прогоны не выданы за состоявшиеся.

## 4. Security: проверенные границы

**Недоверенный вход** — значения PSR-7 query, parsed body, headers, cookies, server attributes и uploads. **Доверенная конфигурация приложения** — объявленные PHP attributes, DI definitions, имена сервисов/классов, ConfigPath selectors, callback/caster/validator implementations и реализация PSR request/parser.

Проверен путь raw extraction → проверка named DTO keys → validation → configured cast → повторная проверка ключей → source-conflict/provenance guards → request context → создание DTO. HTTP-значение в этом пути не выбирает имя вызываемого callback, атрибута, DI service или класса DTO. Класс DTO определяется объявленным target type; selectors и callbacks задаёт код приложения.

В прочитанном слое нет чтения raw body stream, JSON decoding, unserialization или чтения/перемещения upload-файла. Extractors обращаются к соответствующим PSR getters. Следовательно, repeated mapping может повторять обработку уже разобранных значений, но не перечитывает raw stream в этом слое. Query operator-like keys/strings остаются значениями; встроенного языка запросов или eval нет. Wildcard/path semantics возникают из доверенного настроенного selector.

Missing различается с `null`, `false`, `0` и пустой строкой через presence checks и отдельные sentinel values. Literal dotted payload key и ConfigPath имеют разные маршруты; для UploadedFile сначала проверяется прямой ключ. Объектный payload проецируется через публичные значения, без чтения private fields и без `__get`. **Публичный PHP property get hook при такой проекции может исполниться**; это явно проверяемое текущее поведение, а не обещание отсутствия любых hooks. Объект с таким hook поступает от доверенного приложения/parser, а не возникает из обычного JSON `stdClass` сам собой.

Validator вызывается с `THROW_ON_FAILURE_ATTRIBUTE=true`. Установленный контракт validation прямо требует выбрасывать ValidationException при ошибках в этом режиме. Гипотеза о validator, который вместо этого возвращает collector, отклонена как нарушение доверенного extension protocol; подтверждённого обхода validation из неё не следует.

Проверены source conflicts между mapped request data и отдельными request attributes, позднее открытие metadata, provenance для конструктора и classless SetUp callback, отсутствие внутреннего transport metadata в публичном parameter bag. Transform сохраняет semantic first argument, а разрешение остальных аргументов callback не получает автоматически caller bag или ambient HTTP request. После преобразования сохраняется итоговая проверка native type.

Оставшиеся **policy/cost границы**: ограничения размера/глубины/числа полей запроса, upload byte size/error policy, совокупная стоимость validation/casting и поведение parser/PSR implementation определяются приложением. DI не вводит отдельные квоты. Copy/merge больших массивов и повторное mapping могут стоить пропорционально объёму уже разобранных данных; эксплойт или измеренная DoS-амплификация в этой работе не подтверждены.

Для exception lifetime сохранено различие detached diagnostic fields и native Throwable trace: при `zend.exception_ignore_args=0` удерживаемое исключение может удерживать callback arguments через trace. D1 lifetime-проверки используют и восстанавливают нужную ini-настройку; общего обещания sanitization native trace нет. Обычное выполнение доверенного factory/attribute callback не классифицировалось как RCE.

**Подтверждённой security-уязвимости в этой области не найдено.** Это вывод ручного аудита конкретных границ, а не результат недоступного внешнего security scanner и не доказательство безопасности произвольных пользовательских расширений.

## 5. Архитектура и производительность

Центральная регистратура изменяема, а AttributeDefinition bindings — readonly snapshots. Декларативные массивы отделяются до autoload; handler/rule объекты сохраняют identity и актуальное доверенное состояние. Проверены canonical class/interface identity, exact/nearest ancestor matching, ambiguity errors и invalidation по availability revision. Планы хранят metadata, а не runtime значения callback/attribute instances. Для mutable custom rules стабильное memoization отключается.

Проверены completed prefixes, запрет позднего изменения уже исполненной фазы, однократный commit промежуточных property values, native property hooks, наследуемые private backed slots, readonly targets и повторные lazy attempts с новым resolution context. Default ProxyFactory сохраняет D1 rejection до выделения target object для otherwise native-eligible propertyless классов. Неисполняемые виды и неподдерживаемое internal ancestry сохраняют native error route и previous exception; arbitrary attribute arguments при eligibility inspection не вычисляются. Eager fallback не появился. Custom adapters не получили скрытый default-native запрет.

Явно разделены создание контейнером и продукты пользовательских definitions/factories: готовый фабричный продукт не приобретает автоматически повторную обработку attribute lifecycle. Проверен snapshot callable-owner identity и отсутствие случайного клонирования владельца в production.

Нового архитектурного изменения эта область не обосновывает. Не объявлена ошибкой гипотеза о custom member-targeted ConstructorPolicy, меняющем eligibility private constructor: builtin NoConstructor class-only, а достаточного публичного oracle для расширения eligibility с member targets нет. Такое расширение потребовало бы отдельного контракта; оно не добавлено молча.

Metadata/constructor-plan caches уменьшают повторную reflection для стабильного класса. Runtime значения и object defaults не превращены в общие кешированные экземпляры. Проверены исключения для dynamic reflection/closures, освобождение pending lazy callback после success/discard и сохранение retry-состояния лишь пока оно нужно. Новый application-throughput benchmark этим агентом не проводился.

Родительский повторный availability probe показывает 24/192 autoload обращения на `make` при 1/8 missing attributes и 0 на shared `get`; это его измерение, а не локальный результат этого отчёта. Оно подтверждает условный cost вопрос B2, но само по себе не обосновывает изменение контракта late discovery.

## Передаваемые артефакты

- [scope-ledger.json](scope-ledger.json): 152/152 полных per-file review, исходные и изменённые хеши, risks и test mapping.
- [mutation-scope.json](mutation-scope.json): 146/146 окончательных static dispositions, исходные diff и честные ограничения достижимости.
- [nonpublic-proxy-proof-final.json](nonpublic-proxy-proof-final.json): окончательные RED/GREEN на обеих stable PHP.
- [attribute-test-gaps-proof.json](attribute-test-gaps-proof.json): каталожный SetUp witness и отдельный synthetic owner-identity witness.
- [factory-owner-and-setup-capability-tests.patch](factory-owner-and-setup-capability-tests.patch): принятый двухфайловый test-only участок.

Общий checkout не изменялся этим финальным проходом; новых production-изменений, architecture decisions или неподтверждённых runtime результатов в закрывающую сводку не добавлено.

