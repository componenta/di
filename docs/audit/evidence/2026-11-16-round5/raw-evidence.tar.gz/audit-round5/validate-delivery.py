from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

base = Path(__file__).parent
repo = base.parent / 'di'
dest = repo / 'docs/audit/evidence/2026-11-16-round5'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
manifest = read(dest / 'manifest.json')
identity = read(base / 'final-repository-identity.json')
for f in manifest['files']:
    raw = (dest / f['path']).read_bytes()
    assert len(raw) == f['bytes'] and sha(raw) == f['sha256'], f['path']

secret_patterns = [
    re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})'),
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    re.compile(rb'[?&](?:sig|X-Amz-Signature|access_token)=([A-Za-z0-9%+/=_-]{12,})'),
]
json_count = 0
with tarfile.open(dest / 'raw-evidence.tar.gz', 'r:gz') as archive:
    names = set(archive.getnames())
    assert names == {x['path'] for x in manifest['archive_members']}
    for member in manifest['archive_members']:
        info = archive.getmember(member['path'])
        assert info.isfile() and '..' not in Path(info.name).parts and not Path(info.name).is_absolute()
        data = archive.extractfile(info).read()
        assert len(data) == member['bytes'] and sha(data) == member['sha256']
        if Path(info.name).suffix in ['.json', '.md', '.py', '.php', '.patch', '.log', '.xml']:
            assert not any(p.search(data) for p in secret_patterns), 'Potential credential material in ' + info.name
        if info.name.endswith('.json'):
            json.loads(data)
            json_count += 1
    assert gzip.decompress((dest / 'coverage.xml.gz').read_bytes()) == archive.extractfile('audit-round5/ci-final/coverage.xml').read()
    v = read(dest / 'verification.json')
    for finding in v['findings']:
        assert finding['canonical_proof'] in names
    for gate in v['local_gates']:
        assert gate['archive_record'] in names and gate['archive_log'] in names
    for record in v['review_records'].values():
        assert (dest / record).is_file() or record in names, record

scope = read(dest / 'scope.json')
assert scope['pending'] == 0
assert len(scope['baseline_files']) == 563 and len(scope['new_files']) == 5
survivors = read(dest / 'survivors.json')
assert len(survivors['entries']) == survivors['reviewed'] == 477
assert len(survivors['fresh_full_ci']['entries']) == 468
assert len({x['id'] for x in survivors['fresh_full_ci']['entries']}) == 468
assert sum(survivors['owner_counts'].values()) == 477
for owner, counts in survivors['classification_counts_by_owner'].items():
    assert sum(counts.values()) == survivors['owner_counts'][owner]
assert read(dest / 'ci.json') == read(base / 'ci-final/final-ci-summary.json')
ci = read(dest / 'ci.json')
assert ci['all_five_required_jobs_success'] and ci['run']['head_sha'] == identity['head']
assert ci['mutation']['total'] == 4276 and ci['mutation']['categories']['untested'] == 468

paths = subprocess.check_output(['git', 'ls-files', 'src', 'tests'], cwd=repo, text=True).splitlines()
files = {p: sha((repo / p).read_bytes()) for p in paths}
fingerprint = sha(json.dumps(files, sort_keys=True).encode())
assert len(paths) == 423 and fingerprint == identity['source_tests_sha256']
assert not subprocess.check_output(['git', 'diff', '--', 'src', 'tests'], cwd=repo, text=True)

docs = [repo / 'docs/audit/2026-11-16-di6-full-reaudit-round5.md',
        repo / 'docs/audit/2026-11-16-di6-full-reaudit-round5.ru.md', dest / 'README.md']
link_count = 0
for p in docs:
    text = p.read_text()
    assert '@@' not in text, p
    text = re.sub(r'^```.*?^```[ \t]*$', '', text, flags=re.M | re.S)
    text = re.sub(r'`[^`\n]+`', '', text)
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        if re.match(r'^[A-Za-z]+:', link) or link.startswith('#'):
            continue
        target = link.split('#', 1)[0]
        assert (p.parent / target).exists(), (p, link)
        link_count += 1
    lines = p.read_text().splitlines()
    for i, line in enumerate(lines):
        if re.match(r'^#{1,6} ', line):
            assert i + 1 < len(lines) and not lines[i + 1].strip(), (p, i, 'missing blank after heading')

report_review = read(base / 'ci-final/report-ci-review.json')
result = {
    'implementation_head': identity['head'],
    'source_tests_fingerprint': fingerprint,
    'source_tests_unchanged': True,
    'archive_members_verified': len(manifest['archive_members']),
    'archive_json_members_parsed': json_count,
    'delivery_file_hashes_verified': len(manifest['files']),
    'current_survivor_entries': 468,
    'historical_survivor_entries': 477,
    'relative_markdown_links_verified': link_count,
    'credential_pattern_scan': 'no matches in selected text artifact types',
    'coverage_gzip_equals_original_xml': True,
    'report_ci_review_present': True,
}
(base / 'delivery-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
