from pathlib import Path
from collections import Counter
import hashlib
import json

base = Path(__file__).parent
read = lambda name: json.loads((base / name).read_text())
ledger = read('combined-survivors.json')
assert 'fresh_full_ci' not in ledger, 'Apply this overlay once, after rebuilding the baseline combined ledger.'
entries = {e['id']: e for e in ledger['entries']}
assert len(entries) == 477
attribute = read('ci-final/fresh-attribute-survivor-review.json')
core = read('ci-final/fresh-core-survivor-review.json')
fresh = read('ci-final/fresh-survivors.json')
delta = read('ci-final/survivor-delta.json')
relocations = read('ci-final/survivor-relocations.json')
assert delta['same_id_diff_context_changed'] == []
assert len(relocations['mappings']) == 10

reviewed_pairs = {}
for path, source, names in [
    ('ci-final/fresh-attribute-survivor-review.json', attribute['entries'], ('old_id', 'new_id', 'corrected_classification', 'corrected_reason')),
    ('ci-final/fresh-core-survivor-review.json', core['reviews'], ('old_id', 'new_id', 'classification', 'reason')),
]:
    for item in source:
        old_id, new_id, category, reason = (item[k] for k in names)
        entry = entries[old_id]
        assert new_id not in reviewed_pairs
        reviewed_pairs[new_id] = old_id
        entry['historical_review_before_final_overlay'] = {
            'classification': entry['classification'], 'reason': entry['reason'],
            'status': 'superseded by current classification/reason; original detail retained as dated provenance',
        }
        entry['classification'] = category
        entry['reason'] = reason
        entry['current_reason_limits'] = item['limits']
        entry['detail_status'] = 'Original immutable reviewer record. Where wording differs, the top-level current classification/reason and cited overlay supersede it.'
        entry['final_ci_review'] = {
            'fresh_id': new_id, 'overlay': 'audit-round5/' + path,
            'overlay_sha256': hashlib.sha256((base / path).read_bytes()).hexdigest(),
            'mode': 'static_read_only', 'new_runtime_witness': None,
            'original_code_bug_confirmed': False,
        }

assert set(reviewed_pairs) == set(delta['added_ids'])
assert len(set(reviewed_pairs.values())) == 10
for mapping in relocations['mappings']:
    assert reviewed_pairs[mapping['fresh_id']] == mapping['selected_predecessor']['old_id']

ledger['classification_counts_by_owner'] = {
    owner: dict(sorted(Counter(e['classification'] for e in entries.values() if e['review_owner'] == owner).items()))
    for owner in ledger['owner_counts']
}
ledger['limits'] = [x.replace('remaining469', 'remaining 469') for x in ledger['limits']]
ledger['limits'].append('Final CI correspondence and corrected explanations are in fresh_full_ci and top-level current classification/reason. Original detail/proofs preserve their historical bytes; superseded wording must not be treated as the current conclusion.')
current = []
for mutation in sorted(fresh['survivors'], key=lambda e: e['id']):
    old_id = reviewed_pairs.get(mutation['id'], mutation['id'])
    prior = entries[old_id]
    assert mutation['file'] == prior['path']
    current.append({
        'id': mutation['id'], 'prior_id': old_id, 'path': mutation['file'],
        'line': mutation['line'], 'mutator': mutation['mutator'],
        'review_owner': prior['review_owner'], 'classification': prior['classification'],
        'reason': prior['reason'],
        'relationship': 'retained_id_and_identical_printed_diff' if mutation['id'] == old_id else 'reviewed_printed_mutation_predecessor_after_source_edit',
        'review_record': prior.get('final_ci_review', {}).get('overlay', 'entries[' + old_id + '].detail'),
        'focused_execution_of_prior_mutant': prior['fresh_focused_execution'],
        'limits': prior.get('current_reason_limits', [
            'Review is inherited from the individually classified prior entry with unchanged ID/printed diff; see its full detail for invariants and candidate-witness limits.',
            'The final CI successful worker establishes survival of this test run, not global equivalence or absence of all defects.',
        ]),
    })
assert len(current) == len({e['id'] for e in current}) == 468
ledger['fresh_full_ci'] = {
    'head_sha': fresh['head_sha'], 'run_id': fresh['run_id'], 'job_id': fresh['job_id'],
    'survivors': 468, 'retained_ids': 458, 'added_ids': 10, 'absent_old_ids': 19,
    'reviewed_added_id_pairs': 10, 'entire_diff_context_identical_pairs': 9,
    'changed_lines_identical_with_updated_surrounding_context_pairs': 1,
    'absent_old_ids_not_explained_by_relocated_printed_mutations': relocations['old_ids_absent_and_not_explained_by_these_printed_predecessors'],
    'entries': current,
    'evidence': [
        'audit-round5/ci-final/fresh-survivors.json', 'audit-round5/ci-final/survivor-delta.json',
        'audit-round5/ci-final/survivor-relocations.json',
        'audit-round5/ci-final/fresh-attribute-survivor-review.json',
        'audit-round5/ci-final/fresh-core-survivor-review.json',
    ],
    'limits': [
        'These are final-run UNTESTED survivors. Tested/Timeout status cannot be inferred from absence of an old ID.',
        'Printed mutation correspondence is narrower than a claim that all reachable behaviors of edited programs are equivalent.',
        'No new runtime witness or original-source defect was established by the ten pair-specific static reviews.',
    ],
}
(base / 'combined-survivors.json').write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'prior_entries': len(entries), 'fresh_entries': len(current), 'overlaid_pairs': len(reviewed_pairs), 'classification_counts': ledger['classification_counts_by_owner']}, indent=2))
