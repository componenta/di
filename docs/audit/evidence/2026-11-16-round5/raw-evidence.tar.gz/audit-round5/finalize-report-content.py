from pathlib import Path
import shutil

base = Path(__file__).parent
sections = {
    'en': '''### Exact final-code CI

[Run 43857035628](https://github.com/componenta/di/actions/runs/43857035628), attempt 1, completed successfully for `42b62afd9c6a57caa0db3916585e823ab6ebaafa`. All five required jobs passed. The optional historical-comparison benchmark job runs only for manual workflow dispatch and was skipped for this push.

| CI job | Passed | Skipped | Assertions | Result |
|---|---:|---:|---:|---|
| Linux / PHP 8.4 | 1,630 | 18 | 24,953 | Success |
| Linux / PHP 8.5 | 1,647 | 1 | 25,060 | Success |
| Windows / PHP 8.4 | 1,629 | 19 | 24,951 | Success |
| Windows / PHP 8.5 | 1,646 | 2 | 25,058 | Success |
| Coverage and mutation / PHP 8.4 | 1,630 | 18 | 24,953 | Success |

All four platform jobs passed the complete configured PHPStan max-level and style checks; the latter reported 0 / 418 files requiring changes. Full job logs, run/job metadata and independent metric checks are in the raw archive under `audit-round5/ci-final/`. The final report/evidence commit changes documentation and preserves the tested source and test trees.

**Coverage.** The downloaded Clover artifact reports **4,498 / 4,848 statements = 92.78%** and **441 / 558 methods = 79.03%** across all 169 production files. File totals reconcile with project totals, and the source-file set matches the tested commit. Pest prints **92.7%** because its formatter floors to one decimal place. These are statement and method measurements; the artifact does not establish branch/path coverage. Artifact `14224202628` was checked against its API SHA-256 digest, ZIP CRCs and exact extracted XML bytes. Its complete identity is in [ci.json](evidence/2026-11-16-round5/ci.json); the [lossless Clover copy](evidence/2026-11-16-round5/coverage.xml.gz) is retained.

**Mutation.** The completed run created **4,276 mutations in 115 files**: **3,749 `tested`, 59 `timeout`, 468 `untested`**. Pest's reported **MSI is 89.06%**, using `(tested + timeout) / total`, or `3,808 / 4,276`. The completed `tested` share alone is **87.68%** (`3,749 / 4,276`); here the denominator still includes all mutations. In plugin v4.0.1, `tested` means the worker completed with a non-success exit. It is not independent proof that each such worker failed a semantic assertion. `untested` means the worker completed successfully and the mutation survived this run. The categories reconcile with the total, with no pending or uncovered remainder.

The fresh 468-entry survivor catalogue contains **458 retained IDs, 10 added IDs and 19 IDs absent from the prior catalogue**. All ten additions have unique printed-mutation predecessors in the two changed production files: nine entire diff contexts are identical, and one has identical changed lines with an updated neighboring guard. Those ten pairs were reviewed against the final source. The remaining nine absent old entries are no longer reported as `untested`; absence alone does not establish whether a worker was classified `tested` or `timeout`. The fresh catalogue, correspondence table and individual review overlays are archived separately from the historical 477-entry catalogue.''',
    'ru': '''### CI на окончательном коде

[Прогон 43857035628](https://github.com/componenta/di/actions/runs/43857035628), попытка 1, успешно завершён для `42b62afd9c6a57caa0db3916585e823ab6ebaafa`. Прошли все пять обязательных jobs. Необязательный benchmark исторического сравнения, запускаемый вручную, пропущен по условию workflow.

| CI job | Успешно | Пропущено | Assertions | Результат |
|---|---:|---:|---:|---|
| Linux / PHP 8.4 | 1 630 | 18 | 24 953 | Success |
| Linux / PHP 8.5 | 1 647 | 1 | 25 060 | Success |
| Windows / PHP 8.4 | 1 629 | 19 | 24 951 | Success |
| Windows / PHP 8.5 | 1 646 | 2 | 25 058 | Success |
| Coverage и mutation / PHP 8.4 | 1 630 | 18 | 24 953 | Success |

Все четыре платформенных jobs прошли полные настроенные проверки PHPStan на максимальном уровне и стиля; последняя показала 0 / 418 файлов, требующих изменений. Полные логи, metadata запуска/jobs и независимая сверка метрик находятся в архиве в `audit-round5/ci-final/`. Финальный коммит отчёта и доказательств меняет документацию и сохраняет проверенные деревья исходников и тестов.

**Покрытие.** Скачанный Clover artifact содержит **4498 / 4848 statements = 92,78%** и **441 / 558 методов = 79,03%** для всех 169 production-файлов. Суммы по файлам совпадают с проектными, список исходников — с проверенным коммитом. Pest выводит **92,7%**, поскольку его formatter отбрасывает остаток после первого десятичного знака. Это показатели statements и методов; artifact не доказывает покрытие ветвей или путей. Для artifact `14224202628` проверены SHA-256 из API, CRC файлов ZIP и точные байты извлечённого XML. Идентификаторы сохранены в [ci.json](evidence/2026-11-16-round5/ci.json), [Clover XML](evidence/2026-11-16-round5/coverage.xml.gz) сжат без потерь.

**Мутационный анализ.** Завершённый запуск создал **4276 мутаций в 115 файлах**: **3749 `tested`, 59 `timeout`, 468 `untested`**. **MSI Pest — 89,06%**, формула `(tested + timeout) / total`, то есть `3808 / 4276`. Доля завершённых результатов `tested` отдельно — **87,68%** (`3749 / 4276`); знаменатель здесь по-прежнему включает все мутации. В plugin v4.0.1 категория `tested` означает, что worker завершился с неуспешным exit status. Это не независимое доказательство семантического assertion failure для каждого worker. Категория `untested` означает успешное завершение worker: мутация пережила этот прогон. Сумма категорий совпадает с общим количеством, остатка pending или uncovered нет.

Свежий каталог из 468 survivors содержит **458 сохранившихся ID, 10 добавившихся ID и 19 отсутствующих ID из прежнего каталога**. Для всех десяти добавлений найден единственный предшествующий печатный diff мутации в двух изменённых production-файлах: девять полных diff context совпадают, у одного совпадают изменённые строки при обновлённом соседнем guard. Все десять пар проверены по окончательному коду. Ещё девять прежних записей больше не входят в `untested`; само отсутствие не устанавливает, получил worker категорию `tested` или `timeout`. Свежий каталог, таблица соответствий и индивидуальные уточнения сохранены отдельно от исторического каталога из 477 записей.'''
}

extra = {
    'en': '''Fresh review also narrowed several earlier static explanations. `Proxy` is final and readonly, so a witness based on a stateful derived `Proxy` cannot be valid; repeated `newInstance()` now retains only the documented, unexecuted native-argument/materialization hypothesis. A PHP class alias can have a name that cannot appear in an ordinary class declaration, so the invokable sentinel-string mutant is classified as an artificial literal edge rather than blanket equivalence. These are corrections to review reasoning, not newly reproduced library defects. The combined ledger exposes the corrected current explanation while preserving the original record explicitly as superseded.''',
    'ru': '''Свежая проверка также сузила несколько прежних статических объяснений. `Proxy` объявлен final и readonly, поэтому пример со stateful-наследником `Proxy` невозможен; для повторного `newInstance()` оставлена только явно незапущенная гипотеза о native materialization/coercion аргумента. PHP class alias может иметь имя, недопустимое в обычном объявлении класса, поэтому мутация sentinel-строки invokable классифицирована как искусственный literal edge, а не безусловная эквивалентность. Это исправления логики разбора, а не новые воспроизведённые дефекты библиотеки. Объединённый реестр содержит уточнённые текущие объяснения, а прежние записи сохраняет с явной пометкой superseded.'''
}
for lang, suffix in [('en', ''), ('ru', '.ru')]:
    p = base / f'report-template{suffix}.md'
    original = p.read_text()
    assert original.count('@@CI_SECTION@@') == 1
    shutil.copyfile(p, base / f'report-before-ci{suffix}.md')
    current = original.replace('@@CI_SECTION@@', sections[lang])
    if lang == 'en':
        old = 'The fresh full-CI mutation totals above are separate from those historical 477-entry classifications. Timeouts are reported separately from detected mutants; a passing MSI threshold does not turn every survivor into an equivalent program.'
        new = 'The fresh full-CI mutation totals above are separate from those historical 477-entry classifications. Timeouts are separate from the tool\'s completed `tested` results; a passing MSI threshold does not turn every survivor into an equivalent program.'
        current = current.replace(' No release, merge or architectural redesign is asserted by this audit.', '')
    else:
        old = 'Свежие полные показатели CI учитываются отдельно от исторического каталога из 477 записей. Timeout выделены отдельно от обнаруженных мутантов. Успешный порог MSI не доказывает эквивалентность каждого оставшегося survivor.'
        new = 'Свежие полные показатели CI учитываются отдельно от исторического каталога из 477 записей. Timeout выделены отдельно от завершённых результатов `tested` инструмента. Успешный порог MSI не доказывает эквивалентность каждого оставшегося survivor.'
        current = current.replace(' Релиз, merge или перепроектирование архитектуры этим аудитом не заявляются.', '')
    assert old in current
    current = current.replace(old, extra[lang] + '\n\n' + new)
    p.write_text(current)

p = base / 'evidence-readme-template.md'
s = p.read_text()
s = s.replace('All 477 prior catalogue diffs and individual classifications; eight focused exact executions are distinguished from 469 static-only entries', 'All 477 prior catalogue diffs and classifications, explicit current-reason corrections, and the final 468-entry correspondence/classification index; eight focused exact executions are distinguished from 469 static-only entries')
s = s.replace('Report templates and review notes preserve the reviewed narrative before the final CI section was filled. The delivered reports contain the completed CI result.', 'The `report-before-ci` snapshots match the first report review. Final report templates include the completed CI result and have a separate metric/narrative check.')
s = s.replace('## Intermediates excluded from final gate claims', '''## Fresh survivor correspondence and corrected reasoning

The final run has 468 survivors: 458 retained IDs, 10 added and 19 absent from the old catalogue. All retained printed diffs are unchanged. Each new ID has a unique printed-mutation predecessor in the changed source files: nine complete contexts match, while one preserves the changed lines with a changed neighboring guard. Ten pair-specific static reviews are in `ci-final/fresh-attribute-survivor-review.json` and `ci-final/fresh-core-survivor-review.json`. They do not establish new original-source defects or new runtime kills. Absence of the remaining nine old IDs from `untested` does not by itself distinguish `tested` from `timeout`.

The combined ledger's current `classification` and `reason` incorporate explicit correction overlays. Original per-agent detail and archive records retain their bytes and are marked historical/superseded where appropriate. In particular, `Proxy` cannot be subclassed because it is final; an ordinary invalid declaration name can still be a registered `class_alias`. Unsupported hypothetical derived-Proxy witnesses and blanket class-name equivalence claims are not part of the current conclusions. The final CI category `tested` is a worker's completed non-success outcome, not an independently checked semantic assertion failure for every mutant. MSI includes the separately reported 59 timeouts.

## Intermediates excluded from final gate claims''')
p.write_text(s)
print('Final EN/RU CI sections and evidence explanation written; original pre-CI report snapshots retained.')
