from pathlib import Path
import json
import subprocess

base = Path('/workspace/scratch/4d17f5340b2e')
repo = base / 'di'
out = base / 'audit-round5/gates'
results = []
for version in ['8.4.27', '8.5.12']:
    php = base / 'runtime' / ('php-' + version) / 'sapi/cli/php'
    for case in ['RuntimeBench', 'GeneratedVsReflectionBench', 'BuildPhasesBench', 'ParameterPlanBench', 'AttributeAvailabilityBench']:
        label = 'benchmark-smoke-' + version + '-' + case
        cmd = ['python', str(base / 'audit-round5/run_check.py'), '--repo', str(repo), '--out', str(out), label, '--',
               'env', 'COMPONENTA_DI_BENCH_AUTOLOAD=' + str(repo / 'vendor/autoload.php'),
               'COMPONENTA_DI_BENCH_SOURCE=' + str(repo / 'src'), 'DI_BENCH_ITERATIONS=10000',
               'DI_BUILD_ITERATIONS=1000', 'DI_BENCH_ROUNDS=3', str(php), '-n', '-d', 'memory_limit=1G']
        if version.startswith('8.5'):
            cmd += ['-d', 'opcache.enable_cli=1', '-d', 'opcache.jit=0']
        cmd += ['benchmarks/' + case + '.php']
        result = subprocess.run(cmd, cwd=repo, text=True, capture_output=True)
        record = json.loads((out / (label + '.json')).read_text())
        results.append({k: record.get(k) for k in ['label', 'head', 'exit_code', 'seconds', 'command', 'source_tests_unchanged', 'log_sha256']})
        print(json.dumps(results[-1]), flush=True)
        if result.returncode:
            print(result.stdout + result.stderr, flush=True)
            raise SystemExit(result.returncode)
(base / 'audit-round5/benchmark-smoke-summary.json').write_text(json.dumps({
    'classification': 'Fresh final-source harness smoke runs; no pre/post comparison, throughput SLA, or statistical regression claim.',
    'execution': 'The ten benchmark processes ran sequentially. Local PHP 8.4 uses no OPcache; PHP 8.5 enables built-in CLI OPcache with JIT off.',
    'runs': results,
}, indent=2) + '\n')
