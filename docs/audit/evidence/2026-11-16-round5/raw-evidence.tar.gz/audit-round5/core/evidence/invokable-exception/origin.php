<?php
declare(strict_types=1);
$root = realpath($argv[1]);
require $root . '/tests/bootstrap.php';
$origins = [];
foreach ([Componenta\DI\Container::class, Componenta\DI\Resolver\Entry\InvokableResolver::class, Componenta\DI\Resolver\Entry\FactoryResolver::class, Componenta\DI\Resolver\Entry\CompositeResolver::class, Componenta\DI\Tests\Support\ContainerBuilder::class] as $class) {
    $file = (new ReflectionClass($class))->getFileName();
    if ($file === false || !str_starts_with(realpath($file), $root . '/')) { throw new RuntimeException('Wrong class source: ' . $class); }
    $origins[$class] = ['file' => realpath($file), 'sha256' => hash_file('sha256', $file)];
}
foreach (['Componenta\\DI\\Internal\\normalize_env_name', 'Componenta\\DI\\Tests\\Support\\container'] as $function) {
    $file = (new ReflectionFunction($function))->getFileName();
    if ($file === false || !str_starts_with(realpath($file), $root . '/')) { throw new RuntimeException('Wrong function source: ' . $function); }
    $origins[$function] = ['file' => realpath($file), 'sha256' => hash_file('sha256', $file)];
}
echo json_encode(['php' => PHP_VERSION, 'binary' => PHP_BINARY, 'binary_sha256' => hash_file('sha256', PHP_BINARY), 'source_root' => $root, 'origins' => $origins], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES), "\n";
