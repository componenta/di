"""Synthetic subprocess protocol test; no PHP benchmark or throughput measurement."""
import contextlib,hashlib,io,json,pathlib,runpy,shutil,subprocess,sys,tempfile
from unittest.mock import patch
EV=pathlib.Path(__file__).resolve().parent
REPO=EV.parents[1]/'setup-gaps'
OLD=EV/'baseline-runner.py'
NEW=REPO/'docs/audit/reproductions/run-cycle-guard-benchmark.py'
SHA=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
VERSIONS={'/synthetic/php84a':'8.4.27','/synthetic/php84b':'8.4.26','/synthetic/php85':'8.5.12'}
CASES={'same_binary':['/synthetic/php84a','/synthetic/php84a'],'different_patch_same_minor':['/synthetic/php84a','/synthetic/php84b'],'unique_series':['/synthetic/php84a','/synthetic/php85']}
records=[]
with tempfile.TemporaryDirectory(prefix='di-cycle-driver-proof-') as temporary:
 temp=pathlib.Path(temporary);baseline=temp/'baseline';candidate=temp/'candidate';baseline.mkdir();candidate.mkdir()
 shutil.copytree(REPO/'src',baseline/'src');shutil.copytree(REPO/'src',candidate/'src')
 p=candidate/'src/Internal/CycleGuard.php';p.write_bytes(p.read_bytes()+b'\n// Synthetic source distinction; no PHP worker is executed.\n')
 for phase,driver in [('baseline',OLD),('fixed',NEW)]:
  for name,binaries in CASES.items():
   output=EV/(phase+'-'+name)
   assert not output.exists(),output
   args=[str(driver),'--baseline-source',str(baseline),'--candidate-source',str(candidate),'--vendor',str(REPO/'vendor'),'--output',str(output),'--rounds','1','--scale','1']
   for binary in binaries:args+=['--php',binary]
   version_queries=[];worker_commands=[];mkdir_calls=[];source_walks=[]
   actual_rglob=pathlib.Path.rglob;actual_mkdir=pathlib.Path.mkdir
   def query(command,**kwargs):
    assert command[1:]==['-n','-r','echo PHP_VERSION;'];version_queries.append(command);return VERSIONS[command[0]]+'\n'
   def worker(command,**kwargs):
    worker_commands.append(command);source=pathlib.Path(command[3]);worker_path=pathlib.Path(command[2]);sequence=len(worker_commands)
    value={'synthetic_subprocess':True,'binary':command[0],'sequence':sequence,'worker_sha256':SHA(worker_path),'loader_sha256':SHA(worker_path.with_name('source-loader.php')),'source_root':str(source),'provenance':{'cycle_guard_sha256':SHA(source/'src/Internal/CycleGuard.php'),'classes':{'SyntheticDeclaration':'not a loaded PHP class'},'functions':{'synthetic_function':'not an executed PHP function'}},'checks':{'synthetic_protocol':True},'measurements':{'synthetic_only':{'nanoseconds_per_operation':100+sequence}}}
    return subprocess.CompletedProcess(command,0,json.dumps(value)+'\n','')
   def rglob(path,*args,**kwargs):source_walks.append(str(path));return actual_rglob(path,*args,**kwargs)
   def mkdir(path,*args,**kwargs):mkdir_calls.append(str(path));return actual_mkdir(path,*args,**kwargs)
   stdout=io.StringIO();stderr=io.StringIO();exit_code=0
   with patch.object(sys,'argv',args),patch('subprocess.check_output',query),patch('subprocess.run',worker),patch('platform.platform',return_value='synthetic runner control proof'),patch.object(pathlib.Path,'rglob',rglob),patch.object(pathlib.Path,'mkdir',mkdir),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    try:runpy.run_path(str(driver),run_name='__main__')
    except SystemExit as failure:exit_code=failure.code
   outlog=EV/(phase+'-'+name+'.stdout.log');errlog=EV/(phase+'-'+name+'.stderr.log');outlog.write_text(stdout.getvalue());errlog.write_text(stderr.getvalue())
   record={'phase':phase,'case':name,'synthetic':True,'driver_sha256':SHA(driver),'argv':args,'versions':{p:VERSIONS[p] for p in binaries},'exit_code':exit_code,'version_queries':version_queries,'worker_count':len(worker_commands),'source_walk_count':len(source_walks),'output_mkdir_count':len(mkdir_calls),'output_created':output.exists(),'stdout':outlog.name,'stdout_sha256':SHA(outlog),'stderr':errlog.name,'stderr_sha256':SHA(errlog),'diagnostic':stderr.getvalue()}
   if output.exists():
    evidence=json.loads((output/'evidence.json').read_text());runs=evidence['runs'];raw=[r['stdout'] for r in runs]
    mismatches=[{'run':i,'file':pathlib.Path(r['stdout']).name,'recorded_sha256':r['stdout_sha256'],'actual_sha256':SHA(r['stdout'])} for i,r in enumerate(runs) if r['stdout_sha256']!=SHA(r['stdout'])]
    record.update({'recorded_worker_count':len(runs),'unique_raw_stdout_count':len(set(raw)),'overwritten_records':mismatches,'summary_process_samples':{v:{s:{'baseline':len(x['baseline_worker_ns']),'candidate':len(x['candidate_worker_ns'])} for s,x in summary.items()} for v,summary in evidence['summaries'].items()},'evidence_sha256':SHA(output/'evidence.json'),'raw_files':[{'path':f.relative_to(EV).as_posix(),'sha256':SHA(f)} for f in sorted(output.iterdir())]})
   duplicate=name!='unique_series'
   expected_safe=(exit_code==2 and not output.exists() and not worker_commands and not source_walks and not mkdir_calls) if duplicate else (exit_code==0 and record['unique_raw_stdout_count']==8 and record['overwritten_records']==[] and len(worker_commands)==8)
   record['safety_oracle_passed']=expected_safe
   if phase=='baseline' and duplicate:
    assert not expected_safe
    assert exit_code==0 and record['recorded_worker_count']==8 and record['unique_raw_stdout_count']==4 and len(record['overwritten_records'])==4
    if name=='same_binary':assert record['summary_process_samples']['8.4.27']['synthetic_only']=={'baseline':4,'candidate':4}
   else:assert expected_safe,record
   if phase=='fixed' and duplicate:
    for binary in binaries:assert binary in stderr.getvalue() and VERSIONS[binary] in stderr.getvalue()
   records.append(record)
   print(json.dumps({'phase':phase,'case':name,'exit':exit_code,'workers':len(worker_commands),'output_created':output.exists(),'oracle':expected_safe,'overwritten':len(record.get('overwritten_records',[]))}),flush=True)
# Native duplicate-input smokes run only PHP_VERSION queries; invalid source paths must never be inspected.
for version in ['8.4.27','8.5.12']:
 php='/workspace/scratch/4d17f5340b2e/runtime/php-'+version+'/sapi/cli/php';out=EV/('native-duplicate-'+version)
 args=[sys.executable,str(NEW),'--baseline-source','/source-must-not-be-read','--candidate-source','/source-must-not-be-read','--vendor',str(REPO/'vendor'),'--output',str(out),'--php',php,'--php',php]
 result=subprocess.run(args,text=True,capture_output=True);log=EV/('native-duplicate-'+version+'.log');log.write_text(result.stdout+result.stderr)
 assert result.returncode==2 and not out.exists() and 'one --php binary per major/minor series' in result.stderr and version in result.stderr
 records.append({'phase':'fixed','case':'native_duplicate_smoke','synthetic':False,'runtime_version':version,'runtime_sha256':SHA(php),'command':args,'exit_code':result.returncode,'output_created':out.exists(),'log':log.name,'log_sha256':SHA(log),'limits':'Only native PHP_VERSION queries executed, no benchmark worker/source traversal.'})
compile(NEW.read_bytes(),str(NEW),'exec')
patch_bytes=subprocess.check_output(['git','diff','--','docs/audit/reproductions/run-cycle-guard-benchmark.py','docs/audit/reproductions/OptimizationReproduction.md'],cwd=REPO)
(EV/'cycle-runner-input.patch').write_bytes(patch_bytes)
assert subprocess.run(['git','diff','--check'],cwd=REPO,capture_output=True).returncode==0
proof={'finding':'REPRO-RUNTIME-ID-1','title':'Duplicate PHP major/minor series overwrite CycleGuard raw logs','baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'scope':'Two tooling/documentation files only; src and PHP tests unchanged by this unit.','cause':'Worker filenames derive only from major/minor; repeated --php values in one series reuse paths. Statistics additionally group identical versions together.','fix':'Preflight every selected binary version before output creation/source hashing/timing; reject repeated major/minor series and identify both conflicting binary/version values.','files':{'docs/audit/reproductions/run-cycle-guard-benchmark.py':{'baseline_sha256':SHA(OLD),'fixed_sha256':SHA(NEW)},'docs/audit/reproductions/OptimizationReproduction.md':{'fixed_sha256':SHA(REPO/'docs/audit/reproductions/OptimizationReproduction.md')}},'patch':{'file':'cycle-runner-input.patch','sha256':SHA(EV/'cycle-runner-input.patch')},'harness':{'file':'driver-proof.py','sha256':SHA(__file__),'simulation':'Monkeypatched subprocess PHP_VERSION responses and worker JSON only. Actual driver loops, filesystem writes, hash verification and statistics executed against 169-file source copies with one synthetic CycleGuard comment distinction. No PHP worker ran and numeric values are synthetic; they are not benchmark measurements.'},'runs':records,'limits':['Historical measurements are not rerun or modified. The documented one-8.4/one-8.5 campaign has no duplicate-series collision.','The source loader, worker, timed bodies and aggregation formulas are unchanged.','Existing output directories remain allowed for the historical interface; documentation requires a fresh directory.','Synthetic unique-series control proves runner acceptance/record preservation, not DI runtime correctness or performance.'],'harness_history':[{'directory':'harness-attempts','excluded_from_semantic_proof':True,'reason':'Initial synthetic subprocess adapter also intercepted platform.platform uname lookup. Explicit synthetic platform metadata added before canonical run; no benchmark ran.'}],'checks':{'compile':True,'git_diff_check':True,'native_duplicate_version_queries_only':['8.4.27','8.5.12']}}
(EV/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('PROOF_SHA256 '+SHA(EV/'proof.json'));print('PATCH_SHA256 '+SHA(EV/'cycle-runner-input.patch'))
