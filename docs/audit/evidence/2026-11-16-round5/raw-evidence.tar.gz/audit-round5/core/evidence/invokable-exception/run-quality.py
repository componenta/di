import sys,pathlib,subprocess,json,hashlib,xml.etree.ElementTree as ET
kind,version=sys.argv[1:]
evidence=pathlib.Path(__file__).resolve().parent
root=evidence.parents[1]/'repo'
php=pathlib.Path('/workspace/scratch/4d17f5340b2e/runtime')/('php-'+version)/'sapi/cli/php'
files=['tests/Contract/InvokableExceptionContractTest.php','tests/Contract/FactoryFormsContractTest.php','tests/Contract/FactoryValidationContractTest.php','tests/Contract/FactoryRegistrationValidationContractTest.php','tests/Contract/RuntimeResolutionContractTest.php','tests/Contract/ContainerFactoryContractTest.php','tests/Contract/RuntimeRegistrationExceptionContractTest.php','tests/V5/ExceptionContractTest.php']
commands={
'focused':[str(php),'-n','vendor/bin/pest',*files,'--no-coverage','--do-not-cache-result','--colors=never','--compact','--log-junit='+str(evidence/('focused-'+version+'.xml'))],
'phpstan':[str(php),'-n','vendor/bin/phpstan','analyse','--no-progress','--memory-limit=512M','src/Resolver/Entry/InvokableResolver.php','tests/Contract/InvokableExceptionContractTest.php'],
'style':[str(php),'-n','vendor/bin/php-cs-fixer','fix','--config=.php-cs-fixer.dist.php','--dry-run','--diff','--using-cache=no','--path-mode=intersection','src/Resolver/Entry/InvokableResolver.php','tests/Contract/InvokableExceptionContractTest.php']}
command=commands[kind];p=subprocess.run(command,cwd=root,text=True,capture_output=True)
log=evidence/(kind+'-'+version+'.log');log.write_text(p.stdout+p.stderr)
record={'kind':kind,'version':version,'cwd':str(root),'command':command,'exit_code':p.returncode,'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scope':files if kind=='focused' else ['src/Resolver/Entry/InvokableResolver.php','tests/Contract/InvokableExceptionContractTest.php']}
if kind=='focused':
 t=ET.parse(evidence/(kind+'-'+version+'.xml'));record['junit']=t.getroot().find('testsuite').attrib
(evidence/(kind+'-'+version+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print((p.stdout+p.stderr)[-4000:])
