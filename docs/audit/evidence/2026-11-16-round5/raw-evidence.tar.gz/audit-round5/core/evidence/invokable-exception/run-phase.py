import sys, pathlib, subprocess, json, hashlib, xml.etree.ElementTree as ET
phase, version = sys.argv[1:]
root = pathlib.Path(__file__).resolve().parents[2] / 'repo'
evidence = pathlib.Path(__file__).resolve().parent
php = pathlib.Path('/workspace/scratch/4d17f5340b2e/runtime') / ('php-' + version) / 'sapi/cli/php'
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
origin_cmd = [str(php), '-n', str(evidence/'origin.php'), str(root)]
origin = subprocess.run(origin_cmd, cwd=root, text=True, capture_output=True)
(evidence/(phase+'-'+version+'-origin.json')).write_text(origin.stdout)
if origin.returncode: raise RuntimeError(origin.stdout+origin.stderr)
command = [str(php), '-n', 'vendor/bin/pest', 'tests/Contract/InvokableExceptionContractTest.php', '--no-coverage', '--do-not-cache-result', '--colors=never', '--compact', '--log-junit='+str(evidence/(phase+'-'+version+'.xml'))]
r = subprocess.run(command, cwd=root, text=True, capture_output=True)
log = evidence / (phase+'-'+version+'.log'); log.write_text(r.stdout+r.stderr)
xmlpath=evidence/(phase+'-'+version+'.xml')
tree=ET.parse(xmlpath)
failed=[c.attrib.get('name') for c in tree.iter('testcase') if c.find('failure') is not None or c.find('error') is not None]
record={'phase':phase,'version':version,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'cwd':str(root),'command':command,'exit_code':r.returncode,'source_sha256':sha(root/'src/Resolver/Entry/InvokableResolver.php'),'test_sha256':sha(root/'tests/Contract/InvokableExceptionContractTest.php'),'runtime_sha256':sha(php),'junit':tree.getroot().find('testsuite').attrib,'failed_tests':failed,'log':log.name,'log_sha256':sha(log),'junit_file':xmlpath.name,'junit_sha256':sha(xmlpath),'origins':json.loads(origin.stdout)}
(evidence/(phase+'-'+version+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='origins'},ensure_ascii=False,indent=2))
print(r.stdout[-1800:])
