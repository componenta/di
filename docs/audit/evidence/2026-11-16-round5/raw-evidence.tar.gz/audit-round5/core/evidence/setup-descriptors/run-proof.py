import pathlib, subprocess, json, hashlib, xml.etree.ElementTree as ET, time
EV=pathlib.Path(__file__).resolve().parent
ROOT=EV.parents[1]/'setup-gaps'
SHA=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
NEW='tests/Contract/SetUpDescriptorFallbackContractTest.php'
OLD=['tests/Contract/SetUpEnvironmentContractTest.php','tests/Contract/SetUpValueUnwrapperContractTest.php','tests/V5/BuilderAndSetUpContractTest.php']
SOURCES=['src/Resolver/Entry/SetUp/EnvUnwrapper.php','src/Resolver/Entry/SetUp/ConfigUnwrapper.php']
BASE={p:(ROOT/p).read_bytes() for p in SOURCES}
CATALOG=json.loads((EV.parents[1]/'mutation-survivors.json').read_text())
MUTANTS=[('2d3da5b42f6aaf02',SOURCES[0],'if ($env->default !== DefaultValue::None)', 'if ($env->default === DefaultValue::None)'),('989628a219306c29',SOURCES[1],'$config->get($value->path ?? $key, $value->default)', '$config->get($key, $value->default)')]
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert HEAD=='406c8ea563d2fa304434a695c4b6b43f1f269e6f'
assert subprocess.check_output(['git','diff','--','src'],cwd=ROOT)==b''
runs=[]

def run(phase,version,files,expected,mutant=None):
 php=pathlib.Path('/workspace/scratch/4d17f5340b2e/runtime')/('php-'+version)/'sapi/cli/php'
 origin_cmd=[str(php),'-n',str(EV/'origin.php'),str(ROOT)]
 origin=subprocess.run(origin_cmd,cwd=ROOT,capture_output=True,text=True)
 assert origin.returncode==0,origin.stdout+origin.stderr
 origin_value=json.loads(origin.stdout)
 xml=EV/(phase+'-'+version+'.xml')
 cmd=[str(php),'-n','vendor/bin/pest',*files,'--no-coverage','--do-not-cache-result','--colors=never','--compact','--log-junit='+str(xml)]
 started=time.time(); r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);elapsed=time.time()-started
 log=EV/(phase+'-'+version+'.log'); log.write_text(r.stdout+r.stderr)
 cases=list(ET.parse(xml).getroot().iter('testcase'))
 failed=[{'name':c.attrib['name'],'type':('failure' if c.find('failure') is not None else 'error'),'message':(c.find('failure') if c.find('failure') is not None else c.find('error')).attrib.get('message','')} for c in cases if c.find('failure') is not None or c.find('error') is not None]
 record={'phase':phase,'mutant_id':mutant,'version':version,'baseline_commit':HEAD,'cwd':str(ROOT),'command':cmd,'exit_code':r.returncode,'elapsed_seconds':elapsed,'scope':files,'counts':{'tests':len(cases),'passed':sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases),'failed':len(failed),'skipped':sum(c.find('skipped') is not None for c in cases),'assertions':sum(int(c.attrib.get('assertions',0)) for c in cases)},'failed_tests':failed,'source_sha256':{p:SHA(ROOT/p) for p in SOURCES},'test_sha256':SHA(ROOT/NEW),'runtime_sha256':SHA(php),'origins_command':origin_cmd,'origins':origin_value,'log':log.name,'log_sha256':SHA(log),'junit':xml.name,'junit_sha256':SHA(xml)}
 (EV/(phase+'-'+version+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');runs.append(record)
 print(json.dumps({'phase':phase,'version':version,'exit':r.returncode,'counts':record['counts']},ensure_ascii=False),flush=True)
 if r.returncode != expected:
  print(r.stdout+r.stderr,flush=True);raise RuntimeError('Unexpected phase outcome')

try:
 for version in ['8.4.27','8.5.12']:
  run('baseline-old',version,OLD,0)
  run('baseline-new',version,[NEW],0)
 for mid,path,before,after in MUTANTS:
  original=BASE[path].decode();assert original.count(before)==1
  (ROOT/path).write_text(original.replace(before,after))
  for version in ['8.4.27','8.5.12']:
   run('mutant-'+mid+'-old',version,OLD,0,mid)
   run('mutant-'+mid+'-new',version,[NEW],2 if mid == '2d3da5b42f6aaf02' else 1,mid)
  (ROOT/path).write_bytes(BASE[path])
 for version in ['8.4.27','8.5.12']:
  run('restored-combined',version,[*OLD,NEW],0)
finally:
 for path,data in BASE.items():(ROOT/path).write_bytes(data)
assert subprocess.check_output(['git','diff','--','src'],cwd=ROOT)==b''
patch=subprocess.run(['git','diff','--no-index','--','/dev/null',NEW],cwd=ROOT,capture_output=True).stdout
(EV/'setup-descriptors.patch').write_bytes(patch)
installed=ROOT/'vendor/composer/installed.json'; packages=json.loads(installed.read_text())['packages']
proof={'title':'Public SetUp Env fallback and explicit Config descriptor regression witnesses','baseline_commit':HEAD,'production_change':None,'new_test':{'path':NEW,'sha256':SHA(ROOT/NEW),'cases':2,'baseline_assertions':5},'related_old_scope':OLD,'scope_note':'OLD denotes these three related files, not the full repository suite. Each catalog mutation is applied separately to the otherwise unmodified baseline. New tests prove regression detection, not a production bug.','sources':{p:{'baseline_sha256':SHA(ROOT/p),'final_sha256':SHA(ROOT/p)} for p in SOURCES},'catalog_source':{k:v for k,v in CATALOG.items() if k!='entries'},'mutants':[{**{k:v for k,v in next(e for e in CATALOG['entries'] if e['id']==mid).items() if k not in ['classification','reason','public_contract_witness']},'replacement_before':before,'replacement_after':after} for mid,path,before,after in MUTANTS],'runs':runs,'quality':[json.loads((EV/(name+'.json')).read_text()) for name in ['phpstan','style']],'patch':{'file':'setup-descriptors.patch','sha256':SHA(EV/'setup-descriptors.patch')},'dependencies':{'installed_json_sha256':SHA(installed),'packages':[{'name':x['name'],'version':x['version'],'source_reference':x.get('source',{}).get('reference'),'dist_reference':x.get('dist',{}).get('reference')} for x in packages]},'limits':['Targeted PHPStan and one-file style checks, not full configured gates.','No coverage or full mutation suite is run by this witness.','Old suite green shows a gap in the explicitly listed three-file scope; the historical full-CI survivor catalog is separate evidence.'],'source_restored_verified':True,'harness_history':[{'directory':'harness-attempts','excluded_from_semantic_proof':True,'reason':'Initial fixture used a dotted string key for nested Config data; Config specifies literal string keys and requires ConfigPath for nested lookup. Corrected fixture uses ConfigPath. Initial baseline failed for fixture error, not a production defect or semantic RED.'}]}
(EV/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print('PROOF_SHA256 '+SHA(EV/'proof.json'))
print('PATCH_SHA256 '+SHA(EV/'setup-descriptors.patch'))
