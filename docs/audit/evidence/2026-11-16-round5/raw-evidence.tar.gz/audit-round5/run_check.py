#!/usr/bin/env python3
"""Run a check with immutable source/test fingerprints and a complete log."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--out', required=True)
parser.add_argument('label')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
repo = Path(args.repo).resolve()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    raise SystemExit('A command is required')

def fingerprint():
    files = {}
    for subtree in ['src', 'tests']:
        for path in sorted((repo / subtree).rglob('*')):
            if path.is_file():
                files[str(path.relative_to(repo))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'files': files, 'sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()}

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=repo, text=True).strip()

before = fingerprint()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
log = out / (args.label + '.log')
record = {'label': args.label, 'repository': str(repo), 'head': git('rev-parse', 'HEAD'),
          'status_before': git('status', '--porcelain'), 'command': command,
          'started_utc': started, 'before': before}
with log.open('wb') as stream:
    process = subprocess.run(command, cwd=repo, env=os.environ.copy(), stdout=stream, stderr=subprocess.STDOUT)
after = fingerprint()
record.update(exit_code=process.returncode, seconds=time.monotonic() - start,
              ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=after,
              source_tests_unchanged=before == after, status_after=git('status', '--porcelain'),
              log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out / (args.label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['label', 'head', 'exit_code', 'seconds', 'source_tests_unchanged', 'log', 'log_sha256']}), flush=True)
print(log.read_text(errors='replace')[-3500:], flush=True)
raise SystemExit(process.returncode if before == after else 125)
