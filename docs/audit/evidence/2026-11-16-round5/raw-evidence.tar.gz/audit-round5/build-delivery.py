from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

base = Path('/workspace/scratch/4d17f5340b2e')
audit = base / 'audit-round5'
repo = base / 'di'
dest = repo / 'docs/audit/evidence/2026-11-16-round5'
dest.mkdir(parents=True, exist_ok=True)
read = lambda name: json.loads((audit / name).read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = read('final-repository-identity.json')
ci = read('ci-final/final-ci-summary.json')
assert ci['run']['head_sha'] == identity['head'] == '42b62afd9c6a57caa0db3916585e823ab6ebaafa'
assert ci['all_five_required_jobs_success']
assert ci['run']['conclusion'] == 'success'
assert (audit / 'ci-final/report-ci-review.json').is_file()
assert not subprocess.check_output(['git', 'diff', '--', 'src', 'tests'], cwd=repo, text=True)

shutil.copyfile(audit / 'combined-scope.json', dest / 'scope.json')
shutil.copyfile(audit / 'combined-survivors.json', dest / 'survivors.json')
shutil.copyfile(audit / 'ci-final/final-ci-summary.json', dest / 'ci.json')
coverage = audit / 'ci-final/coverage.xml'
(dest / 'coverage.xml.gz').write_bytes(gzip.compress(coverage.read_bytes(), mtime=0))

selected = []
top_names = [
    'repository-inventory.json', 'repository-integrity.json', 'historical-d1-integrity.json',
    'root-review-ledger.json', 'runtime-dependencies.json', 'final-repository-identity.json',
    'junit-comparison.json', 'benchmark-smoke-summary.json', 'tooling-main-verification.json',
    'report-review.json', 'run_check.py', 'run-benchmark-smoke.py', 'merge-review-records.py',
    'report-template.md', 'report-template.ru.md', 'report-before-ci.md', 'report-before-ci.ru.md',
    'apply-final-survivor-overlays.py', 'finalize-report-content.py', 'build-delivery.py', 'validate-delivery.py',
]
for name in top_names:
    p = audit / name
    assert p.is_file(), p
    selected.append((p, 'audit-round5/' + name))
for p in sorted(audit.glob('*-publish.json')):
    if p.name != 'round5-report-publish.json':
        selected.append((p, 'audit-round5/' + p.name))
for directory in ['gates', 'ci-final', 'ci-intermediate', 'parameters/evidence', 'core/evidence']:
    for p in sorted((audit / directory).rglob('*')):
        if p.is_file():
            assert not p.is_symlink(), p
            selected.append((p, 'audit-round5/' + p.relative_to(audit).as_posix()))
for directory in ['parameters', 'core', 'attributes']:
    for p in sorted((audit / directory).iterdir()):
        if p.is_file() and p.suffix in ['.json', '.md', '.patch']:
            selected.append((p, 'audit-round5/' + p.relative_to(audit).as_posix()))
for p in sorted((base / 'runtime').iterdir()):
    if p.is_file() and (p.suffix == '.json' or p.name.endswith('-build.log')):
        selected.append((p, 'runtime/' + p.name))
patch = subprocess.check_output(['git', 'diff', '406c8ea563d2fa304434a695c4b6b43f1f269e6f..' + identity['head']], cwd=repo)
(audit / 'delivered-code-and-tooling.patch').write_bytes(patch)
selected.append((audit / 'delivered-code-and-tooling.patch', 'audit-round5/delivered-code-and-tooling.patch'))
assert len(selected) == len({name for _, name in selected})
members = []
archive = dest / 'raw-evidence.tar.gz'
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for path, name in sorted(selected, key=lambda x: x[1]):
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
                members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for record in members:
        member = tar.getmember(record['path'])
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert sha(tar.extractfile(member).read()) == record['sha256']

gates = []
for p in sorted((audit / 'gates').glob('*.json')):
    record = json.loads(p.read_text())
    if 'command' not in record:
        continue
    log = Path(record['log'])
    assert sha(log.read_bytes()) == record['log_sha256'], p
    gates.append({k: record.get(k) for k in ['label', 'head', 'command', 'started_utc', 'seconds', 'exit_code',
                                           'source_tests_unchanged', 'log_sha256']}
                 | {'source_tests_sha256_before': record['before']['sha256'],
                    'source_tests_sha256_after': record['after']['sha256'],
                    'archive_record': 'audit-round5/gates/' + p.name,
                    'archive_log': 'audit-round5/gates/' + log.name})
for label in ['final-php84', 'final-php85', 'final-phpstan', 'final-style', 'final-composer-validate']:
    gate = next(x for x in gates if x['label'] == label)
    assert gate['exit_code'] == 0 and gate['source_tests_unchanged']
    assert gate['source_tests_sha256_after'] == identity['source_tests_sha256']
platform = json.loads((audit / 'gates/platform-php85.log').read_text())
assert platform['passed_cases'] == 2 and platform['total_cases'] == 10
verification = {
    'schema_version': 1, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseline': '406c8ea563d2fa304434a695c4b6b43f1f269e6f',
    'implementation_and_tooling_head': identity['head'],
    'identity': {k: v for k, v in identity.items() if k != 'paths'},
    'findings': [
        {'id': 'INV-EX-1', 'kind': 'library-correctness', 'commit': '5067bf78d3b949531b807f572d000319e7e14c7e',
         'canonical_proof': 'audit-round5/core/evidence/invokable-exception/proof.json'},
        {'id': 'PROXY-CTOR-1', 'kind': 'library-correctness', 'commit': 'ce0c0a6414d649eb86bf099cc88f2559b63baa1e',
         'fixture_correction_commit': 'eefedd038090e686c06bca44f1dfa4e496af4280',
         'canonical_proof': 'audit-round5/attributes/nonpublic-proxy-proof-final.json'},
        {'id': 'REPRO-RUNTIME-ID-1', 'kind': 'audit-tooling-integrity', 'commit': identity['head'],
         'canonical_proof': 'audit-round5/core/evidence/cycle-runner-input/proof.json'},
    ],
    'tests': {'runtime_cases': 1648, 'added_cases': 28, 'added_assertions_per_runtime': 179,
              'removed_cases': 0, 'existing_skip_changes': 0, 'existing_cases_with_added_assertions': 4,
              'local_php84': {'version': '8.4.27', 'passed': 1629, 'skipped': 19, 'assertions': 24951},
              'local_php85': {'version': '8.5.12', 'passed': 1646, 'skipped': 2, 'assertions': 25058}},
    'local_gates': gates,
    'ci': ci,
    'native_platform_probe': platform,
    'benchmark_smoke': read('benchmark-smoke-summary.json'),
    'dependency_audit': {'installed_package_count': 101, 'result': json.loads((audit / 'gates/composer-audit.log').read_text()),
                         'gate': 'composer-audit', 'dependencies': 'audit-round5/runtime-dependencies.json'},
    'prior_mutation_review': {'catalogue_entries': 477, 'exact_executions': 8, 'exact_killed': 7,
                              'finite_green': 1, 'static_only': 469, 'additional_synthetic_owner_clone': 1},
    'fresh_survivor_review': {'catalogue_entries': 468, 'retained_ids_with_unchanged_diff': 458,
                              'added_ids': 10, 'absent_old_ids': 19, 'reviewed_predecessor_pairs': 10,
                              'entire_context_equal_pairs': 9, 'changed_lines_equal_context_changed_pairs': 1,
                              'new_runtime_witnesses_from_pair_review': 0,
                              'corrected_current_reasons': 'survivors.json top-level entries and fresh_full_ci',
                              'historical_reason_policy': 'Original detail and proof files are preserved, explicitly superseded where corrected.'},
    'review_records': {'file_scope': 'scope.json', 'prior_survivors': 'survivors.json',
                       'independent_changes': 'audit-round5/parameters/independent-change-review.json',
                       'report_review': 'audit-round5/report-review.json',
                       'final_report_ci_review': 'audit-round5/ci-final/report-ci-review.json',
                       'independent_ci_metrics': 'audit-round5/ci-final/root-independent-ci-review.json',
                       'final_core_survivors': 'audit-round5/ci-final/fresh-core-survivor-review.json',
                       'final_attribute_survivors': 'audit-round5/ci-final/fresh-attribute-survivor-review.json'},
    'excluded_or_intermediate': [
        {'record': 'audit-round5/gates/proxy-fixture-phpstan-red.json',
         'reason': 'Source/test fingerprint changed during the command. Not an accepted RED or GREEN gate.'},
        {'record': 'audit-round5/gates/attribute-gaps-style.json',
         'reason': 'CLI invocation omitted explicit config for multiple paths; corrected invocation and final full style pass are recorded separately.'},
        {'record': 'audit-round5/attributes/nonpublic-proxy-proof-intermediate.json',
         'reason': 'Original trait fixture failed full-scope PHPStan in CI. Final fixture and repeated exact-byte proof supersede this record.'},
        {'record': 'audit-round5/core/evidence/setup-descriptors/proof.json#harness_history',
         'reason': 'Initial dotted-string Config fixture was a harness error, not semantic RED. Canonical ConfigPath phases are separate.'},
    ],
    'limits': [
        'Managed deep-security coordinator unavailable; manual source/trust-boundary review and Composer audit were performed.',
        'Historical file review methods and fresh runtime proofs are separate.',
        'B2 and large cold alias graph optimization remain conditional architecture directions; no measured application speedup is claimed.',
        'E1 standalone native scope/identity probe still fails 8 of 10 on the recorded released PHP 8.5.12; package floor remains ^8.4.',
        'The raw archive retains original absolute workspace paths as provenance, not as portable executable paths.',
    ],
}
(dest / 'verification.json').write_text(json.dumps(verification, indent=2, ensure_ascii=False) + '\n')
manifest = {
    'schema_version': 1, 'implementation_head': identity['head'], 'archive_members': members,
    'files': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
              for p in sorted(dest.iterdir()) if p.is_file() and p.name not in ['manifest.json', 'README.md']],
    'verification': 'Archive member count, paths and SHA256 verified after compression; coverage gzip round-tripped.',
}
assert gzip.decompress((dest / 'coverage.xml.gz').read_bytes()) == coverage.read_bytes()
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'directory': str(dest), 'archive_members': len(members), 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': sha(archive.read_bytes()), 'files': len(manifest['files'])}, indent=2))
