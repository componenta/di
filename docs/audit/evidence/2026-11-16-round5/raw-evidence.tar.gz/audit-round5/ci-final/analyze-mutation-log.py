#!/usr/bin/env python3
"""Extract completed Actions mutation evidence; never launches tests or mutations."""
from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal, ROUND_HALF_UP
import gzip
import hashlib
import json
from pathlib import Path
import re

ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
STAMP = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z ?')
HEADER = re.compile(r'UNTESTED\s+(src/.*?)\s+>\s+Line (\d+): (.*?) - ID: ([0-9a-f]+)')


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse(path: Path) -> dict:
    saved = path.read_bytes()
    raw = gzip.decompress(saved) if path.suffix == '.gz' else saved
    text = raw.decode('utf-8')
    raw_lines = text.splitlines()
    lines = [ANSI.sub('', line) for line in raw_lines]
    created = [(i, re.search(r'(\d+) Mutations for (\d+) Files created', line))
               for i, line in enumerate(lines) if 'Mutations for ' in line]
    assert created and created[-1][1], 'No completed mutation generation summary'
    created_index, created_match = created[-1]
    total, files = map(int, created_match.groups())
    summaries = [(i, line) for i, line in enumerate(lines) if 'Mutations:' in line]
    assert summaries, 'No completed mutation category summary'
    summary_index, summary = summaries[-1]
    counts = {key: int(value) for value, key in re.findall(
        r'(\d+)\s+(untested|timeout|tested|uncovered|pending)\b', summary)}
    assert counts and sum(counts.values()) == total, (counts, total)
    for category in ('tested', 'timeout', 'untested', 'uncovered', 'pending'):
        counts.setdefault(category, 0)
    scores = [(i, re.search(r'Score:\s+([\d.]+)%', line))
              for i, line in enumerate(lines) if 'Score:' in line]
    assert scores and scores[-1][1], 'No completed mutation score'
    score_index, score_match = scores[-1]
    score = score_match.group(1)
    msi = Decimal(counts['tested'] + counts['timeout']) / Decimal(total) * 100
    tested_share = Decimal(counts['tested']) / Decimal(total) * 100
    rounded = str(msi.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
    assert Decimal(rounded) == Decimal(score), (rounded, score)
    starts = [(i, match) for i, line in enumerate(lines)
              if (match := HEADER.search(line))]
    survivors = []
    for position, (start, match) in enumerate(starts):
        end = starts[position + 1][0] if position + 1 < len(starts) else summary_index
        body = [STAMP.sub('', line) for line in lines[start + 1:end]]
        while body and (not body[-1].strip() or re.fullmatch(r'\s*-{10,}\s*', body[-1])):
            body.pop()
        while body and not body[0].strip():
            body.pop(0)
        survivors.append({
            'id': match.group(4), 'file': match.group(1).strip(),
            'line': int(match.group(2)), 'mutator': match.group(3),
            'raw_log_first_line': start + 1, 'raw_log_last_line': end,
            'diff_context': '\n'.join(body),
        })
    ids = [item['id'] for item in survivors]
    assert len(ids) == len(set(ids)) == counts['untested'], (len(ids), len(set(ids)), counts)
    return {
        'input': {'path': path.name, 'original_path': str(path), 'saved_bytes': len(saved), 'saved_sha256': digest(saved),
                  'decoded_raw_bytes': len(raw), 'decoded_raw_sha256': digest(raw)},
        'total': total, 'files_mutated': files, 'categories': counts,
        'reported_msi_percent': score, 'calculated_msi_percent': str(msi),
        'calculated_msi_rounded_percent': rounded,
        'completed_tested_over_all_percent': str(tested_share),
        'evidence_lines': [
            {'line': created_index + 1, 'text': lines[created_index]},
            {'line': summary_index + 1, 'text': summary},
            {'line': score_index + 1, 'text': lines[score_index]},
        ],
        'survivors': survivors,
    }


def save(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main() -> None:
    cli = argparse.ArgumentParser()
    cli.add_argument('fresh', type=Path)
    cli.add_argument('previous', type=Path)
    cli.add_argument('--output-dir', type=Path, required=True)
    args = cli.parse_args()
    fresh, previous = parse(args.fresh), parse(args.previous)
    assert len(previous['survivors']) == 477, 'Wrong comparison catalogue'
    fresh_by_id = {item['id']: item for item in fresh['survivors']}
    old_by_id = {item['id']: item for item in previous['survivors']}
    new_ids, old_ids = set(fresh_by_id), set(old_by_id)
    retained, added, removed = sorted(new_ids & old_ids), sorted(new_ids - old_ids), sorted(old_ids - new_ids)
    same_id_diff_changes = [item for item in retained if
                           fresh_by_id[item]['diff_context'] != old_by_id[item]['diff_context']]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    save(args.output_dir / 'fresh-survivors.json', {
        'schema_version': 1, 'head_sha': '42b62afd9c6a57caa0db3916585e823ab6ebaafa',
        'run_id': 43857035628, 'job_id': 133263982873,
        'source_log': fresh['input'], 'count': len(fresh['survivors']),
        'ids_unique': True, 'diff_encoding': 'ANSI and Actions timestamp prefixes removed; PHP code whitespace preserved',
        'survivors': fresh['survivors'],
    })
    save(args.output_dir / 'survivor-delta.json', {
        'schema_version': 1,
        'previous': {'head_sha': '299ee93f6be6d91e3a4fc1372389f1fff953d61b',
                     'run_id': 43774753909, 'job_id': 132998417946,
                     'repository_log_path': 'docs/audit/evidence/2026-11-16-propertyless-lazy/coverage-mutation-job-132998417946.log.gz',
                     'count': len(old_ids), 'input': previous['input']},
        'fresh': {'head_sha': '42b62afd9c6a57caa0db3916585e823ab6ebaafa',
                  'run_id': 43857035628, 'job_id': 133263982873,
                  'count': len(new_ids), 'input': fresh['input']},
        'retained_count': len(retained), 'added_count': len(added), 'removed_count': len(removed),
        'retained_ids': retained, 'added_ids': added, 'removed_ids': removed,
        'same_id_diff_context_changed': same_id_diff_changes,
        'added_entries': [fresh_by_id[item] for item in added],
        'removed_entries': [old_by_id[item] for item in removed],
        'per_file': {
            'previous': dict(sorted(Counter(item['file'] for item in previous['survivors']).items())),
            'fresh': dict(sorted(Counter(item['file'] for item in fresh['survivors']).items())),
        },
        'limits': [
            'This is an exact identifier catalogue comparison, not a count of newly fixed bugs.',
            'Source edits, generated mutation identity, and timeout variation can affect presence in UNTESTED.',
            'An added survivor requires a public-contract oracle before it is treated as a bug or meaningful test gap.',
            'Raw complete job logs remain the authoritative source for all extracted diff contexts.',
        ],
    })
    fresh.pop('survivors')
    save(args.output_dir / 'mutation-metrics.json', fresh)
    print(json.dumps({'counts': fresh['categories'], 'total': fresh['total'],
                      'msi': fresh['reported_msi_percent'],
                      'tested_over_total_percent': fresh['completed_tested_over_all_percent'],
                      'delta': {'retained': len(retained), 'added': len(added), 'removed': len(removed)}}, indent=2))


if __name__ == '__main__':
    main()
