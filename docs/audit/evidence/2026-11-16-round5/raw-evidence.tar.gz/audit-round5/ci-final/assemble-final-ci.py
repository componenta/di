#!/usr/bin/env python3
"""Assemble immutable-head CI evidence from saved responses, logs, and artifacts."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/4d17f5340b2e/di')
HEAD = '42b62afd9c6a57caa0db3916585e823ab6ebaafa'
RUN_ID = 43857035628
COVERAGE_JOB = 133263982873
REQUIRED = {
    133263982869: 'Windows PHP 8.5', 133263982873: 'Coverage PHP 8.4',
    133263982891: 'Windows PHP 8.4', 133263982990: 'PHP 8.5', 133263983051: 'PHP 8.4',
}
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')


def read(name: str):
    return json.loads((HERE / name).read_text())


def record(name: str) -> dict:
    raw = (HERE / name).read_bytes()
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main() -> None:
    raw_run = read('run-metadata-final.json')
    jobs = read('jobs-metadata-final.json')['jobs']
    assert raw_run['id'] == RUN_ID and raw_run['head_sha'] == HEAD and raw_run['run_attempt'] == 1
    assert raw_run['status'] == 'completed' and raw_run['conclusion'] == 'success'
    by_id = {job['id']: job for job in jobs}
    assert len(by_id) == len(jobs) and set(REQUIRED).issubset(by_id)
    run = {key: raw_run.get(key) for key in (
        'id', 'name', 'head_branch', 'head_sha', 'event', 'status', 'conclusion', 'run_number',
        'run_attempt', 'path', 'html_url', 'created_at', 'run_started_at', 'updated_at')}
    required_jobs = []
    texts = {}
    for job_id, name in REQUIRED.items():
        job = by_id[job_id]
        assert job['name'] == name and job['run_id'] == RUN_ID
        assert job['head_sha'] == HEAD and job['run_attempt'] == 1
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        path = f'job-{job_id}.log'
        text = (HERE / path).read_text()
        assert HEAD in text, f'Checkout identity absent in log {path}'
        texts[job_id] = ANSI.sub('', text)
        required_jobs.append({
            **{key: job.get(key) for key in ('id', 'name', 'run_id', 'run_attempt', 'head_sha',
                                           'status', 'conclusion', 'started_at', 'completed_at', 'html_url')},
            'log': record(path), 'checkout_head_present_in_log': True,
        })
    coverage = read('coverage-metrics.json')
    mutation = read('mutation-metrics.json')
    delta = read('survivor-delta.json')
    relocations = read('survivor-relocations.json')
    survivors = read('fresh-survivors.json')
    coverage_log = texts[COVERAGE_JOB]
    coverage_php = re.search(r'(?:Found|Installed|Updated to) PHP (\d+\.\d+\.\d+)', coverage_log)
    assert coverage_php
    plugin_match = re.search(r'Installing pestphp/pest-plugin-mutate \(([^)]+)\)', coverage_log)
    pest_match = re.search(r'Installing pestphp/pest \(([^)]+)\)', coverage_log)
    assert plugin_match and pest_match, 'Need actual current CI dependency versions'
    installed = json.loads((REPO / 'vendor/composer/installed.json').read_text())
    plugin = next(item for item in installed['packages'] if item['name'] == 'pestphp/pest-plugin-mutate')
    assert plugin['version'] == plugin_match.group(1)
    assert coverage['console']['pest_package_version_local'] == pest_match.group(1)
    plugin_base = REPO / 'vendor/pestphp/pest-plugin-mutate'
    plugin_sources = []
    for relative in ('src/Repositories/MutationRepository.php', 'src/MutationTestCollection.php',
                     'src/MutationTest.php', 'src/Support/MutationTestResult.php'):
        content = (plugin_base / relative).read_bytes()
        plugin_sources.append({'path': f'vendor/pestphp/pest-plugin-mutate/{relative}',
                               'sha256': hashlib.sha256(content).hexdigest()})
    plugin_lines = [{'line': i + 1, 'text': line} for i, line in enumerate(coverage_log.splitlines())
                    if re.search(r'Installing pestphp/pest(?:-plugin-mutate)? \(', line)]
    coverage['console']['pest_version_confirmed_in_current_ci_log'] = pest_match.group(1)
    coverage['php_version_confirmed_in_current_ci_log'] = coverage_php.group(1)
    artifact_id = str(coverage['artifact']['id'])
    artifact_digest = coverage['archive']['sha256']
    assert artifact_id in coverage_log and artifact_digest in coverage_log
    coverage['artifact_upload_log_excerpts'] = [
        {'line': i + 1, 'text': line} for i, line in enumerate(coverage_log.splitlines())
        if artifact_id in line or artifact_digest in line
    ]
    coverage['verification']['artifact_id_and_digest_present_in_same_job_log'] = True
    coverage['workflow_steps'] = [{key: step.get(key) for key in
                                   ('number', 'name', 'status', 'conclusion', 'started_at', 'completed_at')}
                                  for step in by_id[COVERAGE_JOB]['steps'] if step['name'] in
                                  ('Enforce coverage and generate Clover report',
                                   'Check mutation score', 'Upload coverage artifact')]
    coverage['threshold_percent'] = 80
    coverage['raw_test_summaries'] = [line for line in coverage_log.splitlines() if 'Tests:' in line]
    mutation['plugin'] = {'name': 'pestphp/pest-plugin-mutate', 'version': plugin['version'],
                          'source_reference_local': plugin['source']['reference'],
                          'version_confirmed_in_current_ci_log': True,
                          'current_ci_dependency_excerpts': plugin_lines,
                          'locally_read_definition_files': plugin_sources}
    mutation['plugin']['definition_excerpts'] = []
    for relative, first, last in (
        ('src/Repositories/MutationRepository.php', 74, 81),
        ('src/MutationTest.php', 117, 149),
    ):
        source_lines = (plugin_base / relative).read_text().splitlines()
        mutation['plugin']['definition_excerpts'].append({
            'path': f'vendor/pestphp/pest-plugin-mutate/{relative}',
            'first_line': first, 'last_line': last,
            'text': '\n'.join(source_lines[first - 1:last]),
        })
    counts = mutation['categories']
    mutation['category_count_origin'] = {
        'explicitly_printed': ['tested', 'timeout', 'untested'],
        'zero_categories_absent_from_summary': ['uncovered', 'pending'],
        'total_reconciles_with_printed_categories': True,
    }
    mutation['category_definitions'] = {
        'tested': 'A mutation worker completed with a non-success exit; this is the plugin classification, not independent proof of a semantic assertion failure for every worker.',
        'timeout': 'The worker exceeded its process timeout and was classified separately as Timeout.',
        'untested': 'The worker completed successfully; the mutation survived this test run.',
        'uncovered': 'The plugin classified the mutation as lacking test coverage.',
        'pending': 'No terminal category was present; this must be zero for this completed accounting.',
    }
    mutation['reported_msi_formula'] = {
        'expression': '100 * (tested + timeout) / total',
        'numerator': counts['tested'] + counts['timeout'], 'denominator': mutation['total'],
        'percent': mutation['calculated_msi_percent'],
        'rounded_to_two_decimals': mutation['calculated_msi_rounded_percent'],
        'matches_reported': True,
    }
    mutation['completed_tested_ratio'] = {
        'expression': '100 * tested / total', 'numerator': counts['tested'],
        'denominator': mutation['total'], 'percent': mutation['completed_tested_over_all_percent'],
        'timeout_excluded_from_numerator_only': True,
    }
    mutation['threshold_percent'] = 85
    mutation['survivors'] = {'count': survivors['count'], 'unique_ids': True,
                             'catalogue': record('fresh-survivors.json'),
                             'delta': record('survivor-delta.json'),
                             'previous_count': delta['previous']['count'],
                             'retained': delta['retained_count'], 'added': delta['added_count'],
                             'removed': delta['removed_count'], 'added_ids': delta['added_ids']}
    mutation['survivors']['printed_mutation_predecessor_mapping'] = {
        'evidence': record('survivor-relocations.json'),
        'added_ids_with_unique_predecessor': len(relocations['mappings']),
        'identical_entire_diff_context': sum(item['selected_predecessor']['entire_diff_context_identical']
                                            for item in relocations['mappings']),
        'same_changed_lines_with_changed_surrounding_context': sum(not item['selected_predecessor']['entire_diff_context_identical']
                                                                   for item in relocations['mappings']),
        'meaning': 'Printed mutation correspondence after source-file edits; not a claim that all reachable behaviors are equivalent.',
    }
    old_platforms = {item['path']: item for item in read('platform-log-summary.json')}
    platforms = []
    for job_id, text in texts.items():
        if job_id == COVERAGE_JOB:
            continue
        name = f'job-{job_id}.log'
        saved = record(name)
        assert saved['sha256'] == old_platforms[name]['sha256']
        assert saved['bytes'] == old_platforms[name]['bytes']
        version = re.search(r'(?:Found|Installed|Updated to) PHP (\d+\.\d+\.\d+)', text)
        styles = re.findall(r'Found (\d+) of (\d+) files that can be fixed', text)
        tests = re.findall(r'Tests:\s+([^\r\n]+?)\((\d+) assertions\)', text)
        assert version and styles and tests and '[OK] No errors' in text
        style_changed, style_files = map(int, styles[-1])
        assert style_changed == 0
        test_detail, assertions = tests[-1]
        test_counts = {key: int(number) for number, key in re.findall(
            r'(\d+)\s+(passed|skipped|failed|todo)', test_detail)}
        assert test_counts.get('failed', 0) == 0
        platforms.append({'job_id': job_id, 'name': REQUIRED[job_id], 'php_version': version.group(1),
                           'tests': {**test_counts, 'assertions': int(assertions)},
                           'style': {'files_needing_changes': style_changed, 'files_checked': style_files},
                           'phpstan': {'level': 'max', 'no_errors': True},
                           'log': saved, 'preexisting_log_hash_unchanged': True,
                           'raw_summary_excerpts': old_platforms[name]['summary_lines']})
    result = {
        'schema_version': 1, 'observed_at': datetime.now(timezone.utc).isoformat(),
        'repository': 'componenta/di', 'run': run,
        'all_five_required_jobs_success': True, 'required_jobs': required_jobs,
        'other_jobs': [{key: job.get(key) for key in ('id', 'name', 'status', 'conclusion', 'head_sha', 'run_attempt')}
                       for job in jobs if job['id'] not in REQUIRED],
        'coverage': coverage, 'mutation': mutation, 'platforms': platforms,
        'metadata': [record(name) for name in
                     ('run-metadata-final.json', 'jobs-metadata-final.json', 'artifacts-metadata-final.json')],
        'limits': [
            'No workflow was rerun, cancelled, or changed to obtain these results; this is attempt 1 of the exact stated head.',
            'Tested is the plugin result for a completed non-success process, not proof that every outcome is a semantic kill.',
            'Timeouts count toward reported MSI; the separate completed-tested share retains all mutations in its denominator.',
            'Survivor catalogue deltas are exact-ID comparisons; they are not automatically counts of bugs, gaps, or fixes.',
            'Clover describes PHP 8.4 PCOV statement/executable-line and method coverage, not branch/path coverage or coverage on all platforms.',
            'Platform-specific skipped tests remain visible in the saved logs; five successful jobs do not remove documented native-engine or conditional-policy limits.',
            'Successful benchmark smoke steps establish execution only, not an application speedup or statistically supported performance result.',
            'Job-log hashes identify the full UTF-8 decoded log text supplied by the GitHub connector; ZIP and Clover hashes identify exact downloaded bytes.',
        ],
    }
    (HERE / 'final-ci-summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'head': HEAD, 'all_five_required_jobs_success': True,
                      'summary': record('final-ci-summary.json'),
                      'counts': counts, 'total': mutation['total'],
                      'msi': mutation['reported_msi_percent'],
                      'fresh_survivors': survivors['count'], 'new_ids': delta['added_count']}, indent=2))


if __name__ == '__main__':
    main()
