#!/usr/bin/env python3
"""Verify and preserve an Actions Clover ZIP without executing repository code."""
from __future__ import annotations

import argparse
from decimal import Decimal, ROUND_FLOOR
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

HEAD = '42b62afd9c6a57caa0db3916585e823ab6ebaafa'
RUN_ID = 43857035628
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')


def file_record(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main() -> None:
    cli = argparse.ArgumentParser()
    cli.add_argument('--directory', type=Path, required=True)
    cli.add_argument('--repo', type=Path, required=True)
    args = cli.parse_args()
    directory = args.directory
    payload = json.loads((directory / 'artifacts-metadata-final.json').read_text())
    matches = [item for item in payload['artifacts'] if item['name'] == 'coverage-php-8.4']
    assert len(matches) == 1, 'Expected exactly one named coverage artifact'
    artifact = matches[0]
    assert not artifact['expired'], 'Coverage artifact expired'
    assert artifact['workflow_run']['id'] == RUN_ID
    assert artifact['workflow_run']['head_sha'] == HEAD
    archive_path = directory / 'coverage-php-8.4.zip'
    archive = file_record(archive_path)
    expected_digest = artifact['digest']
    assert expected_digest == 'sha256:' + archive['sha256'], (expected_digest, archive['sha256'])
    assert artifact['size_in_bytes'] == archive['bytes'], (artifact['size_in_bytes'], archive['bytes'])
    with zipfile.ZipFile(archive_path) as zipped:
        assert zipped.testzip() is None, 'ZIP CRC failure'
        members = [{'name': item.filename, 'bytes': item.file_size,
                    'compressed_bytes': item.compress_size, 'crc32': f'{item.CRC:08x}'}
                   for item in zipped.infolist()]
        reports = [item for item in zipped.infolist()
                   if Path(item.filename).name == 'coverage.xml' and not item.is_dir()]
        assert len(reports) == 1, 'Expected one coverage.xml member'
        xml_bytes = zipped.read(reports[0])
    xml_path = directory / 'coverage.xml'
    if xml_path.exists():
        assert xml_path.read_bytes() == xml_bytes, 'Existing Clover file differs from archive'
    else:
        xml_path.write_bytes(xml_bytes)
    tree = ET.fromstring(xml_bytes)
    project = tree.find('project')
    assert project is not None
    metrics_element = project.find('metrics')
    assert metrics_element is not None
    metrics = {key: int(value) for key, value in metrics_element.attrib.items()}
    # Clover can group class files under package nodes and keep other files at project level.
    files = project.findall('.//file')
    assert metrics['files'] == len(files)
    sums = {key: sum(int(item.find('metrics').get(key, '0')) for item in files)
            for key in metrics if key != 'files'}
    assert all(sums[key] == metrics[key] for key in sums), (sums, metrics)
    normalized_files = []
    for item in files:
        path = item.attrib['name'].replace('\\', '/')
        position = path.find('/src/')
        if position >= 0:
            path = path[position + 1:]
        assert path.startswith('src/') and '..' not in path.split('/')
        normalized_files.append(path)
    assert len(set(normalized_files)) == len(normalized_files)
    git_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.repo, text=True).strip()
    assert git_head == HEAD, git_head
    source_files = subprocess.check_output(
        ['git', 'ls-tree', '-r', '--name-only', HEAD, '--', 'src/'], cwd=args.repo, text=True).splitlines()
    assert sorted(source_files) == sorted(normalized_files), {
        'xml_only': sorted(set(normalized_files) - set(source_files)),
        'git_only': sorted(set(source_files) - set(normalized_files)),
    }
    statement_pct = Decimal(metrics['coveredstatements']) / Decimal(metrics['statements']) * 100
    method_pct = Decimal(metrics['coveredmethods']) / Decimal(metrics['methods']) * 100
    log_path = directory / 'job-133263982873.log'
    lines = [ANSI.sub('', line) for line in log_path.read_text().splitlines()]
    console = [(i, re.search(r'Total:\s*([\d.]+)\s*%', line))
               for i, line in enumerate(lines) if re.search(r'Total:\s*([\d.]+)\s*%', line)]
    assert console
    console_index, console_match = console[-1]
    console_pct = console_match.group(1)
    floored_pct = str(statement_pct.quantize(Decimal('0.1'), rounding=ROUND_FLOOR))
    assert Decimal(console_pct) == Decimal(floored_pct), (console_pct, floored_pct)
    formatter = args.repo / 'vendor/pestphp/pest/src/Support/Coverage.php'
    installed = json.loads((args.repo / 'vendor/composer/installed.json').read_text())
    pest = next(item for item in installed['packages'] if item['name'] == 'pestphp/pest')
    result = {
        'schema_version': 1,
        'source': {'head_sha': HEAD, 'run_id': RUN_ID, 'job_id': 133263982873},
        'artifact': {key: artifact.get(key) for key in
                     ('id', 'name', 'size_in_bytes', 'digest', 'expired', 'created_at', 'updated_at', 'expires_at', 'workflow_run')},
        'archive': archive,
        'verification': {'sha256_matches_artifact_digest': True, 'size_matches_metadata': True,
                         'zip_crc_all_members_valid': True, 'members': members,
                         'clover_file_equals_exact_archive_member': True,
                         'project_metrics_equal_sum_of_file_metrics': True,
                         'source_file_set_equals_immutable_commit': True},
        'clover': {**file_record(xml_path), 'project_metrics': metrics,
                   'statements': {'covered': metrics['coveredstatements'], 'total': metrics['statements'],
                                  'percentage': str(statement_pct)},
                   'methods': {'covered': metrics['coveredmethods'], 'total': metrics['methods'],
                               'percentage': str(method_pct)},
                   'source_files': sorted(normalized_files)},
        'console': {'total_percent': console_pct,
                    'excerpt': {'line': console_index + 1, 'text': lines[console_index]},
                    'formatter': 'number_format(floor($totalCoverage->asFloat() * 10) / 10, 1, ".", "")',
                    'exact_statement_percentage_floored_to_one_decimal_matches': True,
                    'pest_package_version_local': pest['version'],
                    'pest_package_source_reference_local': pest['source']['reference'],
                    'formatter_source_file': 'vendor/pestphp/pest/src/Support/Coverage.php',
                    'formatter_source_sha256_local': hashlib.sha256(formatter.read_bytes()).hexdigest()},
        'limits': ['These are statement/executable-line and method coverage counts, not branch or path coverage.',
                   'Coverage is reported by the PHP 8.4 PCOV workflow job; other platform jobs do not produce Clover.'],
    }
    (directory / 'coverage-metrics.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'statements': result['clover']['statements'], 'methods': result['clover']['methods'],
                      'console_total_percent': console_pct, 'files': len(files),
                      'archive': archive, 'clover_sha256': result['clover']['sha256']}, indent=2))


if __name__ == '__main__':
    main()
